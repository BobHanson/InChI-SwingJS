(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.phesa.AtomicGaussian','com.actelion.research.chem.phesa.pharmacophore.pp.PPGaussian','com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.transformation.Rotation','java.util.Collections','com.actelion.research.calc.SingularValueDecomposition','com.actelion.research.calc.Matrix','com.actelion.research.chem.phesa.PheSAAlignment',['com.actelion.research.chem.phesa.PheSAAlignment','.axis'],'StringBuilder','java.util.stream.Collectors','com.actelion.research.chem.alignment3d.transformation.ExponentialMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ShapeVolume");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['ppGaussians','java.util.List','+atomicGaussians','com','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.ppGaussians=Clazz.new_($I$(1,1));
this.atomicGaussians=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_ShapeVolume',  function (original) {
;C$.$init$.apply(this);
this.atomicGaussians=Clazz.new_($I$(1,1));
this.ppGaussians=Clazz.new_($I$(1,1));
for (var ag, $ag = original.getAtomicGaussians$().iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
this.atomicGaussians.add$O(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_phesa_AtomicGaussian,[ag]));
}
for (var pg, $pg = original.getPPGaussians$().iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
this.ppGaussians.add$O(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian,[pg]));
}
this.com=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_Coordinates,[original.com]);
}, 1);

Clazz.newMeth(C$, 'addPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian',  function (ppGaussian) {
this.ppGaussians.add$O(ppGaussian);
});

Clazz.newMeth(C$, 'addAtomVolume$com_actelion_research_chem_phesa_AtomicGaussian',  function (atomGaussian) {
this.atomicGaussians.add$O(atomGaussian);
});

Clazz.newMeth(C$, 'update$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getAtomicGaussians$(), mol.getAtomCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getPPGaussians$(), mol.getAtomCoordinates$());
});

Clazz.newMeth(C$, 'update$com_actelion_research_chem_conf_Conformer',  function (conf) {
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getAtomicGaussians$(), conf.getCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getPPGaussians$(), conf.getCoordinates$());
});

Clazz.newMeth(C$, 'transform$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transform) {
this.transformGaussians$com_actelion_research_chem_alignment3d_transformation_Transformation(transform);
});

Clazz.newMeth(C$, 'preProcess$com_actelion_research_chem_conf_Conformer',  function (conf) {
var COM=this.getCOM$();
if (conf != null ) {
var nrOfAtoms=conf.getSize$();
for (var i=0; i < nrOfAtoms; i++) {
var coords1=conf.getCoordinates$I(i);
coords1.sub$com_actelion_research_chem_Coordinates(COM);
}
}this.translateToCOM$com_actelion_research_chem_Coordinates(COM);
var rotation=this.createCanonicalOrientation$com_actelion_research_chem_conf_Conformer(conf);
var rot=Clazz.new_([rotation.getArray$()],$I$(5,1).c$$DAA);
return rot;
});

Clazz.newMeth(C$, 'removeRings$',  function () {
var toRemove=Clazz.new_($I$(1,1));
var i=0;
for (var ppg, $ppg = this.ppGaussians.iterator$(); $ppg.hasNext$()&&((ppg=($ppg.next$())),1);) {
if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == 4) toRemove.add$O(Integer.valueOf$I(i));
++i;
}
$I$(6).reverse$java_util_List(toRemove);
for (var index, $index = toRemove.iterator$(); $index.hasNext$()&&((index=($index.next$()).intValue$()),1);) {
this.ppGaussians.remove$I(index);
}
});

Clazz.newMeth(C$, 'createCanonicalOrientation$com_actelion_research_chem_conf_Conformer',  function (conf) {
var m=this.getCovarianceMatrix$();
var svd=Clazz.new_([m.getArray$(), null, null],$I$(7,1).c$$DAA$com_actelion_research_calc_ProgressListener$com_actelion_research_calc_ThreadMaster);
var u=Clazz.new_([svd.getU$()],$I$(8,1).c$$DAA);
var det=u.det$();
if (det < 0 ) {
u.set$I$I$D(0, 1, -u.get$I$I(0, 1));
u.set$I$I$D(1, 1, -u.get$I$I(1, 1));
u.set$I$I$D(2, 1, -u.get$I$I(2, 1));
}var rot=Clazz.new_([u.getArray$()],$I$(5,1).c$$DAA);
if (conf != null ) {
rot.apply$com_actelion_research_chem_conf_Conformer(conf);
this.update$com_actelion_research_chem_conf_Conformer(conf);
} else {
this.transformGaussians$com_actelion_research_chem_alignment3d_transformation_Transformation(rot);
}if (!this.isCanonicalOrientation$()) {
if (conf != null ) {
$I$(9,"rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis",[conf, $I$(10).X]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
} else {
this.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis($I$(10).X);
}if (this.isCanonicalOrientation$()) {
u.set$I$I$D(0, 1, -u.get$I$I(0, 1));
u.set$I$I$D(1, 1, -u.get$I$I(1, 1));
u.set$I$I$D(2, 1, -u.get$I$I(2, 1));
u.set$I$I$D(0, 2, -u.get$I$I(0, 2));
u.set$I$I$D(1, 2, -u.get$I$I(1, 2));
u.set$I$I$D(2, 2, -u.get$I$I(2, 2));
} else {
if (conf != null ) {
$I$(9,"rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis",[conf, $I$(10).X]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
$I$(9,"rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis",[conf, $I$(10).Y]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
} else {
this.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis($I$(10).X);
this.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis($I$(10).Y);
}if (this.isCanonicalOrientation$()) {
u.set$I$I$D(0, 0, -u.get$I$I(0, 0));
u.set$I$I$D(1, 0, -u.get$I$I(1, 0));
u.set$I$I$D(2, 0, -u.get$I$I(2, 0));
u.set$I$I$D(0, 2, -u.get$I$I(0, 2));
u.set$I$I$D(1, 2, -u.get$I$I(1, 2));
u.set$I$I$D(2, 2, -u.get$I$I(2, 2));
} else {
if (conf != null ) {
$I$(9,"rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis",[conf, $I$(10).Y]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
$I$(9,"rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis",[conf, $I$(10).Z]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
} else {
this.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis($I$(10).Y);
this.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis($I$(10).Z);
}if (this.isCanonicalOrientation$()) {
u.set$I$I$D(0, 0, -u.get$I$I(0, 0));
u.set$I$I$D(1, 0, -u.get$I$I(1, 0));
u.set$I$I$D(2, 0, -u.get$I$I(2, 0));
u.set$I$I$D(0, 1, -u.get$I$I(0, 1));
u.set$I$I$D(1, 1, -u.get$I$I(1, 1));
u.set$I$I$D(2, 1, -u.get$I$I(2, 1));
}}}}return u;
});

Clazz.newMeth(C$, 'isCanonicalOrientation$',  function () {
var xxPos=0;
var xxNeg=0;
var yyPos=0;
var yyNeg=0;
var nXPos=0;
var nXNeg=0;
var nYPos=0;
var nYNeg=0;
for (var ag, $ag = this.atomicGaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
var x=ag.center.x;
var y=ag.center.y;
if (x > 0 ) {
xxPos+=x * x;
++nXPos;
} else {
xxNeg+=x * x;
++nXNeg;
}if (y > 0 ) {
yyPos+=y * y;
++nYPos;
} else {
yyNeg+=y * y;
++nYNeg;
}}
xxPos/=nXPos;
yyPos/=nYPos;
xxNeg/=nXNeg;
yyNeg/=nYNeg;
if (xxPos > xxNeg  && yyPos > yyNeg  ) return true;
 else return false;
});

Clazz.newMeth(C$, 'getCOM$',  function () {
this.calcCOM$();
return this.com;
});

Clazz.newMeth(C$, 'calcCOM$',  function () {
var volume=0.0;
var comX=0.0;
var comY=0.0;
var comZ=0.0;
for (var atGauss, $atGauss = this.atomicGaussians.iterator$(); $atGauss.hasNext$()&&((atGauss=($atGauss.next$())),1);) {
volume+=atGauss.getVolume$();
comX+=atGauss.getCenter$().x * atGauss.getVolume$();
comY+=atGauss.getCenter$().y * atGauss.getVolume$();
comZ+=atGauss.getCenter$().z * atGauss.getVolume$();
}
comX=comX / volume;
comY=comY / volume;
comZ=comZ / volume;
this.com=Clazz.new_($I$(4,1).c$$D$D$D,[comX, comY, comZ]);
});

Clazz.newMeth(C$, 'updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA',  function (gaussians, coords) {
for (var gaussian, $gaussian = gaussians.iterator$(); $gaussian.hasNext$()&&((gaussian=($gaussian.next$())),1);) {
gaussian.updateCoordinates$com_actelion_research_chem_CoordinatesA(coords);
}
});

Clazz.newMeth(C$, 'transformGaussians$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transform) {
C$.transformGaussians$java_util_List$com_actelion_research_chem_alignment3d_transformation_Transformation(this.atomicGaussians, transform);
C$.transformGaussians$java_util_List$com_actelion_research_chem_alignment3d_transformation_Transformation(this.ppGaussians, transform);
});

Clazz.newMeth(C$, 'transformGaussians$java_util_List$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (gaussians, transform) {
for (var gaussian, $gaussian = gaussians.iterator$(); $gaussian.hasNext$()&&((gaussian=($gaussian.next$())),1);) {
gaussian.transform$com_actelion_research_chem_alignment3d_transformation_Transformation(transform);
}
}, 1);

Clazz.newMeth(C$, 'rotateGaussian$java_util_List$DAA',  function (gaussians, rot) {
for (var gaussian, $gaussian = gaussians.iterator$(); $gaussian.hasNext$()&&((gaussian=($gaussian.next$())),1);) {
var coords1=Clazz.new_([gaussian.getCenter$()],$I$(4,1).c$$com_actelion_research_chem_Coordinates);
coords1.rotate$DAA(rot);
gaussian.setCenter$com_actelion_research_chem_Coordinates(coords1);
}
}, 1);

Clazz.newMeth(C$, 'rotateGaussians180DegreeAroundAxis$java_util_List$com_actelion_research_chem_phesa_PheSAAlignment_axis',  function (gaussians, a) {
for (var gaussian, $gaussian = gaussians.iterator$(); $gaussian.hasNext$()&&((gaussian=($gaussian.next$())),1);) {
var coords1=Clazz.new_([gaussian.getCenter$()],$I$(4,1).c$$com_actelion_research_chem_Coordinates);
$I$(9).rotateCoordsAroundAxis180$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_PheSAAlignment_axis(coords1, a);
gaussian.setCenter$com_actelion_research_chem_Coordinates(coords1);
}
}, 1);

Clazz.newMeth(C$, 'rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis',  function (a) {
C$.rotateGaussians180DegreeAroundAxis$java_util_List$com_actelion_research_chem_phesa_PheSAAlignment_axis(this.atomicGaussians, a);
C$.rotateGaussians180DegreeAroundAxis$java_util_List$com_actelion_research_chem_phesa_PheSAAlignment_axis(this.ppGaussians, a);
});

Clazz.newMeth(C$, 'encode$',  function () {
var sb=Clazz.new_($I$(11,1));
sb.append$S(Integer.toString$I(this.atomicGaussians.size$()));
sb.append$S("  ");
this.atomicGaussians.forEach$java_util_function_Consumer(((P$.ShapeVolume$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ShapeVolume$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_phesa_AtomicGaussian','accept$O'],  function (e) /*block*/{
this.$finals$.sb.append$S.apply(this.$finals$.sb, [e.encode$.apply(e, [])]);
this.$finals$.sb.append$S.apply(this.$finals$.sb, ["  "]);
});
})()
), Clazz.new_(P$.ShapeVolume$lambda1.$init$,[this, {sb:sb}])));
sb.append$S(Integer.toString$I(this.ppGaussians.size$()));
sb.append$S("  ");
this.ppGaussians.forEach$java_util_function_Consumer(((P$.ShapeVolume$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "ShapeVolume$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian','accept$O'],  function (e) /*block*/{
this.$finals$.sb.append$S.apply(this.$finals$.sb, [e.encode$.apply(e, [])]);
this.$finals$.sb.append$S.apply(this.$finals$.sb, ["  "]);
});
})()
), Clazz.new_(P$.ShapeVolume$lambda2.$init$,[this, {sb:sb}])));
return sb.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
var splitString=s.split$S("  ");
var nrOfAtomicGaussians=(Integer.decode$S(splitString[0].trim$())).$c();
var firstIndex=1;
var lastIndex=1 + nrOfAtomicGaussians;
var atomicGaussians=Clazz.new_($I$(1,1));
var ppGaussians=Clazz.new_($I$(1,1));
for (var i=firstIndex; i < lastIndex; i++) {
atomicGaussians.add$O($I$(2,"fromString$S",[splitString[i].trim$()]));
}
var nrOfPPGaussians=(Integer.decode$S(splitString[lastIndex])).$c();
firstIndex=lastIndex + 1;
lastIndex=firstIndex + nrOfPPGaussians;
for (var i=firstIndex; i < lastIndex; i++) {
ppGaussians.add$O($I$(3).fromString$S$com_actelion_research_chem_StereoMolecule(splitString[i], null));
}
var receptorVol=Clazz.new_(C$);
atomicGaussians.forEach$java_util_function_Consumer(((P$.ShapeVolume$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "ShapeVolume$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_phesa_AtomicGaussian','accept$O'],  function (e) { return (this.$finals$.receptorVol.addAtomVolume$com_actelion_research_chem_phesa_AtomicGaussian.apply(this.$finals$.receptorVol, [e]));});
})()
), Clazz.new_(P$.ShapeVolume$lambda3.$init$,[this, {receptorVol:receptorVol}])));
ppGaussians.forEach$java_util_function_Consumer(((P$.ShapeVolume$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "ShapeVolume$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian','accept$O'],  function (e) { return (this.$finals$.receptorVol.addPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian.apply(this.$finals$.receptorVol, [e]));});
})()
), Clazz.new_(P$.ShapeVolume$lambda4.$init$,[this, {receptorVol:receptorVol}])));
return receptorVol;
}, 1);

Clazz.newMeth(C$, 'getExitVectorGaussians$',  function () {
return this.ppGaussians.stream$().filter$java_util_function_Predicate(((P$.ShapeVolume$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "ShapeVolume$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian','test$O'],  function (e) { return ((Clazz.instanceOf(e.getPharmacophorePoint$.apply(e, []), "com.actelion.research.chem.phesa.pharmacophore.pp.ExitVectorPoint")));});
})()
), Clazz.new_(P$.ShapeVolume$lambda5.$init$,[this, null]))).collect$java_util_stream_Collector($I$(12).toList$());
});

Clazz.newMeth(C$, 'getPPGaussians$',  function () {
return this.ppGaussians;
});

Clazz.newMeth(C$, 'setPPGaussians$java_util_List',  function (ppGaussians) {
this.ppGaussians=ppGaussians;
});

Clazz.newMeth(C$, 'getAtomicGaussians$',  function () {
return this.atomicGaussians;
});

Clazz.newMeth(C$, 'setAtomicGaussians$java_util_List',  function (atomicGaussians) {
this.atomicGaussians=atomicGaussians;
});

Clazz.newMeth(C$, 'getCovarianceMatrix$',  function () {
var massMatrix=Clazz.new_($I$(8,1).c$$I$I,[3, 3]);
var volume=0.0;
for (var ag, $ag = this.atomicGaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
volume+=ag.getVolume$();
var value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().x ;
massMatrix.addToElement$I$I$D(0, 0, value);
value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().y ;
massMatrix.addToElement$I$I$D(0, 1, value);
value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(0, 2, value);
value=ag.getVolume$() * ag.getCenter$().y * ag.getCenter$().y ;
massMatrix.addToElement$I$I$D(1, 1, value);
value=ag.getVolume$() * ag.getCenter$().y * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(1, 2, value);
value=ag.getVolume$() * ag.getCenter$().z * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(2, 2, value);
}
massMatrix.set$I$I$D(0, 0, massMatrix.get$I$I(0, 0) / volume);
massMatrix.set$I$I$D(0, 1, massMatrix.get$I$I(0, 1) / volume);
massMatrix.set$I$I$D(0, 2, massMatrix.get$I$I(0, 2) / volume);
massMatrix.set$I$I$D(1, 1, massMatrix.get$I$I(1, 1) / volume);
massMatrix.set$I$I$D(1, 2, massMatrix.get$I$I(1, 2) / volume);
massMatrix.set$I$I$D(2, 2, massMatrix.get$I$I(2, 2) / volume);
massMatrix.set$I$I$D(1, 0, massMatrix.get$I$I(0, 1));
massMatrix.set$I$I$D(2, 0, massMatrix.get$I$I(0, 2));
massMatrix.set$I$I$D(2, 1, massMatrix.get$I$I(1, 2));
return massMatrix;
});

Clazz.newMeth(C$, 'getSelfAtomOverlap$',  function () {
var Vtot=0.0;
for (var at, $at = this.atomicGaussians.iterator$(); $at.hasNext$()&&((at=($at.next$())),1);) {
for (var at2, $at2 = this.atomicGaussians.iterator$(); $at2.hasNext$()&&((at2=($at2.next$())),1);) {
Vtot+=at.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D(at2);
}
}
return Vtot;
});

Clazz.newMeth(C$, 'getSelfPPOverlap$',  function () {
var Vtot=0.0;
for (var pp, $pp = this.ppGaussians.iterator$(); $pp.hasNext$()&&((pp=($pp.next$())),1);) {
for (var pp2, $pp2 = this.ppGaussians.iterator$(); $pp2.hasNext$()&&((pp2=($pp2.next$())),1);) {
Vtot+=pp.getWeight$() * pp.getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian(pp2) * pp.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D(pp2) ;
}
}
return Vtot;
});

Clazz.newMeth(C$, 'getTotalAtomOverlap$DA$com_actelion_research_chem_phesa_ShapeVolume',  function (transform, fitVol) {
var result=Clazz.array(Double.TYPE, [2]);
var eMap=Clazz.new_($I$(13,1).c$$D$D$D,[transform[0], transform[1], transform[2]]);
var Vtot=0.0;
var Vvol=0.0;
var com=fitVol.getCOM$();
var rotMatrix=eMap.toQuaternion$().getRotMatrix$().getArray$();
var fitGaussians=fitVol.atomicGaussians;
var fitCenterModCoords=Clazz.array($I$(4), [fitGaussians.size$()]);
for (var k=0; k < fitGaussians.size$(); k++) {
var center=Clazz.new_([fitGaussians.get$I(k).getCenter$()],$I$(4,1).c$$com_actelion_research_chem_Coordinates);
center.sub$com_actelion_research_chem_Coordinates(com);
center.rotate$DAA(rotMatrix);
center.add$com_actelion_research_chem_Coordinates(com);
center.x+=transform[3];
center.y+=transform[4];
center.z+=transform[5];
fitCenterModCoords[k]=center;
}
for (var refAt, $refAt = this.atomicGaussians.iterator$(); $refAt.hasNext$()&&((refAt=($refAt.next$())),1);) {
var index=0;
for (var fitAt, $fitAt = fitVol.atomicGaussians.iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
Vtot+=refAt.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D(fitAt, fitCenterModCoords[index], 10.0);
index+=1;
}
}
if (Vtot < 0 ) Vtot=0.0;
result[0]=Vtot;
result[1]=Vvol;
return result;
});

Clazz.newMeth(C$, 'getTotalPPOverlap$DA$com_actelion_research_chem_phesa_ShapeVolume',  function (transform, fitVol) {
var eMap=Clazz.new_($I$(13,1).c$$D$D$D,[transform[0], transform[1], transform[2]]);
var Vtot=0.0;
var com=fitVol.getCOM$();
var rotMatrix=eMap.toQuaternion$().getRotMatrix$().getArray$();
var fitPPGaussians=fitVol.ppGaussians;
var fitCenterModCoords=Clazz.array($I$(4), [fitPPGaussians.size$()]);
var fitDirectionalityMod=Clazz.array($I$(4), [fitPPGaussians.size$()]);
for (var k=0; k < fitPPGaussians.size$(); k++) {
var center=Clazz.new_([fitPPGaussians.get$I(k).getCenter$()],$I$(4,1).c$$com_actelion_research_chem_Coordinates);
center.sub$com_actelion_research_chem_Coordinates(com);
center.rotate$DAA(rotMatrix);
center.add$com_actelion_research_chem_Coordinates(com);
center.x+=transform[3];
center.y+=transform[4];
center.z+=transform[5];
fitCenterModCoords[k]=center;
fitDirectionalityMod[k]=fitPPGaussians.get$I(k).getRotatedDirectionality$DAA$D(rotMatrix, 1.0);
}
for (var refPP, $refPP = this.ppGaussians.iterator$(); $refPP.hasNext$()&&((refPP=($refPP.next$())),1);) {
var index=0;
for (var fitPP, $fitPP = fitVol.ppGaussians.iterator$(); $fitPP.hasNext$()&&((fitPP=($fitPP.next$())),1);) {
Vtot+=refPP.getWeight$() * refPP.getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates(fitPP, fitDirectionalityMod[index]) * refPP.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D(fitPP, fitCenterModCoords[index], 10.0) ;
index+=1;
}
}
return Vtot;
});

Clazz.newMeth(C$, 'translateToCOM$com_actelion_research_chem_Coordinates',  function (com) {
for (var ag, $ag = this.getAtomicGaussians$().iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
ag.getCenter$().sub$com_actelion_research_chem_Coordinates(com);
}
for (var pg, $pg = this.getPPGaussians$().iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
pg.getCenter$().sub$com_actelion_research_chem_Coordinates(com);
}
this.calcCOM$();
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
