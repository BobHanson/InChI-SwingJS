(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "IPharmacophorePoint", function(){
});
C$.$classes$=[['Functionality',25]];
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'applyTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transform) {
transform.apply$com_actelion_research_chem_Coordinates(this.getCenter$());
if (Clazz.instanceOf(transform, "com.actelion.research.chem.alignment3d.transformation.Rotation")) {
var rot=transform;
var direc=this.getRotatedDirectionality$DAA$D(rot.getRotation$(), 1.0);
this.setDirectionality$com_actelion_research_chem_Coordinates(direc);
} else if (Clazz.instanceOf(transform, "com.actelion.research.chem.alignment3d.transformation.Scaling")) {
var scaling=transform;
var rot=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 1.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 0.0, 1.0])]);
var direc=this.getRotatedDirectionality$DAA$D(rot, scaling.getScalingFactor$());
this.setDirectionality$com_actelion_research_chem_Coordinates(direc);
}});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates',  function (pp2, directionalityMod) {
var vectorSim=0.0;
vectorSim=this.getDirectionality$().dot$com_actelion_research_chem_Coordinates(directionalityMod);
if (vectorSim < 0.0 ) {
vectorSim=0.0;
}return vectorSim;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp2) {
return this.getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates(pp2, pp2.getDirectionality$());
});
};;
(function(){/*e*/var C$=Clazz.newClass(P$.IPharmacophorePoint, "Functionality", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index']]]

Clazz.newMeth(C$, 'c$$I',  function (index) {
;C$.$init$.apply(this);
this.index=index;
}, 1);

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "ACCEPTOR", 0, [0]);
Clazz.newEnumConst($vals, C$.c$$I, "DONOR", 1, [1]);
Clazz.newEnumConst($vals, C$.c$$I, "NEG_CHARGE", 2, [2]);
Clazz.newEnumConst($vals, C$.c$$I, "POS_CHARGE", 3, [3]);
Clazz.newEnumConst($vals, C$.c$$I, "AROM_RING", 4, [6]);
Clazz.newEnumConst($vals, C$.c$$I, "EXIT_VECTOR", 5, [7]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
