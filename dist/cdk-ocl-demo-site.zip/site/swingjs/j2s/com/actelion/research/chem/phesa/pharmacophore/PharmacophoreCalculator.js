(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.phesa.pharmacophore.pp.AromRingPoint','java.util.Arrays','java.util.stream.Collectors','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','com.actelion.research.chem.phesa.pharmacophore.pp.DonorPoint','com.actelion.research.chem.AtomFunctionAnalyzer','com.actelion.research.chem.phesa.pharmacophore.pp.AcceptorPoint']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmacophoreCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getPharmacophorePoints$com_actelion_research_chem_StereoMolecule',  function (mol) {
var ppPoints=Clazz.new_($I$(1,1));
var rc=mol.getRingSet$();
for (var r=0; r < rc.getSize$(); r++) {
if (!rc.isAromatic$I(r)) continue;
var ringAtoms=rc.getRingAtoms$I(r);
var arp=Clazz.new_([mol, ringAtoms[0], $I$(3).stream$IA(ringAtoms).boxed$().collect$java_util_stream_Collector($I$(4).toList$())],$I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List);
ppPoints.add$O(arp);
}
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 1) {
if (C$.isDonorHydrogen$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
var d=mol.getConnAtom$I$I(i, 0);
var interactionClass=$I$(5).getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, d);
if (interactionClass < 0) {
continue;
}var dp=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule$I$I$I,[mol, d, i, interactionClass]);
ppPoints.add$O(dp);
}} else if (mol.getAtomicNo$I(i) == 7 || mol.getAtomicNo$I(i) == 8 ) {
if (C$.isAcceptor$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
var neighbours=mol.getAllConnAtoms$I(i);
var neighbourList=Clazz.new_($I$(1,1));
for (var j=0; j < neighbours; j++) neighbourList.add$O(Integer.valueOf$I(mol.getConnAtom$I$I(i, j)));

var interactionClass=$I$(5).getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, i);
if (interactionClass < 0) {
continue;
}if (mol.getAtomicNo$I(i) == 8 && neighbours == 1  && (mol.getConnBondOrder$I$I(i, 0) == 2 || $I$(7).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, i)  || mol.getAtomCharge$I(i) == -1 ) ) {
var a1=mol.getConnAtom$I$I(i, 0);
if (mol.getConnAtoms$I(a1) > 1) {
if (!(mol.getAtomicNo$I(a1) == 16 || mol.getAtomicNo$I(a1) == 15 )) {
var aa1=mol.getConnAtom$I$I(a1, 0);
if (aa1 == i) aa1=mol.getConnAtom$I$I(a1, 1);
neighbourList.add$O(Integer.valueOf$I(aa1));
var ap=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I$I,[mol, i, neighbourList, interactionClass, 1]);
ppPoints.add$O(ap);
var neighbourList2=Clazz.new_($I$(1,1));
for (var neighbour, $neighbour = neighbourList.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$()).intValue$()),1);) {
neighbourList2.add$O(Integer.valueOf$I(neighbour));
}
ap=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I$I,[mol, i, neighbourList2, interactionClass, 2]);
ppPoints.add$O(ap);
} else {
var ap=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[mol, i, neighbourList, interactionClass]);
ppPoints.add$O(ap);
}}} else if (neighbourList.size$() != 0) {
var ap=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[mol, i, neighbourList, interactionClass]);
ppPoints.add$O(ap);
}}}}
return ppPoints;
}, 1);

Clazz.newMeth(C$, 'isAcceptor$com_actelion_research_chem_StereoMolecule$I',  function (mol, a) {
if (mol.getAtomicNo$I(a) == 7 || mol.getAtomicNo$I(a) == 8 ) {
if (mol.getAtomCharge$I(a) <= 0) {
if (mol.isAromaticAtom$I(a)) {
if (mol.getAllConnAtoms$I(a) < 3) {
return true;
} else {
return false;
}} else if (mol.getAtomicNo$I(a) == 7) {
if (mol.getConnAtoms$I(a) == 1 && mol.getConnBondOrder$I$I(a, 0) == 3 ) return true;
if (mol.isFlatNitrogen$I(a)) {
for (var b=0; b < mol.getConnAtoms$I(a); b++) {
if (mol.getConnBondOrder$I$I(a, b) > 1) return true;
}
return false;
}for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var aa=mol.getConnAtom$I$I(a, i);
if (mol.getAtomicNo$I(aa) == 6) {
for (var j=0; j < mol.getAllConnAtoms$I(aa); j++) {
var aaa=mol.getConnAtom$I$I(aa, j);
if (a == aaa) continue;
if (mol.getBondOrder$I(mol.getBond$I$I(aa, aaa)) == 2) {
if (mol.getAtomicNo$I(aaa) == 7) return false;
if (mol.getAtomicNo$I(aaa) == 8) return false;
if (mol.getAtomicNo$I(aaa) == 16) return false;
}}
}}
}return true;
} else return false;
} else {
return false;
}}, 1);

Clazz.newMeth(C$, 'isDonorHydrogen$com_actelion_research_chem_StereoMolecule$I',  function (mol, h) {
if (mol.getAtomicNo$I(h) == 1) {
var dh=mol.getConnAtom$I$I(h, 0);
if (mol.getAtomCharge$I(dh) >= 0 && (mol.getAtomicNo$I(dh) == 7 || mol.getAtomicNo$I(dh) == 8 ) ) {
return true;
} else return false;
} else return false;
}, 1);

Clazz.newMeth(C$, 'isDonorHeavyAtom$com_actelion_research_chem_StereoMolecule$I',  function (mol, d) {
var isDonor=false;
if (mol.getAtomicNo$I(d) == 7 || mol.getAtomicNo$I(d) == 8 ) {
if (mol.getAtomCharge$I(d) >= 0) {
if (mol.getAllHydrogens$I(d) > 0) isDonor=true;
}}return isDonor;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
