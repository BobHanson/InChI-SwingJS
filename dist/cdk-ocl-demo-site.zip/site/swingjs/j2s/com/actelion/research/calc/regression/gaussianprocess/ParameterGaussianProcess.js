(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.gaussianprocess"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter','com.actelion.research.calc.regression.ParameterRegressionMethod','java.io.File']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterGaussianProcess", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['lambda']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["Gaussian process regression"]);C$.$init$.apply(this);
this.setLambda$D(0.005);
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var p=o;
return cmp;
});

Clazz.newMeth(C$, 'getLambda$',  function () {
return this.lambda;
});

Clazz.newMeth(C$, 'setLambda$D',  function (lambda) {
this.lambda=lambda;
this.properties.put$O$O("Lambda", Double.toString$D(lambda));
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.lambda=Double.parseDouble$S(this.properties.getProperty$S("Lambda"));
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ParameterGaussianProcess{"]);
sb.append$S("lambda=").append$S($I$(2,"format3$Double",[Double.valueOf$D(this.lambda)]));
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(3).getHeader$();
li.add$O("Lambda");
return li;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dir=Clazz.new_($I$(4,1).c$$S,["/home/korffmo1/tmp/tmp00"]);
var fiProp=Clazz.new_($I$(4,1).c$$java_io_File$S,[dir, "gaussianProcess.properties"]);
var parameter=Clazz.new_(C$);
parameter.lambda=1.123456;
parameter.write$java_io_File(fiProp);
var parameterIn=Clazz.new_(C$);
parameterIn.read$java_io_File(fiProp);
System.out.println$S(parameterIn.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:20 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
