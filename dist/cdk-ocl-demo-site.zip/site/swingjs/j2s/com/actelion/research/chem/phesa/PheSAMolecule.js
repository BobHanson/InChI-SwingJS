(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PheSAMolecule");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','shape','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mol=Clazz.new_($I$(1,1));
this.shape=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_phesa_MolecularVolume',  function (mol, shape) {
;C$.$init$.apply(this);
this.mol=mol;
this.shape=Clazz.new_($I$(2,1));
this.shape.add$O(shape);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$java_util_ArrayList',  function (mol, shape) {
;C$.$init$.apply(this);
this.mol=mol;
this.shape=shape;
}, 1);

Clazz.newMeth(C$, 'getConformer$com_actelion_research_chem_phesa_MolecularVolume',  function (molVol) {
var nrOfAtoms=this.mol.getAllAtoms$();
var conformer=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Molecule,[this.mol]);
var hydrogenCounter=0;
var hydrogens=molVol.getHydrogens$();
for (var i=0; i < nrOfAtoms; i++) {
if (this.mol.getAtomicNo$I(i) == 1) {
conformer.getCoordinates$I(i).set$com_actelion_research_chem_Coordinates(hydrogens.get$I(hydrogenCounter));
hydrogenCounter+=1;
}for (var j=0; j < molVol.getAtomicGaussians$().size$(); j++) {
var atomId=molVol.getAtomicGaussians$().get$I(j).getAtomId$();
conformer.getCoordinates$I(atomId).set$com_actelion_research_chem_Coordinates(molVol.getAtomicGaussians$().get$I(j).getCenter$());
}
}
conformer.ensureHelperArrays$I(1);
return conformer;
});

Clazz.newMeth(C$, 'getConformer$I',  function (index) {
return this.getConformer$com_actelion_research_chem_phesa_MolecularVolume(this.shape.get$I(index));
});

Clazz.newMeth(C$, 'getMolecule$',  function () {
return this.mol;
});

Clazz.newMeth(C$, 'getVolumes$',  function () {
return this.shape;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
