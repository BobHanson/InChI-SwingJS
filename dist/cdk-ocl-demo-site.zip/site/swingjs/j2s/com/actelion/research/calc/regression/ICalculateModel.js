(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ICalculateModel", null, null, 'com.actelion.research.calc.regression.ICalculateYHat');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:20 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
