(function(){var P$=Clazz.newPackage("com.actelion.research.chem.potentialenergy"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PositionConstraint", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['k','d'],'I',['atom'],'O',['refPos','double[]','conf','com.actelion.research.chem.conf.Conformer']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$I$D$D',  function (conf, atom, k, d) {
;C$.$init$.apply(this);
this.refPos=Clazz.array(Double.TYPE, [3]);
this.atom=atom;
this.conf=conf;
this.refPos[0]=conf.getX$I(atom);
this.refPos[1]=conf.getY$I(atom);
this.refPos[2]=conf.getZ$I(atom);
this.k=k;
this.d=d;
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var energy=0.0;
var pos=Clazz.array(Double.TYPE, -1, [this.conf.getX$I(this.atom), this.conf.getY$I(this.atom), this.conf.getZ$I(this.atom)]);
var dx=pos[0] - this.refPos[0];
var dy=pos[1] - this.refPos[1];
var dz=pos[2] - this.refPos[2];
var dist=Math.sqrt(dx * dx + dy * dy + dz * dz);
var prefactor=0.0;
if (dist > this.d ) prefactor=dist - this.d;
 else prefactor=0.0;
energy+=0.5 * this.k * prefactor * prefactor ;
gradient[this.atom]+=prefactor * dx / Math.max(dist, 1.0E-8);
gradient[this.atom + 1]+=prefactor * dy / Math.max(dist, 1.0E-8);
gradient[this.atom + 2]+=prefactor * dz / Math.max(dist, 1.0E-8);
return energy;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
