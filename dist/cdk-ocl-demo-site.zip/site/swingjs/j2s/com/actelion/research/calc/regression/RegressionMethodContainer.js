(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[[0,'com.actelion.research.calc.regression.median.MedianRegression','com.actelion.research.calc.regression.linear.pls.PLSRegressionModelCalculator','com.actelion.research.calc.regression.linear.pls.boxcox.PLSBoxCoxY','com.actelion.research.calc.regression.knn.KNNRegression','com.actelion.research.calc.regression.svm.SVMRegression','com.actelion.research.calc.regression.randomforest.RandomForestRegression','com.actelion.research.calc.regression.gaussianprocess.GaussianProcessRegression','com.actelion.research.calc.regression.neuralnetwork.NeuralNetworkRegression']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RegressionMethodContainer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['regressionMethod','com.actelion.research.calc.regression.ARegressionMethod','calculatorMedianRegression','com.actelion.research.calc.regression.median.MedianRegression','calculatorPLS','com.actelion.research.calc.regression.linear.pls.PLSRegressionModelCalculator','calculatorPLSBoxCox','com.actelion.research.calc.regression.linear.pls.boxcox.PLSBoxCoxY','calculatorKNNRegression','com.actelion.research.calc.regression.knn.KNNRegression','calculatorSVMRegression','com.actelion.research.calc.regression.svm.SVMRegression','randomForestRegression','com.actelion.research.calc.regression.randomforest.RandomForestRegression','gaussianProcessRegression','com.actelion.research.calc.regression.gaussianprocess.GaussianProcessRegression','neuralNetworkRegression','com.actelion.research.calc.regression.neuralnetwork.NeuralNetworkRegression']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.calculatorMedianRegression=Clazz.new_($I$(1,1));
this.calculatorPLS=Clazz.new_($I$(2,1));
this.calculatorPLSBoxCox=Clazz.new_($I$(3,1));
this.calculatorKNNRegression=Clazz.new_($I$(4,1));
this.calculatorSVMRegression=Clazz.new_($I$(5,1));
this.randomForestRegression=Clazz.new_($I$(6,1));
this.gaussianProcessRegression=Clazz.new_($I$(7,1));
this.neuralNetworkRegression=Clazz.new_($I$(8,1));
this.regressionMethod=this.calculatorPLS;
}, 1);

Clazz.newMeth(C$, 'getMedian$',  function () {
return this.calculatorMedianRegression;
});

Clazz.newMeth(C$, 'getPLS$',  function () {
return this.calculatorPLS;
});

Clazz.newMeth(C$, 'getPLSBoxCox$',  function () {
return this.calculatorPLSBoxCox;
});

Clazz.newMeth(C$, 'getKNN$',  function () {
return this.calculatorKNNRegression;
});

Clazz.newMeth(C$, 'getSVM$',  function () {
return this.calculatorSVMRegression;
});

Clazz.newMeth(C$, 'getRandomForestRegression$',  function () {
return this.randomForestRegression;
});

Clazz.newMeth(C$, 'getGaussianProcessRegression$',  function () {
return this.gaussianProcessRegression;
});

Clazz.newMeth(C$, 'getNeuralNetworkRegression$',  function () {
return this.neuralNetworkRegression;
});

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
return this.regressionMethod.createModel$com_actelion_research_util_datamodel_ModelXYIndex(modelXYIndexTrain);
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
return this.regressionMethod.calculateYHat$com_actelion_research_calc_Matrix(X);
});

Clazz.newMeth(C$, 'setMethod$S',  function (txt) {
if (this.calculatorMedianRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.calculatorMedianRegression;
} else if (this.calculatorKNNRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.calculatorKNNRegression;
} else if (this.calculatorPLSBoxCox.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.calculatorPLSBoxCox;
} else if (this.calculatorPLS.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.calculatorPLS;
} else if (this.calculatorSVMRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.calculatorSVMRegression;
} else if (this.randomForestRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.randomForestRegression;
} else if (this.gaussianProcessRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.gaussianProcessRegression;
} else if (this.neuralNetworkRegression.getName$().equals$O(txt.trim$())) {
this.regressionMethod=this.neuralNetworkRegression;
} else {
this.regressionMethod=this.calculatorPLS;
System.err.println$S("RegressionMethodFactory setMethod unknown model " + txt + " set to " + this.calculatorPLS.getName$() );
}});

Clazz.newMeth(C$, 'getRegressionMethod$',  function () {
return this.regressionMethod;
});

Clazz.newMeth(C$, 'getRegressionMethod$S',  function (txt) {
this.setMethod$S(txt);
return this.regressionMethod;
});

Clazz.newMeth(C$, 'createRegressionMethod$S',  function (txt) {
var regressionMethod=null;
if ("Median".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(1,1));
} else if ("KNN regression".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(4,1));
} else if ("PLS".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(2,1));
} else if ("PLS Power".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(3,1));
} else if ("SVM regression".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(5,1));
} else if ("Random Forest regression".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(6,1));
} else if ("Gaussian process regression".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(7,1));
} else if ("Neural network regression".equals$O(txt.trim$())) {
regressionMethod=Clazz.new_($I$(8,1));
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown regression type '" + txt + "'." ]);
}return regressionMethod;
}, 1);

Clazz.newMeth(C$, 'createRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod',  function (parameterRegressionMethod) {
var regressionMethod=C$.createRegressionMethod$S(parameterRegressionMethod.getName$());
regressionMethod.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterRegressionMethod);
return regressionMethod;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:20 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
