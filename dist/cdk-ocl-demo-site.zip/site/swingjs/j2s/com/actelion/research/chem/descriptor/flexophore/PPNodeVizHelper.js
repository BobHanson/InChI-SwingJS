(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.PPNodeViz','com.actelion.research.chem.descriptor.flexophore.PPNodeVizMultCoord','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPNodeVizHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createWithoutCoordinates$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$I$com_actelion_research_chem_Molecule3D',  function (multCoordFragIndex, indexPPPoint, mol) {
var ppNodeViz=Clazz.new_($I$(1,1));
ppNodeViz.setIndex$I(indexPPPoint);
for (var index, $index = 0, $$index = multCoordFragIndex.getArrIndexFrag$(); $index<$$index.length&&((index=($$index[$index])),1);$index++) {
var interactionType=mol.getInteractionAtomType$I(index);
ppNodeViz.add$I(interactionType);
ppNodeViz.addIndexOriginalAtom$I(index);
}
ppNodeViz.realize$();
var nodeVizMultCoord=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex,[ppNodeViz, multCoordFragIndex]);
return nodeVizMultCoord;
}, 1);

Clazz.newMeth(C$, 'createWithoutCoordinates$IA$I$com_actelion_research_chem_Molecule3D',  function (arrIndexAtomFrag, indexPPPoint, mol) {
var ppNodeViz=Clazz.new_($I$(1,1));
ppNodeViz.setIndex$I(indexPPPoint);
for (var index, $index = 0, $$index = arrIndexAtomFrag; $index<$$index.length&&((index=($$index[$index])),1);$index++) {
var interactionType=mol.getInteractionAtomType$I(index);
ppNodeViz.add$I(interactionType);
ppNodeViz.addIndexOriginalAtom$I(index);
}
ppNodeViz.realize$();
return ppNodeViz;
}, 1);

Clazz.newMeth(C$, 'createWithoutCoordinates$java_util_List$com_actelion_research_chem_Molecule3D',  function (liSubGraphIndices, mol) {
var liPPNodeViz=Clazz.new_($I$(3,1));
for (var i=0; i < liSubGraphIndices.size$(); i++) {
var sgi=liSubGraphIndices.get$I(i);
var ppNodeViz=C$.createWithoutCoordinates$IA$I$com_actelion_research_chem_Molecule3D(sgi.getAtomIndices$(), i, mol);
liPPNodeViz.add$O(ppNodeViz);
}
return liPPNodeViz;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
