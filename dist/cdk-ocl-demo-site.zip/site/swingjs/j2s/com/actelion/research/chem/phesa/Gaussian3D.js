(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.PeriodicTable','com.actelion.research.chem.phesa.QuickMathCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Gaussian3D");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['coeff','alpha','volume','weight'],'I',['atomId','atomicNo'],'O',['center','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$$I$I$com_actelion_research_chem_Coordinates$D',  function (atomId, atomicNo, center, weight) {
;C$.$init$.apply(this);
this.weight=weight;
this.atomId=atomId;
this.atomicNo=atomicNo;
this.center=center;
this.coeff=this.calculateHeight$();
this.alpha=this.calculateWidth$();
this.volume=this.calculateVolume$();
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_Gaussian3D',  function (original) {
;C$.$init$.apply(this);
this.atomId=original.atomId;
this.atomicNo=original.atomicNo;
this.coeff=original.coeff;
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[original.center]);
this.alpha=original.alpha;
this.volume=original.volume;
this.weight=original.weight;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'calculateVolume$',  function () {
var vdwR=$I$(2).getElement$I(this.atomicNo).getVDWRadius$();
var volume=(4.1887902047863905) * vdwR * vdwR * vdwR ;
return volume;
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.coeff;
});

Clazz.newMeth(C$, 'setHeight$D',  function (height) {
this.coeff=height;
});

Clazz.newMeth(C$, 'getWidth$',  function () {
return this.alpha;
});

Clazz.newMeth(C$, 'getVolume$',  function () {
return this.volume;
});

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'setCenter$com_actelion_research_chem_Coordinates',  function (center) {
this.center=center;
});

Clazz.newMeth(C$, 'getAtomicNo$',  function () {
return this.atomicNo;
});

Clazz.newMeth(C$, 'setAtomicNo$I',  function (atomicNo) {
this.atomicNo=atomicNo;
this.coeff=this.calculateHeight$();
this.alpha=this.calculateWidth$();
this.volume=this.calculateVolume$();
});

Clazz.newMeth(C$, 'getAtomId$',  function () {
return this.atomId;
});

Clazz.newMeth(C$, 'setAtomId$I',  function (atomId) {
this.atomId=atomId;
});

Clazz.newMeth(C$, 'getWeight$',  function () {
return this.weight;
});

Clazz.newMeth(C$, 'setWeight$D',  function (weight) {
this.weight=weight;
});

Clazz.newMeth(C$, 'transform$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transform) {
transform.apply$com_actelion_research_chem_Coordinates(this.center);
});

Clazz.newMeth(C$, 'getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D',  function (g2, c2, distCutoff) {
var alphaSum=this.getWidth$() + g2.getWidth$();
var Vij=0.0;
var Kij=0.0;
var dx=this.getCenter$().x - c2.x;
var dy=this.getCenter$().y - c2.y;
var dz=this.getCenter$().z - c2.z;
var Rij2=dx * dx + dy * dy + dz * dz;
if (Rij2 < distCutoff ) {
var c=-(this.getWidth$() * g2.getWidth$() * Rij2 ) / alphaSum;
Kij=this.getHeight$() * g2.getHeight$() * $I$(3).getInstance$().quickExp$D(c) ;
var factor=$I$(3).getInstance$().getPrefactor$I$I(this.getAtomicNo$(), g2.getAtomicNo$());
Vij=this.weight * factor * Kij ;
}return Vij;
});

Clazz.newMeth(C$, 'getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D',  function (g2) {
return this.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$D(g2, 10.0);
});

Clazz.newMeth(C$, 'getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$D',  function (g2, distCutoff) {
return this.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D(g2, g2.getCenter$(), distCutoff);
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[coords[this.atomId]]);
});

Clazz.newMeth(C$, 'updateAtomIndeces$IA',  function (map) {
this.atomId=map[this.atomId];
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
