(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),I$=[[0,'com.actelion.research.chem.phesa.pharmacophore.pp.AcceptorPoint','com.actelion.research.chem.phesa.pharmacophore.pp.DonorPoint','com.actelion.research.chem.phesa.pharmacophore.pp.ChargePoint','com.actelion.research.chem.phesa.pharmacophore.pp.AromRingPoint','com.actelion.research.chem.phesa.pharmacophore.pp.ExitVectorPoint','com.actelion.research.chem.phesa.pharmacophore.pp.SimplePharmacophorePoint']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmacophorePointFactory");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var type=ppString.split$S(" ")[0];
if (type.equals$O("a")) return $I$(1).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else if (type.equals$O("d")) return $I$(2).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else if (type.equals$O("i")) return $I$(3).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else if (type.equals$O("r")) return $I$(4).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else if (type.equals$O("e")) return $I$(5).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else if (type.equals$O("s")) return $I$(6).fromString$S$com_actelion_research_chem_StereoMolecule(ppString, mol);
 else return null;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
