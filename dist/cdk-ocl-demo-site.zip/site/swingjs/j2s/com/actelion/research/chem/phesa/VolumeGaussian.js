(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'com.actelion.research.chem.Coordinates','StringBuilder','com.actelion.research.util.EncoderFloatingPointNumbers','com.actelion.research.chem.PeriodicTable']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VolumeGaussian", null, 'com.actelion.research.chem.phesa.Gaussian3D');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['role'],'O',['shiftVector','com.actelion.research.chem.Coordinates','+referenceVector']]]

Clazz.newMeth(C$, 'c$$I$I$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I',  function (atomId, atomicNo, center, shiftVector, role) {
;C$.superclazz.c$$I$I$com_actelion_research_chem_Coordinates$D.apply(this,[atomId, atomicNo, center.addC$com_actelion_research_chem_Coordinates(shiftVector), 1.0]);C$.$init$.apply(this);
this.shiftVector=shiftVector;
this.referenceVector=center;
this.role=role;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_VolumeGaussian',  function (original) {
;C$.superclazz.c$$I$I$com_actelion_research_chem_Coordinates$D.apply(this,[original.atomId, original.atomicNo, original.center, original.weight]);C$.$init$.apply(this);
this.shiftVector=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[original.shiftVector]);
this.referenceVector=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[original.referenceVector]);
this.role=original.role;
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (encodedGaussian, mol) {
Clazz.super_(C$, this);
this.decode$S$com_actelion_research_chem_StereoMolecule(encodedGaussian, mol);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (encodedGaussian, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[encodedGaussian, mol]);
}, 1);

Clazz.newMeth(C$, 'encode$',  function () {
var shift=Clazz.array(Double.TYPE, -1, [this.shiftVector.x, this.shiftVector.y, this.shiftVector.z]);
var molVolString=Clazz.new_($I$(2,1));
molVolString.append$S(Integer.toString$I(this.atomicNo));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.atomId));
molVolString.append$S(" ");
molVolString.append$S($I$(3).encode$DA$I(shift, 13));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.role));
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (string64, mol) {
var strings=string64.split$S(" ");
this.atomicNo=(Integer.decode$S(strings[0])).$c();
this.atomId=(Integer.decode$S(strings[1])).$c();
var shift=$I$(3).decode$S(strings[2]);
this.role=(Integer.decode$S(strings[3])).$c();
this.alpha=this.calculateWidth$();
this.volume=this.calculateVolume$();
this.coeff=this.calculateHeight$();
this.referenceVector=Clazz.new_([mol.getAtomX$I(this.atomId), mol.getAtomY$I(this.atomId), mol.getAtomZ$I(this.atomId)],$I$(1,1).c$$D$D$D);
this.shiftVector=Clazz.new_($I$(1,1).c$$D$D$D,[shift[0], shift[1], shift[2]]);
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
this.weight=1.0;
});

Clazz.newMeth(C$, 'calculateHeight$',  function () {
return 2.82842712475;
});

Clazz.newMeth(C$, 'calculateWidth$',  function () {
var vdwR=$I$(4).getElement$I(this.atomicNo).getVDWRadius$();
return 2.41798793102 / (vdwR * vdwR);
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.referenceVector=Clazz.new_([mol.getCoordinates$I(this.atomId)],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_conf_Conformer',  function (conf) {
this.referenceVector=Clazz.new_([conf.getCoordinates$I(this.atomId)],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
});

Clazz.newMeth(C$, 'setShiftVector$com_actelion_research_chem_Coordinates',  function (shift) {
this.shiftVector=shift;
});

Clazz.newMeth(C$, 'getShiftVector$',  function () {
return this.shiftVector;
});

Clazz.newMeth(C$, 'addShift$com_actelion_research_chem_Coordinates',  function (shift) {
this.shiftVector.add$com_actelion_research_chem_Coordinates(shift);
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
});

Clazz.newMeth(C$, 'translateRef$com_actelion_research_chem_Coordinates',  function (trans) {
this.referenceVector.add$com_actelion_research_chem_Coordinates(trans);
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
});

Clazz.newMeth(C$, 'rotateShift$com_actelion_research_calc_Matrix',  function (rotMat) {
this.shiftVector.rotate$DAA(rotMat.getArray$());
this.center=this.referenceVector.addC$com_actelion_research_chem_Coordinates(this.shiftVector);
});

Clazz.newMeth(C$, 'getReferenceVector$',  function () {
return this.referenceVector;
});

Clazz.newMeth(C$, 'setReferenceVector$com_actelion_research_chem_Coordinates',  function (referenceVector) {
this.referenceVector=referenceVector;
});

Clazz.newMeth(C$, 'getRole$',  function () {
return this.role;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
