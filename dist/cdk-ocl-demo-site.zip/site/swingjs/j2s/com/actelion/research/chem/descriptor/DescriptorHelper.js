(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.IDCodeParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHelper", null, null, 'com.actelion.research.chem.descriptor.DescriptorConstants');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getDescriptorType$S',  function (shortName) {
var descriptorInfo=C$.getDescriptorInfo$S(C$.unifyShortName$S(shortName));
return (descriptorInfo == null ) ? -1 : descriptorInfo.type;
}, 1);

Clazz.newMeth(C$, 'getDescriptorInfo$S',  function (shortName) {
for (var i=0; i < $I$(1).DESCRIPTOR_EXTENDED_LIST.length; i++) if ($I$(1).DESCRIPTOR_EXTENDED_LIST[i].shortName.equals$O(C$.unifyShortName$S(shortName))) return $I$(1).DESCRIPTOR_EXTENDED_LIST[i];

return null;
}, 1);

Clazz.newMeth(C$, 'isBinaryFingerprint$S',  function (shortName) {
var descriptorInfo=C$.getDescriptorInfo$S(C$.unifyShortName$S(shortName));
return (descriptorInfo == null ) ? false : descriptorInfo.isBinary;
}, 1);

Clazz.newMeth(C$, 'isDescriptorShortName$S',  function (shortName) {
for (var i=0; i < $I$(1).DESCRIPTOR_EXTENDED_LIST.length; i++) if ($I$(1).DESCRIPTOR_EXTENDED_LIST[i].shortName.equals$O(C$.unifyShortName$S(shortName))) return true;

return false;
}, 1);

Clazz.newMeth(C$, 'shortNameToName$S',  function (shortName) {
for (var i=0; i < $I$(1).DESCRIPTOR_EXTENDED_LIST.length; i++) if ($I$(1).DESCRIPTOR_EXTENDED_LIST[i].shortName.equals$O(shortName)) return $I$(1).DESCRIPTOR_EXTENDED_LIST[i].name;

return null;
}, 1);

Clazz.newMeth(C$, 'nameToShortName$S',  function (name) {
for (var i=0; i < $I$(1).DESCRIPTOR_EXTENDED_LIST.length; i++) if ($I$(1).DESCRIPTOR_EXTENDED_LIST[i].name.equals$O(name)) return $I$(1).DESCRIPTOR_EXTENDED_LIST[i].shortName;

return null;
}, 1);

Clazz.newMeth(C$, 'unifyShortName$S',  function (shortname) {
return "PP3DMM2".equals$O(shortname) ? "Flexophore" : shortname;
}, 1);

Clazz.newMeth(C$, 'getTagDescriptorSimilarity$S',  function (shortName) {
return shortName + " Similarity";
}, 1);

Clazz.newMeth(C$, 'getTagDescriptorSimilarity$com_actelion_research_chem_descriptor_ISimilarityCalculator',  function (dh) {
return C$.getTagDescriptorSimilarity$S(dh.getInfo$().shortName);
}, 1);

Clazz.newMeth(C$, 'getTagDescriptorSimilarity$com_actelion_research_chem_descriptor_SimilarityCalculatorInfo',  function (info) {
return C$.getTagDescriptorSimilarity$S(info.shortName);
}, 1);

Clazz.newMeth(C$, 'getTagDescriptorSimilarity$com_actelion_research_chem_descriptor_DescriptorInfo',  function (dh) {
return C$.getTagDescriptorSimilarity$S(dh.shortName);
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_descriptor_DescriptorHandler$S',  function (dh, idcode) {
var parser=Clazz.new_($I$(2,1));
var mol=parser.getCompactMolecule$S(idcode);
mol.ensureHelperArrays$I(7);
return dh.createDescriptor$O(mol);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
