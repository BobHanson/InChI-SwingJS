(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "DescriptorHandler", null, null, 'com.actelion.research.chem.descriptor.ISimilarityCalculator');

C$.$clinit$=2;

C$.$fields$=[[]
,['O',['FAILED_BYTES','byte[]']]]

C$.$static$=function(){C$.$static$=0;
C$.FAILED_BYTES="Calculation Failed".getBytes$java_nio_charset_Charset($I$(1).UTF_8);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
