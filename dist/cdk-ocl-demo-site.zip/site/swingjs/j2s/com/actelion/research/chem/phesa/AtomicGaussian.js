(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'StringBuilder','com.actelion.research.util.EncoderFloatingPointNumbers','com.actelion.research.chem.Coordinates','com.actelion.research.chem.PeriodicTable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomicGaussian", null, 'com.actelion.research.chem.phesa.Gaussian3D');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$I$I$com_actelion_research_chem_Coordinates',  function (atomId, atomicNo, center) {
;C$.superclazz.c$$I$I$com_actelion_research_chem_Coordinates$D.apply(this,[atomId, atomicNo, center, 1.0]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_AtomicGaussian',  function (original) {
;C$.superclazz.c$$com_actelion_research_chem_phesa_Gaussian3D.apply(this,[original]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (encodedGaussian) {
Clazz.super_(C$, this);
this.decode$S(encodedGaussian);
}, 1);

Clazz.newMeth(C$, 'fromString$S',  function (encodedGaussian) {
return Clazz.new_(C$.c$$S,[encodedGaussian]);
}, 1);

Clazz.newMeth(C$, 'encode$',  function () {
var coords=Clazz.array(Double.TYPE, -1, [this.center.x, this.center.y, this.center.z]);
var molVolString=Clazz.new_($I$(1,1));
molVolString.append$S(Integer.toString$I(this.atomicNo));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.atomId));
molVolString.append$S(" ");
molVolString.append$S($I$(2,"encode$DA$I",[Clazz.array(Double.TYPE, -1, [this.weight]), 13]));
molVolString.append$S(" ");
molVolString.append$S($I$(2).encode$DA$I(coords, 13));
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (string64) {
var strings=string64.split$S(" ");
this.atomicNo=(Integer.decode$S(strings[0])).$c();
this.atomId=(Integer.decode$S(strings[1])).$c();
var w=$I$(2).decode$S(strings[2]);
var coords=$I$(2).decode$S(strings[3]);
this.alpha=this.calculateWidth$();
this.volume=this.calculateVolume$();
this.coeff=this.calculateHeight$();
this.center=Clazz.new_($I$(3,1).c$$D$D$D,[coords[0], coords[1], coords[2]]);
this.weight=w[0];
});

Clazz.newMeth(C$, 'calculateHeight$',  function () {
return 2.82842712475;
});

Clazz.newMeth(C$, 'calculateWidth$',  function () {
var vdwR=$I$(4).getElement$I(this.atomicNo).getVDWRadius$();
return 2.41798793102 / (vdwR * vdwR);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
