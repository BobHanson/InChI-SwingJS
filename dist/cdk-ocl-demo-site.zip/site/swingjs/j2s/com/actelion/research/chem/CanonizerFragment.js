(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.Arrays',['com.actelion.research.chem.Canonizer','.LongIntSorter'],'com.actelion.research.chem.CanonizerMesoHelper','java.util.ArrayList','com.actelion.research.chem.CanonizerBond','com.actelion.research.chem.CanonizerBaseValue','com.actelion.research.chem.SortedStringList','com.actelion.research.chem.CanonizerFragment','com.actelion.research.chem.EZHalfParity','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Molecule','StringBuilder','com.actelion.research.chem.Canonizer$1RankObject','com.actelion.research.chem.Canonizer$2RankObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CanonizerFragment");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['atom','int[]','+bond']]]

Clazz.newMeth(C$, 'c$$IA$I$IA$I',  function (atom, atoms, bond, bonds) {
;C$.$init$.apply(this);
this.atom=$I$(1).copyOf$IA$I(atom, atoms);
this.bond=$I$(1).copyOf$IA$I(bond, bonds);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:21 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
