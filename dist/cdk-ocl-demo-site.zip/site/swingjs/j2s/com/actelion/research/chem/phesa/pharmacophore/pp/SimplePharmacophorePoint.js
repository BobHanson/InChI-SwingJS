(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),I$=[[0,'com.actelion.research.chem.Coordinates','java.util.Base64','StringBuilder','com.actelion.research.chem.phesa.EncodeFunctions',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimplePharmacophorePoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atomID'],'O',['+center','functionality','com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint.Functionality']]
,['O',['directionality','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality',  function (atomID, center, functionality) {
;C$.$init$.apply(this);
this.atomID=atomID;
this.center=center;
this.functionality=functionality;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_SimplePharmacophorePoint',  function (point) {
;C$.$init$.apply(this);
this.atomID=point.atomID;
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[point.center]);
this.functionality=point.functionality;
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
C$.decode$S(ppString);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[coords[this.atomID]]);
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return C$.directionality;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(2).getEncoder$();
var molVolString=Clazz.new_($I$(3,1));
molVolString.append$S("s");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.atomID));
molVolString.append$S(" ");
var coords=Clazz.array(Double.TYPE, -1, [this.center.x, this.center.y, this.center.z]);
molVolString.append$S(encoder.encodeToString$BA($I$(4).doubleArrayToByteArray$DA(coords)));
molVolString.append$S(" ");
molVolString.append$I(this.functionality.getIndex$());
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (encoded) {
var decoder=$I$(2).getDecoder$();
var strings=encoded.split$S(" ");
var id=(Integer.decode$S(strings[1])).$c();
var coords=$I$(4,"byteArrayToDoubleArray$BA",[decoder.decode$BA(strings[2].getBytes$())]);
var c=Clazz.new_($I$(1,1).c$$D$D$D,[coords[0], coords[1], coords[2]]);
var func=null;
var functionalityID=(Integer.valueOf$S(strings[3])).$c();
for (var f, $f = 0, $$f = $I$(5).values$(); $f<$$f.length&&((f=($$f[$f])),1);$f++) {
if (f.getIndex$() == functionalityID) {
func=f;
break;
}}
var sPP=Clazz.new_(C$.c$$I$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality,[id, c, func]);
return sPP;
}, 1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
var sim=0.0;
if (pp.getFunctionalityIndex$() == this.functionality.getIndex$()) sim=1.0;
return sim;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.atomID;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.atomID=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
return;
});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.atomID=map[this.atomID];
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [this.atomID]);
return a;
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_SimplePharmacophorePoint,[this]);
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
return;
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[C$.directionality]);
return directMod;
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
return this.functionality.getIndex$();
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates',  function (pp2, directionalityMod) {
return 1.0;
});

C$.$static$=function(){C$.$static$=0;
C$.directionality=Clazz.new_($I$(1,1).c$$D$D$D,[1.0, 0.0, 0.0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
