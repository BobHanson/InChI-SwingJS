(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.TreeSet','com.actelion.research.chem.Canonizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FastMolecularComplexityCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'assessComplexity$com_actelion_research_chem_StereoMolecule',  function (mol) {
var bondCount=Math.min((mol.getBonds$()/2|0), 7);
if (bondCount < 2) return 0;
mol.ensureHelperArrays$I(63);
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(1,1).c$$I$I);
var fragmentSet=Clazz.new_($I$(2,1));
var atomMap=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
var bondsTouch=Clazz.array(Boolean.TYPE, [mol.getBonds$(), mol.getBonds$()]);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
for (var i=1; i < mol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var bond1=mol.getConnBond$I$I(atom, i);
var bond2=mol.getConnBond$I$I(atom, j);
bondsTouch[bond1][bond2]=true;
bondsTouch[bond2][bond1]=true;
}
}
}
var bondIsMember=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
var maxLevel=bondCount - 2;
var levelBond=Clazz.array(Integer.TYPE, [maxLevel + 1]);
for (var rootBond=0; rootBond < mol.getBonds$(); rootBond++) {
bondIsMember[rootBond]=true;
var level=0;
levelBond[0]=rootBond;
while (true){
var levelBondFound=false;
while (!levelBondFound && levelBond[level] < mol.getBonds$() - 1 ){
++levelBond[level];
if (!bondIsMember[levelBond[level]]) {
for (var bond=rootBond; bond < mol.getBonds$(); bond++) {
if (bondIsMember[bond] && bondsTouch[bond][levelBond[level]] ) {
levelBondFound=true;
break;
}}
}}
if (levelBondFound) {
bondIsMember[levelBond[level]]=true;
if (level == maxLevel) {
mol.copyMoleculeByBonds$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, bondIsMember, true, atomMap);
fragmentSet.add$O(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$());
bondIsMember[levelBond[level]]=false;
} else {
++level;
levelBond[level]=rootBond;
}} else {
if (--level < 0) break;
bondIsMember[levelBond[level]]=false;
}}
bondIsMember[rootBond]=false;
}
return Math.log(fragmentSet.size$()) / bondCount;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
