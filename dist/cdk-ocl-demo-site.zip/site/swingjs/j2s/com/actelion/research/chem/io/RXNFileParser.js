(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'com.actelion.research.chem.reaction.Reaction','java.io.BufferedReader','java.io.StringReader','java.io.InputStreamReader','java.io.FileInputStream','java.nio.charset.StandardCharsets','com.actelion.research.io.BOMSkipper','com.actelion.research.chem.reaction.ReactionEncoder','com.actelion.research.chem.MolfileParser','com.actelion.research.chem.StereoMolecule','StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RXNFileParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getReaction$S',  function (buffer) {
return this.getReaction$S$Z(buffer, false);
});

Clazz.newMeth(C$, 'getReaction$S$Z',  function (buffer, ignoreIdCode) {
var theReaction=Clazz.new_($I$(1,1));
var theReader=Clazz.new_([Clazz.new_($I$(3,1).c$$S,[buffer])],$I$(2,1).c$$java_io_Reader);
this.parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z(theReaction, theReader, ignoreIdCode);
return theReaction;
});

Clazz.newMeth(C$, 'getReaction$java_io_File',  function (file) {
return this.getReaction$java_io_File$Z(file, false);
});

Clazz.newMeth(C$, 'getReaction$java_io_File$Z',  function (file, ignoreIdCode) {
var theReaction=Clazz.new_($I$(1,1));
var theReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(5,1).c$$java_io_File,[file]), $I$(6).UTF_8],$I$(4,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(2,1).c$$java_io_Reader);
$I$(7).skip$java_io_Reader(theReader);
this.parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z(theReaction, theReader, ignoreIdCode);
return theReaction;
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$S',  function (theReaction, buffer) {
return this.parse$com_actelion_research_chem_reaction_Reaction$S$Z(theReaction, buffer, false);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$S$Z',  function (theReaction, buffer, ignoreIdCode) {
var theReader=Clazz.new_([Clazz.new_($I$(3,1).c$$S,[buffer])],$I$(2,1).c$$java_io_Reader);
return this.parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z(theReaction, theReader, ignoreIdCode);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$java_io_File',  function (theReaction, file) {
return this.parse$com_actelion_research_chem_reaction_Reaction$java_io_File$Z(theReaction, file, false);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$java_io_File$Z',  function (theReaction, file, ignoreIdCode) {
var theReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(5,1).c$$java_io_File,[file]), $I$(6).UTF_8],$I$(4,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(2,1).c$$java_io_Reader);
$I$(7).skip$java_io_Reader(theReader);
return this.parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z(theReaction, theReader, ignoreIdCode);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader',  function (theReaction, theReader) {
return this.parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z(theReaction, theReader, false);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z',  function (theReaction, theReader, ignoreIdCode) {
var theLine=theReader.readLine$();
var ok=false;
if ((theLine == null ) || !theLine.startsWith$S("$RXN") ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["\'$RXN\' tag not found"]);
}if (theLine.equals$O("$RXN V3000")) {
ok=p$1.parseV3$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z.apply(this, [theReaction, theReader, ignoreIdCode]);
} else {
ok=p$1.parseV2$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z.apply(this, [theReaction, theReader, ignoreIdCode]);
}return ok;
});

Clazz.newMeth(C$, 'parseV3$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z',  function (theReaction, theReader, ignoreIdCode) {
var name=theReader.readLine$().trim$();
if (name.length$() != 0) theReaction.setName$S(name);
theReader.readLine$();
var comment=theReader.readLine$();
if (!ignoreIdCode && comment.startsWith$S("OCL_RXN_V1.0:") ) {
var encoding=comment.substring$I("OCL_RXN_V1.0:".length$());
if ($I$(8).decode$S$Z$com_actelion_research_chem_reaction_Reaction(encoding, true, theReaction) != null ) return true;
}var theLine=theReader.readLine$();
var molParser=Clazz.new_($I$(9,1));
if (theLine != null  && theLine.startsWith$S("M  V30 COUNTS") ) {
var t=theLine.substring$I(13).trim$();
var p=t.split$S(" ");
var reactantCount=Integer.parseInt$S(p[0]);
var productCount=Integer.parseInt$S(p[1]);
if (reactantCount > 0) {
theLine=theReader.readLine$();
if ("M  V30 BEGIN REACTANT".equals$O(theLine)) {
for (var i=0; i < reactantCount; i++) {
var molecule=Clazz.new_($I$(10,1));
var molfile=Clazz.new_($I$(11,1).c$$I,[32768]);
molfile.append$S("\nActelion Java MolfileCreator 2.0\n\n  0  0  0  0  0  0              0 V3000\n");
do {
theLine=theReader.readLine$();
molfile.append$S(theLine);
molfile.append$S("\n");
} while ((theLine != null ) && !theLine.startsWith$S("M  V30 END CTAB") );
molParser.parse$com_actelion_research_chem_StereoMolecule$StringBuffer(molecule, molfile);
theReaction.addReactant$com_actelion_research_chem_StereoMolecule(molecule);
}
}theLine=theReader.readLine$();
}if (productCount > 0) {
theLine=theReader.readLine$();
if ("M  V30 BEGIN PRODUCT".equals$O(theLine)) {
for (var i=0; i < productCount; i++) {
var molecule=Clazz.new_($I$(10,1));
var molfile=Clazz.new_($I$(11,1).c$$I,[32768]);
molfile.append$S("\nActelion Java MolfileCreator 2.0\n\n  0  0  0  0  0  0              0 V3000\n");
do {
theLine=theReader.readLine$();
molfile.append$S(theLine);
molfile.append$S("\n");
} while ((theLine != null ) && !theLine.startsWith$S("M  V30 END CTAB") );
molParser.parse$com_actelion_research_chem_StereoMolecule$StringBuffer(molecule, molfile);
theReaction.addProduct$com_actelion_research_chem_StereoMolecule(molecule);
}
theLine=theReader.readLine$();
}}return true;
}return false;
}, p$1);

Clazz.newMeth(C$, 'parseV2$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader$Z',  function (theReaction, theReader, ignoreIdCode) {
var name=theReader.readLine$().trim$();
if (name.length$() != 0) theReaction.setName$S(name);
theReader.readLine$();
var comment=theReader.readLine$();
if (!ignoreIdCode && comment.startsWith$S("OCL_RXN_V1.0:") ) {
var encoding=comment.substring$I("OCL_RXN_V1.0:".length$());
if ($I$(8).decode$S$Z$com_actelion_research_chem_reaction_Reaction(encoding, true, theReaction) != null ) return true;
}var theLine=theReader.readLine$();
var reactantCount=Integer.parseInt$S(theLine.substring$I$I(0, 3).trim$());
var productCount=Integer.parseInt$S(theLine.substring$I$I(3, 6).trim$());
var molParser=Clazz.new_($I$(9,1));
for (var i=0; i < reactantCount; i++) {
theLine=theReader.readLine$();
if ((theLine == null ) || !theLine.startsWith$S("$MOL") ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["\'$MOL\' tag not found"]);
}var reactant=Clazz.new_($I$(10,1));
var molfile=Clazz.new_($I$(11,1).c$$I,[32768]);
do {
theLine=theReader.readLine$();
molfile.append$S(theLine);
molfile.append$S("\n");
} while ((theLine != null ) && !theLine.startsWith$S("M  END") );
if (theLine == null ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["\'M  END\' not found"]);
}molParser.parse$com_actelion_research_chem_StereoMolecule$StringBuffer(reactant, molfile);
theReaction.addReactant$com_actelion_research_chem_StereoMolecule(reactant);
}
for (var i=0; i < productCount; i++) {
theLine=theReader.readLine$();
if ((theLine == null ) || !theLine.startsWith$S("$MOL") ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["\'$MOL\' tag not found"]);
}var product=Clazz.new_($I$(10,1));
var molfile=Clazz.new_($I$(11,1).c$$I,[32768]);
do {
theLine=theReader.readLine$();
molfile.append$S(theLine);
molfile.append$S("\n");
} while ((theLine != null ) && !theLine.startsWith$S("M  END") );
if (theLine == null ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["\'M  END\' not found"]);
}molParser.parse$com_actelion_research_chem_StereoMolecule$StringBuffer(product, molfile);
theReaction.addProduct$com_actelion_research_chem_StereoMolecule(product);
}
return true;
}, p$1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:25 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
