(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.transformation.ExponentialMap','java.util.ArrayList','com.actelion.research.chem.alignment3d.transformation.RotationDerivatives','com.actelion.research.chem.phesa.QuickMathCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EvaluableOverlap", null, null, 'com.actelion.research.chem.optimization.Evaluable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['ppWeight'],'O',['shapeAlign','com.actelion.research.chem.phesa.PheSAAlignment','transform','double[]','cachedCoords','com.actelion.research.chem.Coordinates[]','+cachedCoordsPP','origCOM','com.actelion.research.chem.Coordinates','dv0At','double[][]','+dv1At','+dv2At','+dv0PP','+dv1PP','+dv2PP','+results','fitAtGaussModCoords','com.actelion.research.chem.Coordinates[]','+fitPPGaussModCoords']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_PheSAAlignment$DA',  function (shapeAlign, transform) {
C$.c$$com_actelion_research_chem_phesa_PheSAAlignment$DA$D.apply(this, [shapeAlign, transform, 0.5]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_PheSAAlignment$DA$D',  function (shapeAlign, transform, ppWeight) {
;C$.$init$.apply(this);
this.ppWeight=ppWeight;
this.shapeAlign=shapeAlign;
this.transform=transform;
this.fitAtGaussModCoords=Clazz.array($I$(1), [shapeAlign.getMolGauss$().getAtomicGaussians$().size$()]);
this.fitPPGaussModCoords=Clazz.array($I$(1), [shapeAlign.getMolGauss$().getPPGaussians$().size$()]);
this.dv0At=Clazz.array(Double.TYPE, [this.fitAtGaussModCoords.length, 3]);
this.dv1At=Clazz.array(Double.TYPE, [this.fitAtGaussModCoords.length, 3]);
this.dv2At=Clazz.array(Double.TYPE, [this.fitAtGaussModCoords.length, 3]);
this.dv0PP=Clazz.array(Double.TYPE, [this.fitPPGaussModCoords.length, 3]);
this.dv1PP=Clazz.array(Double.TYPE, [this.fitPPGaussModCoords.length, 3]);
this.dv2PP=Clazz.array(Double.TYPE, [this.fitPPGaussModCoords.length, 3]);
this.results=Clazz.array(Double.TYPE, [shapeAlign.getRefMolGauss$().getAtomicGaussians$().size$(), shapeAlign.getRefMolGauss$().getAtomicGaussians$().size$()]);
this.cachedCoords=Clazz.array($I$(1), [shapeAlign.getMolGauss$().getAtomicGaussians$().size$()]);
this.cachedCoordsPP=Clazz.array($I$(1), [shapeAlign.getMolGauss$().getPPGaussians$().size$()]);
this.origCOM=Clazz.new_($I$(1,1));
for (var i=0; i < shapeAlign.getMolGauss$().getAtomicGaussians$().size$(); i++) {
this.cachedCoords[i]=shapeAlign.getMolGauss$().getAtomicGaussians$().get$I(i).center;
}
for (var i=0; i < shapeAlign.getMolGauss$().getPPGaussians$().size$(); i++) {
this.cachedCoordsPP[i]=shapeAlign.getMolGauss$().getPPGaussians$().get$I(i).center;
}
for (var coords, $coords = 0, $$coords = this.cachedCoords; $coords<$$coords.length&&((coords=($$coords[$coords])),1);$coords++) {
this.origCOM.add$com_actelion_research_chem_Coordinates(coords);
}
this.origCOM.scale$D(1.0 / this.cachedCoords.length);
for (var coords, $coords = 0, $$coords = this.cachedCoords; $coords<$$coords.length&&((coords=($$coords[$coords])),1);$coords++) {
coords.sub$com_actelion_research_chem_Coordinates(this.origCOM);
}
for (var coords, $coords = 0, $$coords = this.cachedCoordsPP; $coords<$$coords.length&&((coords=($$coords[$coords])),1);$coords++) {
coords.sub$com_actelion_research_chem_Coordinates(this.origCOM);
}
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_EvaluableOverlap',  function (e) {
;C$.$init$.apply(this);
this.shapeAlign=e.shapeAlign;
this.transform=e.transform;
this.dv0At=e.dv0At;
this.dv1At=e.dv1At;
this.dv2At=e.dv2At;
this.dv0PP=e.dv0PP;
this.dv0PP=e.dv1PP;
this.dv0PP=e.dv2PP;
this.fitAtGaussModCoords=e.fitAtGaussModCoords;
this.fitPPGaussModCoords=e.fitPPGaussModCoords;
this.results=e.results;
}, 1);

Clazz.newMeth(C$, 'getTransformedCoordinates$com_actelion_research_chem_CoordinatesA$java_util_List',  function (modCoords, fitMolGauss) {
var em=Clazz.new_($I$(2,1).c$$D$D$D,[this.transform[0], this.transform[1], this.transform[2]]);
var q=em.toQuaternion$();
var rotMatrix=q.getRotMatrix$().getArray$();
for (var k=0; k < fitMolGauss.size$(); k++) {
var center=Clazz.new_([fitMolGauss.get$I(k).center],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
center.sub$com_actelion_research_chem_Coordinates(this.origCOM);
center.rotate$DAA(rotMatrix);
center.add$com_actelion_research_chem_Coordinates(this.origCOM);
center.x+=this.transform[3];
center.y+=this.transform[4];
center.z+=this.transform[5];
modCoords[k]=center;
}
}, p$1);

Clazz.newMeth(C$, 'setState$DA',  function (transform) {
Clazz.assert(C$, this, function(){return this.transform.length == transform.length});
for (var i=0; i < transform.length; i++) {
this.transform[i]=transform[i];
}
});

Clazz.newMeth(C$, 'getState$DA',  function (v) {
for (var i=0; i < this.transform.length; i++) {
v[i]=this.transform[i];
}
return v;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this.getState$DA(Clazz.array(Double.TYPE, [this.transform.length]));
});

Clazz.newMeth(C$, 'getAlignment$',  function () {
return this.shapeAlign;
});

Clazz.newMeth(C$, 'getFGValue$DA',  function (grad) {
var refMolGauss=this.shapeAlign.getRefMolGauss$();
var fitMolGauss=this.shapeAlign.getMolGauss$();
var value=0.0;
var atomGrad=Clazz.array(Double.TYPE, [grad.length]);
var volumeGaussians=Clazz.new_($I$(3,1));
if (Clazz.instanceOf(refMolGauss, "com.actelion.research.chem.phesa.MolecularVolume")) volumeGaussians=(refMolGauss).getVolumeGaussians$();
value+=(1.0 - this.ppWeight) * p$1.getFGValueOverlap$DA$java_util_List$java_util_List$java_util_List$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA.apply(this, [atomGrad, refMolGauss.getAtomicGaussians$(), fitMolGauss.getAtomicGaussians$(), volumeGaussians, this.dv0At, this.dv1At, this.dv2At, this.fitAtGaussModCoords]);
var ppGrad=Clazz.array(Double.TYPE, [grad.length]);
value+=this.ppWeight * p$1.getFGValueOverlapPP$DA$java_util_List$java_util_List$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA.apply(this, [ppGrad, refMolGauss.getPPGaussians$(), fitMolGauss.getPPGaussians$(), this.dv0PP, this.dv1PP, this.dv2PP, this.fitPPGaussModCoords]);
for (var i=0; i < grad.length; i++) grad[i]=(1.0 - this.ppWeight) * atomGrad[i] + this.ppWeight * ppGrad[i];

return value;
});

Clazz.newMeth(C$, 'getEMapGradient$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA',  function (dRdv0, dRdv1, dRdv2, cachedCoords) {
var v=Clazz.array(Double.TYPE, -1, [this.transform[0], this.transform[1], this.transform[2]]);
var rotationDerivatives=Clazz.new_($I$(4,1).c$$DA,[v]);
var dRdvi_1=Clazz.array(Double.TYPE, [3, 3]);
var dRdvi_2=Clazz.array(Double.TYPE, [3, 3]);
var dRdvi_3=Clazz.array(Double.TYPE, [3, 3]);
rotationDerivatives.dRdv$I$DAA(0, dRdvi_1);
rotationDerivatives.dRdv$I$DAA(1, dRdvi_2);
rotationDerivatives.dRdv$I$DAA(2, dRdvi_3);
for (var a=0; a < cachedCoords.length; a++) {
var xi=cachedCoords[a];
var dRij_dv0=xi.rotateC$DAA(dRdvi_1);
var dRij_dv1=xi.rotateC$DAA(dRdvi_2);
var dRij_dv2=xi.rotateC$DAA(dRdvi_3);
dRdv0[a][0]=dRij_dv0.x;
dRdv0[a][1]=dRij_dv0.y;
dRdv0[a][2]=dRij_dv0.z;
dRdv1[a][0]=dRij_dv1.x;
dRdv1[a][1]=dRij_dv1.y;
dRdv1[a][2]=dRij_dv1.z;
dRdv2[a][0]=dRij_dv2.x;
dRdv2[a][1]=dRij_dv2.y;
dRdv2[a][2]=dRij_dv2.z;
}
}, p$1);

Clazz.newMeth(C$, 'getFGValueOverlap$DA$java_util_List$java_util_List$java_util_List$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA',  function (grad, refMolGauss, fitMolGauss, volGaussians, dRdv0, dRdv1, dRdv2, fitGaussModCoords) {
p$1.getTransformedCoordinates$com_actelion_research_chem_CoordinatesA$java_util_List.apply(this, [fitGaussModCoords, fitMolGauss]);
p$1.getEMapGradient$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA.apply(this, [dRdv0, dRdv1, dRdv2, this.cachedCoords]);
var totalOverlap=0.0;
var fitCenterModCoord;
for (var i=0; i < refMolGauss.size$(); i++) {
var refAt=refMolGauss.get$I(i);
for (var j=0; j < fitMolGauss.size$(); j++) {
var atomOverlap=0.0;
var fitAt=fitMolGauss.get$I(j);
fitCenterModCoord=fitGaussModCoords[j];
var alphaSum=refAt.getWidth$() + fitAt.getWidth$();
var dx=refAt.getCenter$().x - fitCenterModCoord.x;
var dy=refAt.getCenter$().y - fitCenterModCoord.y;
var dz=refAt.getCenter$().z - fitCenterModCoord.z;
var Rij2=dx * dx + dy * dy + dz * dz;
if (Rij2 >= 10.0 ) continue;
atomOverlap=refAt.getHeight$() * fitAt.getHeight$() * $I$(5).getInstance$().quickExp$D(-(refAt.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(5).getInstance$().getPrefactor$I$I(refAt.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
totalOverlap+=atomOverlap;
var gradientPrefactor=atomOverlap * -2 * refAt.getWidth$() * fitAt.getWidth$()  / (refAt.getWidth$() + fitAt.getWidth$());
var dv0=dRdv0[j][0] * dx + dRdv0[j][1] * dy + dRdv0[j][2] * dz;
var dv1=dRdv1[j][0] * dx + dRdv1[j][1] * dy + dRdv1[j][2] * dz;
var dv2=dRdv2[j][0] * dx + dRdv2[j][1] * dy + dRdv2[j][2] * dz;
grad[0]+=gradientPrefactor * dv0;
grad[1]+=gradientPrefactor * dv1;
grad[2]+=gradientPrefactor * dv2;
grad[3]+=gradientPrefactor * dx;
grad[4]+=gradientPrefactor * dy;
grad[5]+=gradientPrefactor * dz;
}}
}
for (var k=0; k < volGaussians.size$(); k++) {
var refVol=volGaussians.get$I(k);
for (var j=0; j < fitMolGauss.size$(); j++) {
var atomOverlap=0.0;
var fitAt=fitMolGauss.get$I(j);
fitCenterModCoord=fitGaussModCoords[j];
var alphaSum=refVol.getWidth$() + fitAt.getWidth$();
var dx=refVol.getCenter$().x - fitCenterModCoord.x;
var dy=refVol.getCenter$().y - fitCenterModCoord.y;
var dz=refVol.getCenter$().z - fitCenterModCoord.z;
var Rij2=dx * dx + dy * dy + dz * dz;
if (Rij2 >= 10.0 ) continue;
atomOverlap=refVol.getRole$() * refVol.getHeight$() * fitAt.getHeight$() * $I$(5).getInstance$().quickExp$D(-(refVol.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(5).getInstance$().getPrefactor$I$I(refVol.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (Math.abs(atomOverlap) > 0.0 ) {
totalOverlap+=atomOverlap;
var gradientPrefactor=atomOverlap * -2 * refVol.getWidth$() * fitAt.getWidth$()  / (refVol.getWidth$() + fitAt.getWidth$());
var dv0=dRdv0[j][0] * dx + dRdv0[j][1] * dy + dRdv0[j][2] * dz;
var dv1=dRdv1[j][0] * dx + dRdv1[j][1] * dy + dRdv1[j][2] * dz;
var dv2=dRdv2[j][0] * dx + dRdv2[j][1] * dy + dRdv2[j][2] * dz;
grad[0]+=gradientPrefactor * dv0;
grad[1]+=gradientPrefactor * dv1;
grad[2]+=gradientPrefactor * dv2;
grad[3]+=gradientPrefactor * dx;
grad[4]+=gradientPrefactor * dy;
grad[5]+=gradientPrefactor * dz;
}}
}
return (-1.0 * totalOverlap);
}, p$1);

Clazz.newMeth(C$, 'getFGValueOverlapPP$DA$java_util_List$java_util_List$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA',  function (grad, refMolGauss, fitMolGauss, dRdv0, dRdv1, dRdv2, fitGaussModCoords) {
p$1.getTransformedCoordinates$com_actelion_research_chem_CoordinatesA$java_util_List.apply(this, [fitGaussModCoords, fitMolGauss]);
p$1.getEMapGradient$DAA$DAA$DAA$com_actelion_research_chem_CoordinatesA.apply(this, [dRdv0, dRdv1, dRdv2, this.cachedCoordsPP]);
var totalOverlap=0.0;
var fitCenterModCoord;
for (var i=0; i < refMolGauss.size$(); i++) {
var refAt=refMolGauss.get$I(i);
for (var j=0; j < fitMolGauss.size$(); j++) {
var fitAt=fitMolGauss.get$I(j);
var atomOverlap=0.0;
fitCenterModCoord=fitGaussModCoords[j];
var alphaSum=refAt.getWidth$() + fitAt.getWidth$();
var dx=refAt.getCenter$().x - fitCenterModCoord.x;
var dy=refAt.getCenter$().y - fitCenterModCoord.y;
var dz=refAt.getCenter$().z - fitCenterModCoord.z;
var Rij2=dx * dx + dy * dy + dz * dz;
if (Rij2 >= 10.0 ) {
continue;
}atomOverlap=refAt.getWeight$() * refAt.getHeight$() * fitAt.getHeight$() * $I$(5).getInstance$().quickExp$D(-(refAt.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(5).getInstance$().getPrefactor$I$I(refAt.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
var sim=refAt.getInteractionSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian(fitAt);
if (sim == 0.0 ) continue;
atomOverlap*=sim;
totalOverlap+=atomOverlap;
var gradientPrefactor=atomOverlap * -2 * refAt.getWidth$() * fitAt.getWidth$()  / (refAt.getWidth$() + fitAt.getWidth$());
var dv0=dRdv0[j][0] * dx + dRdv0[j][1] * dy + dRdv0[j][2] * dz;
var dv1=dRdv1[j][0] * dx + dRdv1[j][1] * dy + dRdv1[j][2] * dz;
var dv2=dRdv2[j][0] * dx + dRdv2[j][1] * dy + dRdv2[j][2] * dz;
grad[0]+=gradientPrefactor * dv0;
grad[1]+=gradientPrefactor * dv1;
grad[2]+=gradientPrefactor * dv2;
grad[3]+=gradientPrefactor * dx;
grad[4]+=gradientPrefactor * dy;
grad[5]+=gradientPrefactor * dz;
}}
}
return (-1.0 * totalOverlap);
}, p$1);

Clazz.newMeth(C$, 'clone$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_EvaluableOverlap,[this]);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
