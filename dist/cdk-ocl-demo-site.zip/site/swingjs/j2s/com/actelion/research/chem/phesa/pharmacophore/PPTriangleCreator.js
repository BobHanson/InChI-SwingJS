(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore"),I$=[[0,'java.util.ArrayList','java.util.HashMap','com.actelion.research.chem.phesa.pharmacophore.PPTriangle']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPTriangleCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'create$java_util_List$com_actelion_research_chem_Coordinates',  function (ppGaussians, com) {
var pharmacophorePoints=Clazz.new_($I$(1,1));
for (var ppGaussian, $ppGaussian = ppGaussians.iterator$(); $ppGaussian.hasNext$()&&((ppGaussian=($ppGaussian.next$())),1);) pharmacophorePoints.add$O(ppGaussian.getPharmacophorePoint$());

pharmacophorePoints.sort$java_util_Comparator(((P$.PPTriangleCreator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PPTriangleCreator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint','compare$O$O'],  function (p1, p2) /*block*/{
var f1=p1.getFunctionalityIndex$.apply(p1, []);
var f2=p2.getFunctionalityIndex$.apply(p2, []);
return Integer.compare$I$I(f1, f2);
});
})()
), Clazz.new_(P$.PPTriangleCreator$lambda1.$init$,[this, null])));
var toSkip=Clazz.new_($I$(1,1));
var n=pharmacophorePoints.size$();
var distMat=Clazz.array(Double.TYPE, [n, n]);
for (var i=0; i < n; i++) {
var pp1=pharmacophorePoints.get$I(i);
for (var j=i + 1; j < n; j++) {
var pp2=pharmacophorePoints.get$I(j);
distMat[i][j]=pp1.getCenter$().distance$com_actelion_research_chem_Coordinates(pp2.getCenter$());
if (distMat[i][j] < 0.01 ) toSkip.add$O(Integer.valueOf$I(j));
}
}
var triangle;
var triangles=Clazz.new_($I$(2,1));
var counter=0;
for (var i=0; i < n && counter < 1000 ; i++) {
if (toSkip.contains$O(Integer.valueOf$I(i))) continue;
var pp1=pharmacophorePoints.get$I(i);
for (var j=i + 1; j < n; j++) {
if (toSkip.contains$O(Integer.valueOf$I(j))) continue;
var pp2=pharmacophorePoints.get$I(j);
for (var k=j + 1; k < n; k++) {
if (toSkip.contains$O(Integer.valueOf$I(k))) continue;
var pp3=pharmacophorePoints.get$I(k);
var d12=distMat[i][j];
var d13=distMat[i][k];
var d23=distMat[j][k];
if (d12 < 2.5  || d13 < 2.5   || d23 < 2.5  ) continue;
triangle=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$D$D$D$com_actelion_research_chem_Coordinates,[pp1, pp2, pp3, d12, d13, d23, com]);
++counter;
var key=triangle.getHash$();
if (triangles.containsKey$O(Integer.valueOf$I(key))) triangles.get$O(Integer.valueOf$I(key)).add$O(triangle);
 else {
var triangleList=Clazz.new_($I$(1,1));
triangleList.add$O(triangle);
triangles.put$O$O(Integer.valueOf$I(key), triangleList);
}}
}
}
return triangles;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
