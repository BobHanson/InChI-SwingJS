(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.phesa.pharmacophore.pp.ChargePoint','java.util.Arrays','java.util.Collection','java.util.stream.Collectors']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChargedGroupDetector");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','chargedGroups','java.util.List','ringCollection','com.actelion.research.chem.RingCollection']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
this.chargedGroups=Clazz.new_($I$(1,1));
this.ringCollection=mol.getRingSet$();
}, 1);

Clazz.newMeth(C$, 'detect$',  function () {
var chargePoints=Clazz.new_($I$(1,1));
for (var r=0; r < this.ringCollection.getSize$(); r++) {
var tetrazole=Clazz.new_($I$(1,1));
var totCharge=0;
var ringAtoms=this.ringCollection.getRingAtoms$I(r);
for (var atom, $atom = 0, $$atom = ringAtoms; $atom<$$atom.length&&((atom=new Integer($$atom[$atom])),1);$atom++) {
if (p$1.alreadyDetected$I.apply(this, [(atom).$c()])) continue;
if (this.mol.getAtomicNo$I((atom).$c()) == 7 && this.mol.isAromaticAtom$I((atom).$c())  && this.mol.getConnAtoms$I((atom).$c()) <= 2 ) {
tetrazole.add$O(atom);
totCharge+=this.mol.getAtomCharge$I((atom).$c());
}}
if (tetrazole.size$() == 4 && totCharge < 0 ) {
this.chargedGroups.add$O(tetrazole);
var cp=Clazz.new_([this.mol, (tetrazole.get$I(0)).$c(), $I$(3,"asList$OA",[Clazz.array(Integer, -1, [tetrazole.get$I(1), tetrazole.get$I(2), tetrazole.get$I(3)])]), totCharge],$I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I);
chargePoints.add$O(cp);
}}
for (var a=0; a < this.mol.getAtoms$(); a++) {
if (p$1.alreadyDetected$I.apply(this, [a])) continue;
if (this.mol.getAtomicNo$I(a) == 8) {
if (this.mol.getConnAtoms$I(a) == 0) continue;
var aa=this.mol.getConnAtom$I$I(a, 0);
if (p$1.alreadyDetected$I.apply(this, [aa])) continue;
var cp=C$.isPartOfChargedAcid$com_actelion_research_chem_StereoMolecule$I(this.mol, a);
if (cp == null ) continue;
chargePoints.add$O(cp);
var group=Clazz.new_($I$(1,1));
group.add$O(Integer.valueOf$I(cp.getChargeAtom$()));
group.addAll$java_util_Collection(cp.getNeighbours$());
this.chargedGroups.add$O(group);
} else if (this.mol.getAtomicNo$I(a) == 7) {
var carbonCenter=-1;
var charge=0;
var neighbours=Clazz.new_($I$(1,1));
if (!this.mol.isAromaticAtom$I(a) && this.mol.getConnAtoms$I(a) <= 2 ) {
neighbours.add$O(Integer.valueOf$I(a));
charge+=this.mol.getAtomCharge$I(a);
var nDBs=0;
for (var i=0; i < this.mol.getConnAtoms$I(a); i++) {
var aa=this.mol.getConnAtom$I$I(a, i);
if (p$1.alreadyDetected$I.apply(this, [aa])) continue;
if (this.mol.getAtomicNo$I(aa) == 6) {
carbonCenter=aa;
charge+=this.mol.getAtomCharge$I(aa);
if (this.mol.getBondOrder$I(this.mol.getBond$I$I(a, aa)) == 2) ++nDBs;
for (var j=0; j < this.mol.getConnAtoms$I(aa); j++) {
var aaa=this.mol.getConnAtom$I$I(aa, j);
if (this.mol.isAromaticAtom$I(aaa)) continue;
if (aaa == a) continue;
if (p$1.alreadyDetected$I.apply(this, [aaa])) continue;
if (this.mol.getAtomicNo$I(aaa) == 7 && this.mol.getConnAtoms$I(aaa) <= 2 ) {
neighbours.add$O(Integer.valueOf$I(aaa));
charge+=this.mol.getAtomCharge$I(aaa);
if (this.mol.getBondOrder$I(this.mol.getBond$I$I(aa, aaa)) == 2) ++nDBs;
}}
}}
if (nDBs > 1 && charge > 0 ) {
var cp=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[this.mol, carbonCenter, neighbours, charge]);
chargePoints.add$O(cp);
var group=Clazz.new_($I$(1,1));
group.add$O(Integer.valueOf$I(cp.getChargeAtom$()));
group.addAll$java_util_Collection(cp.getNeighbours$());
this.chargedGroups.add$O(group);
}}}if (p$1.alreadyDetected$I.apply(this, [a])) continue;
 else {
var charge=this.mol.getAtomCharge$I(a);
if (charge != 0 && !p$1.hasCounterChargedNeighbour$I.apply(this, [a]) ) {
charge=charge > 0 ? 1 : -1;
var cp=Clazz.new_([this.mol, a, Clazz.new_($I$(1,1)), charge],$I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I);
chargePoints.add$O(cp);
var group=Clazz.new_($I$(1,1));
group.add$O(Integer.valueOf$I(a));
this.chargedGroups.add$O(group);
}}}
return chargePoints;
});

Clazz.newMeth(C$, 'getChargedGroups$',  function () {
return this.chargedGroups;
});

Clazz.newMeth(C$, 'hasCounterChargedNeighbour$I',  function (a) {
for (var aa=0; aa < this.mol.getConnAtoms$I(a); aa++) {
if (this.mol.getAtomCharge$I(a) * this.mol.getAtomCharge$I(this.mol.getConnAtom$I$I(a, aa)) < 0) return true;
}
return false;
}, p$1);

Clazz.newMeth(C$, 'alreadyDetected$I',  function (a) {
var isDetected=this.chargedGroups.stream$().flatMap$java_util_function_Function((function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "ChargedGroupDetector$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.stream$.apply(t,[])});
})()
)); return Clazz.new_(P$.ChargedGroupDetector$lambda1.$init$,[this, null])})($I$(4))).collect$java_util_stream_Collector($I$(5).toList$()).contains$O(Integer.valueOf$I(a)) ? true : false;
return isDetected;
}, p$1);

Clazz.newMeth(C$, 'isPartOfChargedAcid$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 8 || mol.getConnAtoms$I(atom) != 1  || mol.getConnBondOrder$I$I(atom, 0) != 1 ) return null;
var connAtom=mol.getConnAtom$I$I(atom, 0);
if (mol.getAtomicNo$I(connAtom) == 6) {
var neighbours=Clazz.new_($I$(1,1));
neighbours.add$O(Integer.valueOf$I(atom));
var charge=0;
charge+=mol.getAtomCharge$I(atom);
charge+=mol.getAtomCharge$I(connAtom);
var nConnected2C=mol.getConnAtoms$I(connAtom);
for (var i=0; i < nConnected2C; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) {
continue;
}if (mol.getAtomicNo$I(indexAtom) != 8) {
continue;
}charge+=mol.getAtomCharge$I(indexAtom);
neighbours.add$O(Integer.valueOf$I(indexAtom));
}
if (charge < 0) {
var cp=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[mol, connAtom, neighbours, charge]);
return cp;
}} else if (mol.getAtomicNo$I(connAtom) == 16) {
var nConnected2S=mol.getConnAtoms$I(connAtom);
var neighbours=Clazz.new_($I$(1,1));
neighbours.add$O(Integer.valueOf$I(atom));
var charge=0;
charge+=mol.getAtomCharge$I(atom);
charge+=mol.getAtomCharge$I(connAtom);
for (var i=0; i < nConnected2S; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) continue;
if (mol.getAtomicNo$I(indexAtom) != 8) continue;
charge+=mol.getAtomCharge$I(indexAtom);
neighbours.add$O(Integer.valueOf$I(indexAtom));
}
if (charge < 0) {
var cp=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[mol, connAtom, neighbours, charge]);
return cp;
}} else if (mol.getAtomicNo$I(connAtom) == 15) {
var nConnected2P=mol.getConnAtoms$I(connAtom);
var neighbours=Clazz.new_($I$(1,1));
neighbours.add$O(Integer.valueOf$I(atom));
var charge=0;
charge+=mol.getAtomCharge$I(atom);
charge+=mol.getAtomCharge$I(connAtom);
for (var i=0; i < nConnected2P; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) continue;
if (mol.getAtomicNo$I(indexAtom) != 8) continue;
charge+=mol.getAtomCharge$I(indexAtom);
neighbours.add$O(Integer.valueOf$I(indexAtom));
}
if (charge < 0) {
var cp=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I,[mol, connAtom, neighbours, charge]);
return cp;
}}return null;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
