(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'com.actelion.research.chem.prediction.IncrementTableWithIndex','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.SSSearcherWithIndex']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DruglikenessPredictorWithIndex");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['sInitialized'],'O',['sIncrementTable','com.actelion.research.chem.prediction.IncrementTableWithIndex','sFragmentList','com.actelion.research.chem.StereoMolecule[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
{
if (!C$.sInitialized) {
try {
C$.sIncrementTable=Clazz.new_($I$(1,1).c$$S,["/resources/druglikeness.txt"]);
C$.sFragmentList=Clazz.array($I$(2), [C$.sIncrementTable.getSize$()]);
for (var i=0; i < C$.sIncrementTable.getSize$(); i++) C$.sFragmentList[i]=Clazz.new_($I$(3,1).c$$Z,[false]).getCompactMolecule$S(C$.sIncrementTable.getFragment$I(i));

C$.sInitialized=true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Unable to initialize DruglikenessPredictor");
} else {
throw e;
}
}
}}}, 1);

Clazz.newMeth(C$, 'assessDruglikeness$com_actelion_research_chem_StereoMolecule$JA$com_actelion_research_calc_ThreadMaster',  function (mol, index, threadMaster) {
if (!C$.sInitialized) return -999.0;
var nastyIncrementSum=0.0;
var incrementSum=0.0;
var fragmentCount=0;
var swi=Clazz.new_($I$(4,1).c$$I,[1]);
swi.setMolecule$com_actelion_research_chem_StereoMolecule$JA(mol, index);
for (var i=0; i < C$.sIncrementTable.getSize$(); i++) {
if (threadMaster != null  && threadMaster.threadMustDie$() ) return -999.0;
swi.setFragment$com_actelion_research_chem_StereoMolecule$JA(C$.sFragmentList[i], C$.sIncrementTable.getIndex$I(i));
if (swi.isFragmentInMolecule$()) {
var increment=C$.sIncrementTable.getIncrement$I(i);
if (increment < -1 ) nastyIncrementSum+=increment;
 else {
incrementSum+=increment;
++fragmentCount;
}}}
if (fragmentCount == 0) return -1;
var druglikeness=nastyIncrementSum + incrementSum / Math.sqrt(fragmentCount);
druglikeness=druglikeness + 0.0625 * (fragmentCount - 40);
return druglikeness;
});

C$.$static$=function(){C$.$static$=0;
C$.sInitialized=false;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
