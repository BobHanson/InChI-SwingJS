(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),p$1={},I$=[[0,'com.actelion.research.chem.PeriodicTable']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuickMathCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['precalcExp','double[]','precalcPrefactors','double[][]']]
,['O',['sInstance','com.actelion.research.chem.phesa.QuickMathCalculator']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.precalculatePrefactors.apply(this, []);
p$1.precalculateExp.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.sInstance == null ) {
{
if (C$.sInstance == null ) {
C$.sInstance=Clazz.new_(C$);
}}}return C$.sInstance;
}, 1);

Clazz.newMeth(C$, 'precalculatePrefactors',  function () {
this.precalcPrefactors=Clazz.array(Double.TYPE, [54, 54]);
for (var i=1; i < 54; i++) {
for (var j=1; j < 54; j++) {
var vdwR1=$I$(1).getElement$I(i).getVDWRadius$();
var vdwR2=$I$(1).getElement$I(j).getVDWRadius$();
var alphaSum=2.41798793102 / (vdwR1 * vdwR1) + 2.41798793102 / (vdwR2 * vdwR2);
this.precalcPrefactors[i][j]=Math.pow((3.141592653589793 / alphaSum), 1.5);
}
}
}, p$1);

Clazz.newMeth(C$, 'precalculateExp',  function () {
this.precalcExp=Clazz.array(Double.TYPE, [1000]);
for (var i=0; i < 1000; i++) {
this.precalcExp[i]=Math.exp(-i * 0.01);
}
}, p$1);

Clazz.newMeth(C$, 'quickExp$D',  function (c) {
var index=-1 * ((c * 100)|0);
var exp1=this.precalcExp[index];
var exp2=this.precalcExp[index + 1];
var f=-c * 100 - index;
var exp=exp1 + f * (exp2 - exp1);
return exp;
});

Clazz.newMeth(C$, 'getPrefactor$I$I',  function (a1, a2) {
return this.precalcPrefactors[a1][a2];
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
