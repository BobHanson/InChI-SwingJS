(function(){var P$=Clazz.newPackage("com.actelion.research.chem.potentialenergy"),I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionTerm']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionConstraint", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['targetValueMin','targetValueMax'],'O',['conf','com.actelion.research.chem.conf.Conformer','torsionAtoms','int[]']]
,['D',['FORCE_CONSTANT']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$IA$D$D',  function (conf, torsionAtoms, targetValue, width) {
;C$.$init$.apply(this);
this.conf=conf;
this.torsionAtoms=torsionAtoms;
this.targetValueMin=2 * 3.141592653589793 * (targetValue - width)  / 360.0;
this.targetValueMax=2 * 3.141592653589793 * (targetValue + width)  / 360.0;
if (this.targetValueMin < 0.0 ) this.targetValueMin+=6.283185307179586;
if (this.targetValueMax < 0.0 ) this.targetValueMax=6.283185307179586;
}, 1);

Clazz.newMeth(C$, 'computeDihedralTerm$D',  function (dihedral) {
var dihedralTarget=dihedral;
if (!(dihedral > this.targetValueMin  && dihedral < this.targetValueMax  ) && !(dihedral > this.targetValueMin  && this.targetValueMin > this.targetValueMax  ) && !(dihedral < this.targetValueMax  && this.targetValueMin > this.targetValueMax  )  ) {
var minDihedralTarget=dihedral - this.targetValueMin;
var maxDihedralTarget=dihedral - this.targetValueMax;
dihedralTarget=(Math.abs(minDihedralTarget) < Math.abs(maxDihedralTarget)  ? this.targetValueMin : this.targetValueMax);
}var dihedralTerm=dihedral - dihedralTarget;
return dihedralTerm;
});

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var a1=this.torsionAtoms[0];
var a2=this.torsionAtoms[1];
var a3=this.torsionAtoms[2];
var a4=this.torsionAtoms[3];
var c1=this.conf.getCoordinates$I(a1);
var c2=this.conf.getCoordinates$I(a2);
var c3=this.conf.getCoordinates$I(a3);
var c4=this.conf.getCoordinates$I(a4);
var dihedral=$I$(1).getDihedral$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates(c1, c2, c3, c4);
if (dihedral < 0.0 ) dihedral+=6.283185307179586;
var dihedralTerm=this.computeDihedralTerm$D(dihedral);
var e=0.5 * dihedralTerm * dihedralTerm * C$.FORCE_CONSTANT ;
var dEdPhi=C$.FORCE_CONSTANT * dihedralTerm;
$I$(2,"getCartesianTorsionGradient$IA$com_actelion_research_chem_conf_Conformer$DA$D$com_actelion_research_chem_CoordinatesA$IAA",[this.torsionAtoms, this.conf, gradient, dEdPhi, Clazz.array($I$(1), -1, [c1, c2, c3, c4]), null]);
return e;
});

C$.$static$=function(){C$.$static$=0;
C$.FORCE_CONSTANT=50.0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
