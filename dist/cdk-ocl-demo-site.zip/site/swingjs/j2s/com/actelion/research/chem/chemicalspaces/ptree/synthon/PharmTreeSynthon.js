(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.ptree.synthon"),p$1={},I$=[[0,'java.util.HashMap','com.actelion.research.chem.descriptor.pharmacophoretree.DescriptorHandlerPTree','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.Canonizer','com.actelion.research.chem.Molecule','java.util.ArrayList','java.util.HashSet','java.util.Arrays','java.util.stream.Collectors','com.actelion.research.chem.StereoMolecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmTreeSynthon");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['idcode','pharmTreeEncoded','id'],'O',['connectorLabels','java.util.Map','dhp','com.actelion.research.chem.descriptor.pharmacophoretree.DescriptorHandlerPTree','idcParser','com.actelion.research.chem.IDCodeParser']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.connectorLabels=Clazz.new_($I$(1,1));
this.dhp=Clazz.new_($I$(2,1));
this.idcParser=Clazz.new_($I$(3,1));
p$1.process$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
}, 1);

Clazz.newMeth(C$, 'process$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getCanMolecule$Z(true);
mol.ensureHelperArrays$I(15);
for (var a=0; a < mol.getAtoms$(); a++) {
if (mol.getAtomicNo$I(a) >= 92) {
this.connectorLabels.put$O$O(mol.getAtomLabel$I(a), Integer.valueOf$I(a));
}}
this.idcode=mol.getIDCode$();
}, p$1);

Clazz.newMeth(C$, 'getLinkerNoFromConnectorLabel$S',  function (label) {
return $I$(5).getAtomicNoFromLabel$S(label) + 1 - 92;
});

Clazz.newMeth(C$, 'getConnectorLabels$',  function () {
return this.connectorLabels;
});

Clazz.newMeth(C$, 'getPharmTree$',  function () {
return this.dhp.decode$S(this.pharmTreeEncoded);
});

Clazz.newMeth(C$, 'setPharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (pTree) {
this.pharmTreeEncoded=this.dhp.encode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(pTree);
});

Clazz.newMeth(C$, 'getStructure$',  function () {
return this.idcParser.getCompactMolecule$S(this.idcode);
});

Clazz.newMeth(C$, 'createMinimalSynthon$',  function () {
var synthon=this.getStructure$();
var connectorAtoms=Clazz.new_([this.connectorLabels.values$()],$I$(6,1).c$$java_util_Collection);
return this.cutConnectorPaths$com_actelion_research_chem_StereoMolecule$java_util_List(synthon, connectorAtoms);
});

Clazz.newMeth(C$, 'cutConnectorPaths$com_actelion_research_chem_StereoMolecule$java_util_List',  function (synthon, connectorAtoms) {
var combis=Clazz.new_($I$(6,1));
for (var i=0; i < connectorAtoms.size$(); i++) {
for (var j=i + 1; j < connectorAtoms.size$(); j++) {
combis.add$O(Clazz.array(Integer.TYPE, -1, [(connectorAtoms.get$I(i)).valueOf(), (connectorAtoms.get$I(j)).valueOf()]));
}
}
var includedAtoms=Clazz.new_($I$(7,1));
var maxPathLength=50;
if (combis.size$() == 0) {
var connectorAtom=(connectorAtoms.get$I(0)).$c();
includedAtoms.add$O(Integer.valueOf$I(connectorAtom));
includedAtoms.add$O(Integer.valueOf$I(synthon.getConnAtom$I$I(connectorAtom, 0)));
} else {
for (var combi, $combi = combis.iterator$(); $combi.hasNext$()&&((combi=($combi.next$())),1);) {
var pathAtoms=Clazz.array(Integer.TYPE, [50]);
$I$(8).fill$IA$I(pathAtoms, -1);
synthon.getPath$IA$I$I$I$ZA(pathAtoms, combi[0], combi[1], maxPathLength, null);
includedAtoms.addAll$java_util_Collection($I$(8).stream$IA(pathAtoms).boxed$().filter$java_util_function_Predicate((P$.PharmTreeSynthon$lambda1$||(P$.PharmTreeSynthon$lambda1$=(((P$.PharmTreeSynthon$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthon$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$Integer','test$O'],  function (e) { return ((e).$c() >= 0 );});
})()
), Clazz.new_(P$.PharmTreeSynthon$lambda1.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(9).toList$()));
includedAtoms.add$O(Integer.valueOf$I(combi[0]));
includedAtoms.add$O(Integer.valueOf$I(combi[1]));
}
}var isAtomIncluded=Clazz.array(Boolean.TYPE, [synthon.getAtoms$()]);
for (var a=0; a < synthon.getAtoms$(); a++) {
if (includedAtoms.contains$O(Integer.valueOf$I(a))) isAtomIncluded[a]=true;
}
var minimalSynthon=Clazz.new_($I$(10,1));
synthon.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(minimalSynthon, isAtomIncluded, true, null);
return minimalSynthon;
});

Clazz.newMeth(C$, 'getId$',  function () {
return this.id;
});

Clazz.newMeth(C$, 'setId$S',  function (id) {
this.id=id;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:22 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
