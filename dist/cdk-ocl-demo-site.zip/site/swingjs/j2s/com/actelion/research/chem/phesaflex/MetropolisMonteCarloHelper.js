(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesaflex"),I$=[[0,'com.actelion.research.chem.conf.BondRotationHelper','java.util.Random','com.actelion.research.chem.conf.TorsionDB','java.util.ArrayList','java.util.stream.IntStream','com.actelion.research.chem.conf.TorsionRelevanceHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MetropolisMonteCarloHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.seed=1234;
},1);

C$.$fields$=[['D',['rmax','rmin','previousAngle','slope'],'I',['previousBond'],'J',['seed'],'O',['mol','com.actelion.research.chem.StereoMolecule','torsionRelevance','float[]','rotatableBonds','int[]','random','java.util.Random','bondRotationHelper','com.actelion.research.chem.conf.BondRotationHelper']]
,['D',['MAX_ANGLE','MIN_ANGLE','TEMPERATURE']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
}, 1);

Clazz.newMeth(C$, 'init$',  function () {
var success=true;
this.bondRotationHelper=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[this.mol]);
this.random=Clazz.new_($I$(2,1).c$$J,[this.seed]);
var isRotatableBond=Clazz.array(Boolean.TYPE, [this.mol.getBonds$()]);
$I$(3).findRotatableBonds$com_actelion_research_chem_StereoMolecule$Z$ZA(this.mol, true, isRotatableBond);
var rotBonds=Clazz.new_($I$(4,1));
$I$(5).range$I$I(0, isRotatableBond.length).forEach$java_util_function_IntConsumer(((P$.MetropolisMonteCarloHelper$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "MetropolisMonteCarloHelper$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) /*block*/{
if (this.$finals$.isRotatableBond[e]) this.$finals$.rotBonds.add$O.apply(this.$finals$.rotBonds, [Integer.valueOf$I(e)]);
});
})()
), Clazz.new_(P$.MetropolisMonteCarloHelper$lambda1.$init$,[this, {isRotatableBond:isRotatableBond,rotBonds:rotBonds}])));
this.rotatableBonds=rotBonds.stream$().mapToInt$java_util_function_ToIntFunction((P$.MetropolisMonteCarloHelper$lambda2$||(P$.MetropolisMonteCarloHelper$lambda2$=(((P$.MetropolisMonteCarloHelper$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "MetropolisMonteCarloHelper$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (i) { return ((i).$c());});
})()
), Clazz.new_(P$.MetropolisMonteCarloHelper$lambda2.$init$,[this, null])))))).toArray$();
this.torsionRelevance=$I$(6).getRelevance$com_actelion_research_chem_StereoMolecule$ZA(this.mol, isRotatableBond);
this.rmin=3.4028235E38;
this.rmax=0.0;
for (var relevance, $relevance = 0, $$relevance = this.torsionRelevance; $relevance<$$relevance.length&&((relevance=($$relevance[$relevance])),1);$relevance++) {
if (relevance < this.rmin ) this.rmin=relevance;
if (relevance > this.rmax ) this.rmax=relevance;
}
this.slope=(C$.MIN_ANGLE - C$.MAX_ANGLE) / (this.rmax - this.rmin);
if (this.rotatableBonds.length == 0) success=false;
return success;
});

Clazz.newMeth(C$, 'step$',  function () {
var prefactor=this.random.nextInt$I(2) < 1 ? -1 : 1;
this.previousBond=this.rotatableBonds[this.random.nextInt$I(this.rotatableBonds.length)];
this.previousAngle=C$.MAX_ANGLE + (this.torsionRelevance[this.previousBond] - this.rmin) * this.slope;
this.previousAngle*=prefactor;
this.bondRotationHelper.rotateSmallerSide$I$D(this.previousBond, this.previousAngle);
});

Clazz.newMeth(C$, 'undoStep$',  function () {
this.bondRotationHelper.rotateSmallerSide$I$D(this.previousBond, -this.previousAngle);
});

Clazz.newMeth(C$, 'accept$D$D',  function (oldScore, newScore) {
var accept=false;
if (newScore > oldScore ) accept=true;
 else {
var delta=-(newScore - oldScore);
var p=Math.exp(-delta / C$.TEMPERATURE);
var rnd=this.random.nextDouble$();
if (rnd < p ) accept=true;
}return accept;
});

C$.$static$=function(){C$.$static$=0;
C$.MAX_ANGLE=1.0471975511965976;
C$.MIN_ANGLE=0.08726646259971647;
C$.TEMPERATURE=0.0043;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
