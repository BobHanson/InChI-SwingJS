(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ModelSolutionSimilarity", null, 'com.actelion.research.util.graph.complete.SolutionCompleteGraph');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrSimilarityNodes','float[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_util_graph_complete_SolutionCompleteGraph$FA',  function (scg, arrSimilarityNodes) {
Clazz.super_(C$, this);
C$.superclazz.prototype.copyIntoThis$com_actelion_research_util_graph_complete_AMemorizedObject.apply(this, [scg]);
this.arrSimilarityNodes=arrSimilarityNodes;
}, 1);

Clazz.newMeth(C$, 'getSimilarityNode$I',  function (index) {
return this.arrSimilarityNodes[index];
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
