(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','StringBuilder',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExitVectorPoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['coreAtom','exitAtom','connectionID'],'O',['directionality','com.actelion.research.chem.Coordinates','+center']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, c, e) {
;C$.$init$.apply(this);
this.coreAtom=c;
this.exitAtom=e;
this.connectionID=Integer.parseInt$S(mol.getAtomCustomLabel$I(e));
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
p$1.decode$S$com_actelion_research_chem_StereoMolecule.apply(this, [ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_ExitVectorPoint',  function (eP) {
;C$.$init$.apply(this);
this.coreAtom=eP.coreAtom;
this.exitAtom=eP.exitAtom;
this.directionality=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[eP.directionality]);
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[eP.center]);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.center=Clazz.new_($I$(1,1).c$$D$D$D,[coords[this.coreAtom].x, coords[this.coreAtom].y, coords[this.coreAtom].z]);
this.directionality=coords[this.exitAtom].subC$com_actelion_research_chem_Coordinates(coords[this.coreAtom]);
this.directionality.scale$D(1.0 / this.directionality.getLength$());
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(1,1));
directMod.x=this.directionality.x * rotMatrix[0][0] + this.directionality.y * rotMatrix[1][0] + this.directionality.z * rotMatrix[2][0];
directMod.y=this.directionality.x * rotMatrix[0][1] + this.directionality.y * rotMatrix[1][1] + this.directionality.z * rotMatrix[2][1];
directMod.z=this.directionality.x * rotMatrix[0][2] + this.directionality.y * rotMatrix[1][2] + this.directionality.z * rotMatrix[2][2];
directMod.scale$D(scaleFactor);
return directMod;
});

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return this.directionality;
});

Clazz.newMeth(C$, 'encode$',  function () {
var molVolString=Clazz.new_($I$(2,1));
molVolString.append$S("e");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.coreAtom));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.exitAtom));
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var strings=ppString.split$S(" ");
this.coreAtom=(Integer.decode$S(strings[1])).$c();
this.exitAtom=(Integer.decode$S(strings[2])).$c();
this.connectionID=Integer.parseInt$S(mol.getAtomCustomLabel$I(this.exitAtom));
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, p$1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
if (Clazz.instanceOf(pp, "com.actelion.research.chem.phesa.pharmacophore.pp.ExitVectorPoint")) {
return 1.0;
}return 0.0;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.coreAtom;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.coreAtom=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
this.directionality=directionality;
});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.coreAtom=map[this.coreAtom];
this.exitAtom=map[this.exitAtom];
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [this.coreAtom, this.exitAtom]);
return a;
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_ExitVectorPoint,[this]);
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
grad[3 * this.exitAtom]=sim * di.x / 3.0;
grad[3 * this.exitAtom + 1]=sim * di.y / 3.0;
grad[3 * this.exitAtom + 2]=sim * di.z / 3.0;
grad[3 * this.coreAtom]=sim * -di.x / 3.0;
grad[3 * this.coreAtom + 1]=sim * -di.y / 3.0;
grad[3 * this.coreAtom + 2]=sim * -di.z / 3.0;
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
return $I$(3).EXIT_VECTOR.getIndex$();
});

Clazz.newMeth(C$, 'getConnectionID$',  function () {
return this.connectionID;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
