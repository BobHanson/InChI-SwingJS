(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'java.util.HashSet','java.util.ArrayList','com.actelion.research.chem.SSSearcher',['com.actelion.research.chem.mcs.MCS','.ComparatorBitsSet'],'java.util.HashMap','com.actelion.research.chem.StereoMolecule','com.actelion.research.util.datamodel.IntVec','java.util.Collections','com.actelion.research.chem.ExtendedMoleculeFunctions','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MCS", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ComparatorBitsSet',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.excluded=null;
},1);

C$.$fields$=[['Z',['considerAromaticRings','considerRings'],'O',['mol','com.actelion.research.chem.StereoMolecule','+frag','hsIndexFragCandidates','java.util.HashSet','+hsIndexFragGarbage','+hsIndexFragSolution','sss','com.actelion.research.chem.SSSearcher','comparatorBitsSet','com.actelion.research.chem.mcs.MCS.ComparatorBitsSet','molMCS','com.actelion.research.chem.StereoMolecule','liMCSSolutions','java.util.List','hmRingBnd_ListRingBnds','java.util.HashMap','+hmAromaticRingBnd_ListRingBnds','ringCollection','com.actelion.research.chem.RingCollection','excluded','boolean[]','arrMatchListFrag2Mol','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I$com_actelion_research_chem_SSSearcher.apply(this, [0, null]);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (ringStatus) {
C$.c$$I$com_actelion_research_chem_SSSearcher.apply(this, [ringStatus, null]);
}, 1);

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_SSSearcher',  function (ringStatus, searcher) {
;C$.$init$.apply(this);
this.considerRings=false;
this.considerAromaticRings=false;
switch (ringStatus) {
case 0:
break;
case 1:
this.considerRings=true;
break;
case 2:
this.considerAromaticRings=true;
break;
default:
break;
}
this.hsIndexFragCandidates=Clazz.new_($I$(1,1).c$$I,[1200]);
this.hsIndexFragGarbage=Clazz.new_($I$(1,1).c$$I,[1200]);
this.hsIndexFragSolution=Clazz.new_($I$(1,1).c$$I,[1200]);
this.liMCSSolutions=Clazz.new_($I$(2,1).c$$I,[1200]);
if (searcher == null ) this.sss=Clazz.new_($I$(3,1));
 else this.sss=searcher;
this.comparatorBitsSet=Clazz.new_($I$(4,1));
this.hmRingBnd_ListRingBnds=Clazz.new_($I$(5,1));
this.hmAromaticRingBnd_ListRingBnds=Clazz.new_($I$(5,1));
}, 1);

Clazz.newMeth(C$, 'setSSSearcher$com_actelion_research_chem_SSSearcher',  function (sss) {
this.sss=sss;
});

Clazz.newMeth(C$, 'set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (mol, frag) {
this.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$ZA(mol, frag, null);
});

Clazz.newMeth(C$, 'set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$ZA',  function (mol, frag, excluded) {
var fragBiggestSub=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule,[frag]);
fragBiggestSub.ensureHelperArrays$I(7);
fragBiggestSub.stripSmallFragments$();
fragBiggestSub.ensureHelperArrays$I(7);
this.mol=mol;
this.frag=fragBiggestSub;
this.excluded=excluded;
p$1.init.apply(this, []);
});

Clazz.newMeth(C$, 'init',  function () {
this.hsIndexFragCandidates.clear$();
this.hsIndexFragGarbage.clear$();
this.hsIndexFragSolution.clear$();
this.liMCSSolutions.clear$();
this.hmRingBnd_ListRingBnds.clear$();
this.hmAromaticRingBnd_ListRingBnds.clear$();
p$1.initCandidates.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'initCandidates',  function () {
this.ringCollection=this.frag.getRingSet$();
var rings=this.ringCollection.getSize$();
for (var i=0; i < rings; i++) {
var arrIndexBnd=this.ringCollection.getRingBonds$I(i);
for (var j=0; j < arrIndexBnd.length; j++) {
if (!this.hmRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(arrIndexBnd[j]))) {
this.hmRingBnd_ListRingBnds.put$O$O(Integer.valueOf$I(arrIndexBnd[j]), Clazz.new_($I$(2,1)));
}var li=this.hmRingBnd_ListRingBnds.get$O(Integer.valueOf$I(arrIndexBnd[j]));
li.add$O(arrIndexBnd);
}
if (this.ringCollection.isAromatic$I(i)) {
for (var j=0; j < arrIndexBnd.length; j++) {
if (!this.hmAromaticRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(arrIndexBnd[j]))) {
this.hmAromaticRingBnd_ListRingBnds.put$O$O(Integer.valueOf$I(arrIndexBnd[j]), Clazz.new_($I$(2,1)));
}var li=this.hmAromaticRingBnd_ListRingBnds.get$O(Integer.valueOf$I(arrIndexBnd[j]));
li.add$O(arrIndexBnd);
}
}}
var nInts=(((this.frag.getBonds$() / 32) + (0.96875))|0);
for (var i=0; i < this.frag.getBonds$(); i++) {
var iv=Clazz.new_($I$(7,1).c$$I,[nInts]);
p$1.setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec.apply(this, [i, iv]);
this.hsIndexFragCandidates.add$O(iv);
}
}, p$1);

Clazz.newMeth(C$, 'setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec',  function (bit, iv) {
if (!this.considerAromaticRings && !this.considerRings ) {
iv.setBit$I(bit);
} else if (this.considerRings) {
iv.setBit$I(bit);
if (this.hmRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(bit))) {
var li=this.hmRingBnd_ListRingBnds.get$O(Integer.valueOf$I(bit));
for (var i=0; i < li.size$(); i++) {
var a=li.get$I(i);
for (var j=0; j < a.length; j++) {
iv.setBit$I(a[j]);
}
}
}} else if (this.considerAromaticRings) {
iv.setBit$I(bit);
if (this.hmAromaticRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(bit))) {
var li=this.hmAromaticRingBnd_ListRingBnds.get$O(Integer.valueOf$I(bit));
for (var i=0; i < li.size$(); i++) {
var a=li.get$I(i);
for (var j=0; j < a.length; j++) {
iv.setBit$I(a[j]);
}
}
}}iv.calculateHashCode$();
}, p$1);

Clazz.newMeth(C$, 'getAllSolutionsForCommonSubstructures',  function () {
this.sss.setMolecule$com_actelion_research_chem_StereoMolecule(this.mol);
this.frag.setFragment$Z(true);
this.sss.setFragment$com_actelion_research_chem_StereoMolecule(this.frag);
try {
if (this.sss.findFragmentInMolecule$I$I$ZA(4, 4, this.excluded) > 0) {
this.molMCS=this.frag;
var liIndexFragCandidates=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
if (liIndexFragCandidates != null  && !liIndexFragCandidates.isEmpty$() ) {
var iv=liIndexFragCandidates.get$I(0);
iv.setBits$I$I(0, iv.sizeBits$());
iv.calculateHashCode$();
var li=Clazz.new_($I$(2,1));
li.add$O(iv);
return li;
}}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
var maxSizeCandidates=0;
while (!this.hsIndexFragCandidates.isEmpty$()){
var liIndexFragCandidates=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
$I$(8).sort$java_util_List$java_util_Comparator(liIndexFragCandidates, this.comparatorBitsSet);
var iv=liIndexFragCandidates.get$I(liIndexFragCandidates.size$() - 1);
this.hsIndexFragCandidates.remove$O(iv);
if (false) {
System.out.println$S("Bits set " + iv.getBitsSet$());
if (iv.getBitsSet$() == this.frag.getBonds$()) {
System.out.println$S("Full structure in iv.");
}}var fragSub=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, iv);
this.sss.setFragment$com_actelion_research_chem_StereoMolecule(fragSub);
if (this.sss.findFragmentInMolecule$I$I$ZA(4, 8, this.excluded) > 0) {
this.hsIndexFragSolution.add$O(iv);
p$1.removeAllSubSolutions$com_actelion_research_util_datamodel_IntVec.apply(this, [iv]);
if (iv.getBitsSet$() != this.frag.getBonds$()) {
var liIV=p$1.getAllPlusOneAtomCombinations$com_actelion_research_util_datamodel_IntVec$com_actelion_research_chem_StereoMolecule.apply(this, [iv, this.frag]);
for (var ivPlus, $ivPlus = liIV.iterator$(); $ivPlus.hasNext$()&&((ivPlus=($ivPlus.next$())),1);) {
if (false) {
if (ivPlus.getBitsSet$() == this.frag.getBonds$()) {
System.out.println$S("Full structure in ivPlus.");
}}if ((!this.hsIndexFragGarbage.contains$O(ivPlus)) && (!this.hsIndexFragSolution.contains$O(ivPlus)) ) {
this.hsIndexFragCandidates.add$O(ivPlus);
}}
if (false) {
System.out.println$S("tsIndexFragCandidates " + this.hsIndexFragCandidates.size$());
}}if (maxSizeCandidates < this.hsIndexFragCandidates.size$()) {
maxSizeCandidates=this.hsIndexFragCandidates.size$();
}} else {
this.hsIndexFragGarbage.add$O(iv);
}}
if (this.hsIndexFragSolution.size$() == 0) {
return null;
}return C$.getFinalSolutionSet$java_util_HashSet(this.hsIndexFragSolution);
}, p$1);

Clazz.newMeth(C$, 'getAllCommonSubstructures$',  function () {
var liIndexFragSolution=p$1.getAllSolutionsForCommonSubstructures.apply(this, []);
if (liIndexFragSolution == null ) {
return null;
}$I$(8).sort$java_util_List$java_util_Comparator(liIndexFragSolution, this.comparatorBitsSet);
var ivMCS=liIndexFragSolution.get$I(liIndexFragSolution.size$() - 1);
this.molMCS=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, ivMCS);
var li=Clazz.new_($I$(2,1));
for (var iv, $iv = liIndexFragSolution.iterator$(); $iv.hasNext$()&&((iv=($iv.next$())),1);) {
li.add$O(C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, iv));
}
return $I$(9).removeSubStructures$java_util_List(li);
});

Clazz.newMeth(C$, 'getMCS$',  function () {
var liIndexFragSolution=p$1.getAllSolutionsForCommonSubstructures.apply(this, []);
if (liIndexFragSolution == null ) {
return null;
}$I$(8).sort$java_util_List$java_util_Comparator(liIndexFragSolution, this.comparatorBitsSet);
var ivMCS=liIndexFragSolution.get$I(liIndexFragSolution.size$() - 1);
this.molMCS=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, ivMCS);
return this.molMCS;
});

Clazz.newMeth(C$, 'getMCSBondArray$ZA$ZA',  function (arrBondMCSMol, arrBondFrag) {
var arrBondMol_Result=Clazz.array(Boolean.TYPE, [2, null]);
var liIndexFragSolution=p$1.getAllSolutionsForCommonSubstructures.apply(this, []);
if (liIndexFragSolution == null ) {
return null;
}$I$(8).sort$java_util_List$java_util_Comparator(liIndexFragSolution, this.comparatorBitsSet);
var ivMCSLargest=liIndexFragSolution.get$I(liIndexFragSolution.size$() - 1);
var bonds=this.frag.getBonds$();
if (arrBondFrag == null ) {
arrBondFrag=Clazz.array(Boolean.TYPE, [bonds]);
} else {
$I$(10).fill$ZA$Z(arrBondFrag, false);
}for (var i=0; i < bonds; i++) {
if (ivMCSLargest.isBitSet$I(i)) {
arrBondFrag[i]=true;
}}
var fragSub=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, ivMCSLargest);
this.sss.setFragment$com_actelion_research_chem_StereoMolecule(fragSub);
this.arrMatchListFrag2Mol=null;
if (this.sss.findFragmentInMolecule$I$I$ZA(4, 8, this.excluded) > 0) {
var liMatchSubFrag2Mol=this.sss.getMatchList$();
this.arrMatchListFrag2Mol=p$1.getMappedMatchListFrag2Mol$com_actelion_research_chem_StereoMolecule$IA.apply(this, [fragSub, liMatchSubFrag2Mol.get$I(0)]);
var bondsMol=this.mol.getBonds$();
if (arrBondMCSMol == null ) {
arrBondMCSMol=Clazz.array(Boolean.TYPE, [bondsMol]);
} else {
$I$(10).fill$ZA$Z(arrBondMCSMol, false);
}p$1.getBondArrayMolecule$IA$ZA$ZA.apply(this, [this.arrMatchListFrag2Mol, arrBondFrag, arrBondMCSMol]);
}arrBondMol_Result[0]=arrBondMCSMol;
arrBondMol_Result[1]=arrBondFrag;
return arrBondMol_Result;
});

Clazz.newMeth(C$, 'getArrMatchListFrag2Mol$',  function () {
return this.arrMatchListFrag2Mol;
});

Clazz.newMeth(C$, 'getMappedMatchListFrag2Mol$com_actelion_research_chem_StereoMolecule$IA',  function (fragSub, arrMatchListSubFrag2Mol) {
var arrMatchListFrag2Mol=Clazz.array(Integer.TYPE, [this.frag.getAtoms$()]);
this.sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(fragSub, this.frag);
this.sss.findFragmentInMolecule$I$I$ZA(4, 8, null);
var liMatchSubFrag2Mol=this.sss.getMatchList$();
var arrMatchListSubFrag2Frag=liMatchSubFrag2Mol.get$I(0);
var hmIndexSubFrag_IndexFrag=Clazz.new_($I$(5,1));
for (var i=0; i < arrMatchListSubFrag2Frag.length; i++) {
hmIndexSubFrag_IndexFrag.put$O$O(Integer.valueOf$I(i), Integer.valueOf$I(arrMatchListSubFrag2Frag[i]));
}
for (var i=0; i < arrMatchListSubFrag2Mol.length; i++) {
var indexAtSubFragment=i;
var indexAtFragment=(hmIndexSubFrag_IndexFrag.get$O(Integer.valueOf$I(indexAtSubFragment))).$c();
arrMatchListFrag2Mol[indexAtFragment]=arrMatchListSubFrag2Mol[indexAtSubFragment];
}
return arrMatchListFrag2Mol;
}, p$1);

Clazz.newMeth(C$, 'getBondArrayMolecule$IA$ZA$ZA',  function (arrMatchFragment2Mol, arrBondMCSFrag, arrBondMCSMol) {
for (var i=0; i < arrMatchFragment2Mol.length; i++) {
var indexAtFrag=i;
var indexAtMol=arrMatchFragment2Mol[i];
var nConn2Frag=this.frag.getConnAtoms$I(indexAtFrag);
for (var j=0; j < nConn2Frag; j++) {
var indexAtFragConn=this.frag.getConnAtom$I$I(indexAtFrag, j);
var indexBondFrag=this.frag.getBond$I$I(indexAtFrag, indexAtFragConn);
if (arrBondMCSFrag[indexBondFrag]) {
var indexAtMolConn=arrMatchFragment2Mol[indexAtFragConn];
var indexBondMol=this.mol.getBond$I$I(indexAtMol, indexAtMolConn);
if (indexBondMol > -1) {
arrBondMCSMol[indexBondMol]=true;
}}}
}
return arrBondMCSMol;
}, p$1);

Clazz.newMeth(C$, 'getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec',  function (frag, iv) {
var isFragmentAtom=Clazz.array(Boolean.TYPE, [frag.getAtoms$()]);
var atoms=0;
var bonds=frag.getBonds$();
for (var bond=0; bond < bonds; bond++) {
if (iv.isBitSet$I(bond)) {
for (var i=0; i < 2; i++) {
var atom=frag.getBondAtom$I$I(i, bond);
if (!isFragmentAtom[atom]) {
isFragmentAtom[atom]=true;
++atoms;
}}
}}
var fragSubBonds=Clazz.new_($I$(6,1).c$$I$I,[atoms, bonds]);
fragSubBonds.setFragment$Z(true);
frag.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragSubBonds, isFragmentAtom, true, null);
fragSubBonds.ensureHelperArrays$I(7);
return fragSubBonds;
}, 1);

Clazz.newMeth(C$, 'getAllPlusOneAtomCombinations$com_actelion_research_util_datamodel_IntVec$com_actelion_research_chem_StereoMolecule',  function (iv, frag) {
var bonds=frag.getBonds$();
var liIntVec=Clazz.new_($I$(2,1));
var hsAtomIndex=Clazz.new_($I$(1,1));
for (var i=0; i < bonds; i++) {
if (iv.isBitSet$I(i)) {
var indexAt1=frag.getBondAtom$I$I(0, i);
var indexAt2=frag.getBondAtom$I$I(1, i);
hsAtomIndex.add$O(Integer.valueOf$I(indexAt1));
hsAtomIndex.add$O(Integer.valueOf$I(indexAt2));
}}
for (var i=0; i < bonds; i++) {
if (!iv.isBitSet$I(i)) {
var indexAt1=frag.getBondAtom$I$I(0, i);
var indexAt2=frag.getBondAtom$I$I(1, i);
if (hsAtomIndex.contains$O(Integer.valueOf$I(indexAt1)) || hsAtomIndex.contains$O(Integer.valueOf$I(indexAt2)) ) {
var ivPlus=Clazz.new_([iv.get$()],$I$(7,1).c$$IA);
p$1.setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec.apply(this, [i, ivPlus]);
liIntVec.add$O(ivPlus);
}}}
return liIntVec;
}, p$1);

Clazz.newMeth(C$, 'removeAllSubSolutions$com_actelion_research_util_datamodel_IntVec',  function (ivSolution) {
var liIndexFragSolution=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
for (var ivCandidate, $ivCandidate = liIndexFragSolution.iterator$(); $ivCandidate.hasNext$()&&((ivCandidate=($ivCandidate.next$())),1);) {
if (C$.isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate)) {
this.hsIndexFragCandidates.remove$O(ivCandidate);
}}
}, p$1);

Clazz.newMeth(C$, 'getFinalSolutionSet$java_util_HashSet',  function (hsIndexFragSolution) {
var liIndexFragSolution=Clazz.new_($I$(2,1).c$$java_util_Collection,[hsIndexFragSolution]);
for (var i=liIndexFragSolution.size$() - 1; i >= 0; i--) {
var ivCandidate=liIndexFragSolution.get$I(i);
for (var j=0; j < liIndexFragSolution.size$(); j++) {
var ivSolution=liIndexFragSolution.get$I(j);
if (i != j) {
if (C$.isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate)) {
liIndexFragSolution.remove$I(i);
break;
}}}
}
return liIndexFragSolution;
}, 1);

Clazz.newMeth(C$, 'isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec',  function (ivSolution, ivCandidate) {
var iv=$I$(7).OR$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate);
if (iv.equals$O(ivSolution)) {
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'getScore$',  function () {
var sc=0;
var nBndsFrag=this.frag.getBonds$();
var nBndsMol=this.mol.getBonds$();
var nBndsMCS=this.molMCS.getBonds$();
sc=nBndsMCS / Math.max(nBndsFrag, nBndsMol);
return sc;
});

Clazz.newMeth(C$, 'isConsiderAromaticRings$',  function () {
return this.considerAromaticRings;
});

Clazz.newMeth(C$, 'isConsiderRings$',  function () {
return this.considerRings;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.MCS, "ComparatorBitsSet", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec','compare$O$O'],  function (iv1, iv2) {
var bits1=iv1.getBitsSet$();
var bits2=iv2.getBitsSet$();
if (bits1 > bits2) {
return 1;
} else if (bits1 < bits2) {
return -1;
}return 0;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
