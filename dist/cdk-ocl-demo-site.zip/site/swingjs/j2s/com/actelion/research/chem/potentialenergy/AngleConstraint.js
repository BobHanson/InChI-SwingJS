(function(){var P$=Clazz.newPackage("com.actelion.research.chem.potentialenergy"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AngleConstraint", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['targetValue'],'O',['conf','com.actelion.research.chem.conf.Conformer','angleAtoms','int[]']]
,['D',['FORCE_CONSTANT']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$IA$D',  function (conf, angleAtoms, targetAngle) {
;C$.$init$.apply(this);
this.conf=conf;
this.angleAtoms=angleAtoms;
this.targetValue=2 * 3.141592653589793 * targetAngle  / 360.0;
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var a1=this.angleAtoms[0];
var a2=this.angleAtoms[1];
var a3=this.angleAtoms[2];
var c1=this.conf.getCoordinates$I(a1);
var c2=this.conf.getCoordinates$I(a2);
var c3=this.conf.getCoordinates$I(a3);
var r0=c1.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var r1=c3.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var dist0=c2.distance$com_actelion_research_chem_Coordinates(c1);
var dist1=c3.distance$com_actelion_research_chem_Coordinates(c2);
var cosTheta=r0.cosAngle$com_actelion_research_chem_Coordinates(r1);
var sinThetaSq=1.0 - cosTheta * cosTheta;
var sinTheta=1.0E-8;
if (sinThetaSq > 0.0 ) sinTheta=Math.sqrt(sinThetaSq);
var angleTerm=Math.acos(cosTheta) - this.targetValue;
var dEdTheta=C$.FORCE_CONSTANT * angleTerm;
var dCos_dS=Clazz.array(Double.TYPE, -1, [1.0 / dist0 * (r1.x - cosTheta * r0.x), 1.0 / dist0 * (r1.y - cosTheta * r0.y), 1.0 / dist0 * (r1.z - cosTheta * r0.z), 1.0 / dist1 * (r0.x - cosTheta * r1.x), 1.0 / dist1 * (r0.y - cosTheta * r1.y), 1.0 / dist1 * (r0.z - cosTheta * r1.z)]);
gradient[3 * a1]+=dEdTheta * dCos_dS[0] / (-sinTheta);
gradient[3 * a1 + 1]+=dEdTheta * dCos_dS[1] / (-sinTheta);
gradient[3 * a1 + 2]+=dEdTheta * dCos_dS[2] / (-sinTheta);
gradient[3 * a2]+=dEdTheta * (-dCos_dS[0] - dCos_dS[3]) / (-sinTheta);
gradient[3 * a2 + 1]+=dEdTheta * (-dCos_dS[1] - dCos_dS[4]) / (-sinTheta);
gradient[3 * a2 + 2]+=dEdTheta * (-dCos_dS[2] - dCos_dS[5]) / (-sinTheta);
gradient[3 * a3]+=dEdTheta * dCos_dS[3] / (-sinTheta);
gradient[3 * a3 + 1]+=dEdTheta * dCos_dS[4] / (-sinTheta);
gradient[3 * a3 + 2]+=dEdTheta * dCos_dS[5] / (-sinTheta);
return 0.5 * C$.FORCE_CONSTANT * angleTerm * angleTerm ;
});

C$.$static$=function(){C$.$static$=0;
C$.FORCE_CONSTANT=50.0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
