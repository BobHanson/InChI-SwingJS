(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Isotope");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['absoluteMass','percentage'],'I',['neutrones']]]

Clazz.newMeth(C$, 'c$$I$D$D',  function (neutrones, absoluteMass, percentage) {
;C$.$init$.apply(this);
this.neutrones=neutrones;
this.absoluteMass=absoluteMass;
this.percentage=percentage;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:21 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
