(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','StringBuilder',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DonorPoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['donorAtom','donorHydrogen','interactionClass'],'O',['directionality','com.actelion.research.chem.Coordinates','+center']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, d, h, interactionClass) {
;C$.$init$.apply(this);
this.donorAtom=d;
this.donorHydrogen=h;
this.interactionClass=interactionClass;
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
p$1.decode$S$com_actelion_research_chem_StereoMolecule.apply(this, [ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_DonorPoint',  function (dP) {
;C$.$init$.apply(this);
this.donorAtom=dP.donorAtom;
this.donorHydrogen=dP.donorHydrogen;
this.directionality=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[dP.directionality]);
this.interactionClass=dP.interactionClass;
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[dP.center]);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.center=Clazz.new_($I$(1,1).c$$D$D$D,[coords[this.donorHydrogen].x, coords[this.donorHydrogen].y, coords[this.donorHydrogen].z]);
this.directionality=coords[this.donorHydrogen].subC$com_actelion_research_chem_Coordinates(coords[this.donorAtom]);
this.directionality.scale$D(1.0 / this.directionality.getLength$());
});

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return this.directionality;
});

Clazz.newMeth(C$, 'encode$',  function () {
var molVolString=Clazz.new_($I$(2,1));
molVolString.append$S("d");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.donorAtom));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.donorHydrogen));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.interactionClass));
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var strings=ppString.split$S(" ");
this.donorAtom=(Integer.decode$S(strings[1])).$c();
this.donorHydrogen=(Integer.decode$S(strings[2])).$c();
this.interactionClass=(Integer.decode$S(strings[3])).$c();
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, p$1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
if (Clazz.instanceOf(pp, "com.actelion.research.chem.phesa.pharmacophore.pp.DonorPoint")) {
return 1.0;
}return 0.0;
});

Clazz.newMeth(C$, 'getInteractionClass$',  function () {
return this.interactionClass;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.donorHydrogen;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.donorHydrogen=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
this.directionality=directionality;
});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.donorAtom=map[this.donorAtom];
this.donorHydrogen=map[this.donorHydrogen];
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [this.donorAtom, this.donorHydrogen]);
return a;
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_DonorPoint,[this]);
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(1,1));
directMod=this.directionality.rotateC$DAA(rotMatrix);
directMod.scale$D(scaleFactor);
return directMod;
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
grad[3 * this.donorHydrogen]=sim * di.x / 3.0;
grad[3 * this.donorHydrogen + 1]=sim * di.y / 3.0;
grad[3 * this.donorHydrogen + 2]=sim * di.z / 3.0;
grad[3 * this.donorAtom]=sim * -di.x / 3.0;
grad[3 * this.donorAtom + 1]=sim * -di.y / 3.0;
grad[3 * this.donorAtom + 2]=sim * -di.z / 3.0;
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
return $I$(3).DONOR.getIndex$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
