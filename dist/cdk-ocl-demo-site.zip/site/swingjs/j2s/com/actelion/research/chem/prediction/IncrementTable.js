(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'java.util.ArrayList','java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets','com.actelion.research.chem.prediction.IncrementTableRecord']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IncrementTable");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mRecords','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mRecords=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (filename) {
;C$.$init$.apply(this);
var theReader=Clazz.new_([Clazz.new_([this.getClass$().getResourceAsStream$S(filename), $I$(4).UTF_8],$I$(3,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(2,1).c$$java_io_Reader);
this.mRecords=Clazz.new_($I$(1,1));
while (true){
var theLine=theReader.readLine$();
if (theLine == null ) break;
var tabPosition=theLine.indexOf$I("\t");
if (tabPosition == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["line without TAB"]);
var idcode=theLine.substring$I$I(0, tabPosition);
var increment=Double.valueOf$S(theLine.substring$I(tabPosition + 1)).doubleValue$();
this.mRecords.add$O(Clazz.new_($I$(5,1).c$$S$D,[idcode, increment]));
}
theReader.close$();
}, 1);

Clazz.newMeth(C$, 'addElement$S$D',  function (idcode, increment) {
this.mRecords.add$O(Clazz.new_($I$(5,1).c$$S$D,[idcode, increment]));
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.mRecords.size$();
});

Clazz.newMeth(C$, 'getFragment$I',  function (i) {
return this.mRecords.get$I(i).mIDCode;
});

Clazz.newMeth(C$, 'getIncrement$I',  function (i) {
return this.mRecords.get$I(i).mIncrement;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
