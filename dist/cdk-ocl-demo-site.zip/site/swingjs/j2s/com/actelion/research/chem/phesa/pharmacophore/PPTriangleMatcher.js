(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.alignment3d.transformation.TransformationSequence',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.AlignmentResult']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPTriangleMatcher");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getMatchingTransforms$java_util_Map$java_util_Map$I$I',  function (triangleSetRef, triangleSetFit, refConformerId, conformerId) {
return C$.getMatchingTransforms$java_util_Map$java_util_Map$I$I$Z(triangleSetRef, triangleSetFit, refConformerId, conformerId, true);
}, 1);

Clazz.newMeth(C$, 'getMatchingTransforms$java_util_Map$java_util_Map$I$I$Z',  function (triangleSetRef, triangleSetFit, refConformerId, conformerId, useDirectionality) {
var cutoff=0.3;
if (!useDirectionality) cutoff=0.6;
var results=Clazz.new_($I$(1,1));
for (var tHash, $tHash = triangleSetRef.keySet$().iterator$(); $tHash.hasNext$()&&((tHash=($tHash.next$()).intValue$()),1);) {
if (!triangleSetFit.containsKey$O(Integer.valueOf$I(tHash))) continue;
var fitTriangles=triangleSetFit.get$O(Integer.valueOf$I(tHash));
var refTriangles=triangleSetRef.get$O(Integer.valueOf$I(tHash));
for (var refTriangle, $refTriangle = refTriangles.iterator$(); $refTriangle.hasNext$()&&((refTriangle=($refTriangle.next$())),1);) {
for (var fitTriangle, $fitTriangle = fitTriangles.iterator$(); $fitTriangle.hasNext$()&&((fitTriangle=($fitTriangle.next$())),1);) {
if (C$.doEdgeLengthsMatch$com_actelion_research_chem_phesa_pharmacophore_PPTriangle$com_actelion_research_chem_phesa_pharmacophore_PPTriangle(refTriangle, fitTriangle)) {
var transform=Clazz.new_($I$(2,1));
var score=refTriangle.getMatchingTransform$com_actelion_research_chem_phesa_pharmacophore_PPTriangle$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z(fitTriangle, transform, useDirectionality);
if (score > cutoff ) results.add$O(Clazz.new_($I$(3,1).c$$D$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$I$I,[score, transform, refConformerId, conformerId]));
}}
}
}
return results;
}, 1);

Clazz.newMeth(C$, 'doEdgeLengthsMatch$com_actelion_research_chem_phesa_pharmacophore_PPTriangle$com_actelion_research_chem_phesa_pharmacophore_PPTriangle',  function (triangle1, triangle2) {
var d1=triangle1.getEdgeLengths$();
var d2=triangle2.getEdgeLengths$();
if (Math.abs(d1[0] - d2[0]) < 2.0  && Math.abs(d1[1] - d2[1]) < 2.0   && Math.abs(d1[2] - d2[2]) < 2.0  ) {
return true;
} else return false;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
