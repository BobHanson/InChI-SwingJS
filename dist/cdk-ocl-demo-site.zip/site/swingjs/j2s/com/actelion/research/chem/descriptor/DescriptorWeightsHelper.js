(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','java.util.Arrays','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorWeightsHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['creatorMolDistHistViz','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.creatorMolDistHistViz=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'calcWeightLabelsFlexophore$com_actelion_research_chem_Molecule3D',  function (molecule3D) {
var liSubGraphIndices=this.creatorMolDistHistViz.getSubGraphIndices$com_actelion_research_chem_Molecule3D(molecule3D);
var weights=C$.calcWeightLabels$java_util_List$com_actelion_research_chem_Molecule3D(liSubGraphIndices, molecule3D);
return weights;
});

Clazz.newMeth(C$, 'calcWeightLabels$java_util_List$com_actelion_research_chem_Molecule3D',  function (liSubGraphIndices, molecule3D) {
var weights=C$.getBasisWeightLabels$com_actelion_research_chem_Molecule3D(molecule3D);
for (var i=0; i < liSubGraphIndices.size$(); i++) {
var sgi=liSubGraphIndices.get$I(i);
var indexWeight=1;
if ($I$(2).isLinker$com_actelion_research_chem_StereoMolecule$java_util_List$I(molecule3D, liSubGraphIndices, i)) {
if (!$I$(2).isOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(molecule3D, sgi)) {
indexWeight=2;
}if ($I$(2).isCharged$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(molecule3D, sgi)) {
indexWeight=2;
}} else {
indexWeight=2;
}for (var atomIndex, $atomIndex = 0, $$atomIndex = sgi.getAtomIndices$(); $atomIndex<$$atomIndex.length&&((atomIndex=($$atomIndex[$atomIndex])),1);$atomIndex++) {
weights[atomIndex]=indexWeight;
}
}
return weights;
}, 1);

Clazz.newMeth(C$, 'getBasisWeightLabels$com_actelion_research_chem_Molecule3D',  function (molecule3D) {
var weights=Clazz.array(Integer.TYPE, [molecule3D.getAtoms$()]);
$I$(3).fill$IA$I(weights, 1);
return weights;
}, 1);

Clazz.newMeth(C$, 'mergeWeightLabels$IA$IA',  function (arrWeightLabel, arrWeightLabelUser) {
if (arrWeightLabel.length != arrWeightLabelUser.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Weight labels differ in size!"]);
}var arrWeightLabelMerged=Clazz.array(Integer.TYPE, [arrWeightLabel.length]);
for (var i=0; i < arrWeightLabel.length; i++) {
var label=arrWeightLabel[i];
if (arrWeightLabelUser[i] == 0) {
label=arrWeightLabelUser[i];
} else if (arrWeightLabel[i] == 2 && arrWeightLabelUser[i] == 2 ) {
label=3;
} else if (arrWeightLabelUser[i] == 2) {
label=3;
}arrWeightLabelMerged[i]=label;
}
return arrWeightLabelMerged;
}, 1);

Clazz.newMeth(C$, 'toStringWeightLabels$IA',  function (weightLabels) {
var weightBuilder=Clazz.new_($I$(4,1));
for (var weightLabel, $weightLabel = 0, $$weightLabel = weightLabels; $weightLabel<$$weightLabel.length&&((weightLabel=($$weightLabel[$weightLabel])),1);$weightLabel++) {
weightBuilder.append$C(String.fromCharCode((48 + weightLabel)));
}
return weightBuilder.toString();
}, 1);

Clazz.newMeth(C$, 'parseSingleDigitString$S',  function (s) {
if (s == null ) return null;
var arr=Clazz.array(Integer.TYPE, [s.length$()]);
for (var i=0; i < s.length$(); i++) {
var c=Integer.parseInt$S(Character.toString$C(s.charAt$I(i)));
arr[i]=c;
}
return arr;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
