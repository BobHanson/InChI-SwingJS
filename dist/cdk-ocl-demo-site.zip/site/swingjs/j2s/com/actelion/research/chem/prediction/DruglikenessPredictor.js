(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'com.actelion.research.chem.prediction.IncrementTable','com.actelion.research.chem.prediction.ParameterizedStringList','com.actelion.research.chem.SSSearcher','com.actelion.research.chem.StereoMolecule','Thread','com.actelion.research.chem.IDCodeParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DruglikenessPredictor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mDetail','com.actelion.research.chem.prediction.ParameterizedStringList']]
,['Z',['sInitialized'],'O',['sIncrementTable','com.actelion.research.chem.prediction.IncrementTable']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
{
if (!C$.sInitialized) {
try {
C$.sIncrementTable=Clazz.new_($I$(1,1).c$$S,["/resources/druglikenessNoIndex.txt"]);
C$.sInitialized=true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Unable to initialize DruglikenessPredictor");
} else {
throw e;
}
}
}}}, 1);

Clazz.newMeth(C$, 'assessDruglikeness$com_actelion_research_chem_StereoMolecule$com_actelion_research_calc_ThreadMaster',  function (mol, threadMaster) {
var detail=Clazz.new_($I$(2,1));
if (!C$.sInitialized) {
detail.add$S$I("Druglikeness predictor not properly initialized.", 2);
return -999.0;
}detail.add$S$I("Found sub-structure fragments and their contributions:", 2);
detail.add$S$I("(yellow atoms carry at least one more substituent)", 2);
var nastyIncrementSum=0.0;
var incrementSum=0.0;
var fragmentCount=0;
var sss=Clazz.new_($I$(3,1).c$$I,[1]);
var fragment=Clazz.new_($I$(4,1));
for (var i=0; i < C$.sIncrementTable.getSize$(); i++) {
if (threadMaster != null  && threadMaster.threadMustDie$() ) return -999.0;
$I$(5).yield$();
Clazz.new_($I$(6,1).c$$Z,[false]).parse$com_actelion_research_chem_StereoMolecule$S(fragment, C$.sIncrementTable.getFragment$I(i));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(fragment, mol);
if (sss.isFragmentInMolecule$()) {
var increment=C$.sIncrementTable.getIncrement$I(i);
if (increment < -1 ) nastyIncrementSum+=increment;
 else {
incrementSum+=increment;
++fragmentCount;
}detail.add$S$I(C$.sIncrementTable.getFragment$I(i), 1);
detail.add$S$I(Double.toString$D(increment), 3);
}}
if (fragmentCount == 0) return -1;
var druglikeness=nastyIncrementSum + incrementSum / Math.sqrt(fragmentCount);
druglikeness=druglikeness + 0.0625 * (fragmentCount - 40);
this.mDetail=detail;
return druglikeness;
});

Clazz.newMeth(C$, 'getDruglikenessString$com_actelion_research_chem_StereoMolecule',  function (testMolecule) {
if (!C$.sInitialized) return "Druglikeness predictor not properly initialized.";
var incrementSum=0.0;
var fragmentCount=0;
var sss=Clazz.new_($I$(3,1).c$$I,[1]);
var fragment=Clazz.new_($I$(4,1));
for (var i=0; i < C$.sIncrementTable.getSize$(); i++) {
Clazz.new_($I$(6,1).c$$Z,[false]).parse$com_actelion_research_chem_StereoMolecule$S(fragment, C$.sIncrementTable.getFragment$I(i));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(fragment, testMolecule);
if (sss.isFragmentInMolecule$()) {
incrementSum+=C$.sIncrementTable.getIncrement$I(i);
++fragmentCount;
}}
var druglikeness=(fragmentCount == 0) ? -1 : incrementSum / Math.sqrt(fragmentCount);
return new Double(druglikeness).toString() + "\t" + fragmentCount + "\t" + testMolecule.getAtoms$() ;
});

Clazz.newMeth(C$, 'getDetail$',  function () {
return this.mDetail;
});

C$.$static$=function(){C$.$static$=0;
C$.sInitialized=false;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
