(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.calc.Matrix','com.actelion.research.chem.phesa.PheSAAlignment','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.alignment3d.transformation.Rotation',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPTriangle");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.d=Clazz.array(Double.TYPE, [3]);
this.c=Clazz.array($I$(1), [3]);
this.f=Clazz.array(Integer.TYPE, [3]);
this.dirs=Clazz.array($I$(1), [3]);
},1);

C$.$fields$=[['O',['d','double[]','c','com.actelion.research.chem.Coordinates[]','f','int[]','initialRot','double[][]','initialTranslate','double[]','u','double[][]','molCom','com.actelion.research.chem.Coordinates','+com','dirs','com.actelion.research.chem.Coordinates[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$D$D$D$com_actelion_research_chem_Coordinates',  function (pp1, pp2, pp3, d12, d13, d23, molCom) {
;C$.$init$.apply(this);
this.molCom=molCom;
this.f[0]=pp1.getFunctionalityIndex$();
this.f[1]=pp2.getFunctionalityIndex$();
this.f[2]=pp3.getFunctionalityIndex$();
this.d[0]=d12;
this.d[1]=d13;
this.d[2]=d23;
this.c[0]=Clazz.new_([pp1.getCenter$()],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
this.c[1]=Clazz.new_([pp2.getCenter$()],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
this.c[2]=Clazz.new_([pp3.getCenter$()],$I$(1,1).c$$com_actelion_research_chem_Coordinates);
this.dirs[0]=pp1.getDirectionality$();
this.dirs[1]=pp2.getDirectionality$();
this.dirs[2]=pp3.getDirectionality$();
p$1.canonizeOrder.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'canonizeOrder',  function () {
if (this.f[0] != this.f[1] && this.f[0] != this.f[2]  && this.f[1] != this.f[2] ) {
return;
} else if (this.f[0] == this.f[1] && this.f[1] == this.f[2] ) {
if (this.d[0] <= this.d[1] ) {
if (this.d[1] <= this.d[2] ) return;
 else {
if (this.d[0] <= this.d[2] ) p$1.swap$I$I.apply(this, [0, 1]);
 else {
p$1.swap$I$I.apply(this, [0, 1]);
p$1.swap$I$I.apply(this, [1, 2]);
}}} else {
if (this.d[2] <= this.d[1] ) p$1.swap$I$I.apply(this, [0, 2]);
 else {
if (this.d[0] <= this.d[2] ) p$1.swap$I$I.apply(this, [1, 2]);
 else {
p$1.swap$I$I.apply(this, [0, 1]);
p$1.swap$I$I.apply(this, [0, 2]);
}}}} else if (this.f[0] == this.f[1]) {
if (this.d[1] > this.d[2] ) {
p$1.swap$I$I.apply(this, [0, 1]);
}} else if (this.f[1] == this.f[2]) {
if (this.d[0] > this.d[1] ) {
p$1.swap$I$I.apply(this, [1, 2]);
}}}, p$1);

Clazz.newMeth(C$, 'swap$I$I',  function (i, j) {
var fiold=this.f[i];
var dirold=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[this.dirs[i]]);
this.dirs[i]=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[this.dirs[j]]);
this.f[i]=this.f[j];
this.f[j]=fiold;
this.dirs[j]=dirold;
var ciold=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[this.c[i]]);
this.c[i]=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[this.c[j]]);
this.c[j]=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[ciold]);
if (i == 0 && j == 1 ) {
var dold=this.d[2];
this.d[2]=this.d[1];
this.d[1]=dold;
} else if (i == 0 && j == 2 ) {
var dold=this.d[2];
this.d[2]=this.d[0];
this.d[0]=dold;
} else if (i == 1 && j == 2 ) {
var dold=this.d[1];
this.d[1]=this.d[0];
this.d[0]=dold;
}}, p$1);

Clazz.newMeth(C$, 'getHash$',  function () {
return this.f[0] + 10 * this.f[1] + 100 * this.f[2];
});

Clazz.newMeth(C$, 'getEdgeLengths$',  function () {
return this.d;
});

Clazz.newMeth(C$, 'preAlign',  function () {
this.com=(this.c[0].addC$com_actelion_research_chem_Coordinates(this.c[1]).addC$com_actelion_research_chem_Coordinates(this.c[2])).scaleC$D(0.33333);
this.c[0].sub$com_actelion_research_chem_Coordinates(this.com);
this.c[1].sub$com_actelion_research_chem_Coordinates(this.com);
this.c[2].sub$com_actelion_research_chem_Coordinates(this.com);
var xInt=this.c[0].unitC$();
var v=this.c[1].unitC$();
var zInt=xInt.cross$com_actelion_research_chem_Coordinates(v).unitC$();
var yInt=zInt.cross$com_actelion_research_chem_Coordinates(xInt).unitC$();
var m=Clazz.array(Double.TYPE, [3, 3]);
m[0][0]=xInt.x;
m[1][0]=xInt.y;
m[2][0]=xInt.z;
m[0][1]=yInt.x;
m[1][1]=yInt.y;
m[2][1]=yInt.z;
m[0][2]=zInt.x;
m[1][2]=zInt.y;
m[2][2]=zInt.z;
this.c[0].rotate$DAA(m);
this.c[1].rotate$DAA(m);
this.c[2].rotate$DAA(m);
this.initialRot=m;
this.initialTranslate=Clazz.array(Double.TYPE, -1, [-this.com.x, -this.com.y, -this.com.z]);
}, p$1);

Clazz.newMeth(C$, 'getInitialRot$',  function () {
return this.initialRot;
});

Clazz.newMeth(C$, 'getInitialTranslate$',  function () {
return this.initialTranslate;
});

Clazz.newMeth(C$, 'getMatchingTransform$com_actelion_research_chem_phesa_pharmacophore_PPTriangle$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z',  function (fitTriangle, transform, useDirectionality) {
var ur=Clazz.array(Double.TYPE, [3, 3]);
if (this.initialRot == null  && this.initialTranslate == null  ) p$1.preAlign.apply(this, []);
if (fitTriangle.initialRot == null  && fitTriangle.initialTranslate == null  ) p$1.preAlign.apply(fitTriangle, []);
var a1=this.c[0];
var a2=this.c[1];
var a3=this.c[2];
var b1=fitTriangle.c[0];
var b2=fitTriangle.c[1];
var b3=fitTriangle.c[2];
var ppFit=((4 - 2 * Math.min(a1.subC$com_actelion_research_chem_Coordinates(b1).dist$(), 2)) + (4 - 2 * Math.min(a2.subC$com_actelion_research_chem_Coordinates(b2).dist$(), 2)) + (4 - 2 * Math.min(a3.subC$com_actelion_research_chem_Coordinates(b3).dist$(), 2)) ) / 12.0;
var mu=Clazz.new_($I$(2,1).c$$DAA,[this.initialRot]);
this.u=mu.getTranspose$().getArray$();
$I$(3).multiplyMatrix$DAA$DAA$DAA(this.u, fitTriangle.initialRot, ur);
transform.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(Clazz.new_($I$(4,1).c$$DA,[fitTriangle.initialTranslate]));
transform.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(Clazz.new_($I$(5,1).c$$DAA,[ur]));
transform.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(Clazz.new_([Clazz.array(Double.TYPE, -1, [-this.initialTranslate[0], -this.initialTranslate[1], -this.initialTranslate[2]])],$I$(4,1).c$$DA));
var fitComNew=Clazz.new_($I$(1,1));
fitComNew.x=fitTriangle.molCom.x - fitTriangle.com.x;
fitComNew.y=fitTriangle.molCom.y - fitTriangle.com.y;
fitComNew.z=fitTriangle.molCom.z - fitTriangle.com.z;
var fitComNewRot=Clazz.new_($I$(1,1));
fitComNewRot.x=ur[0][0] * (fitComNew.x) + ur[1][0] * (fitComNew.y) + ur[2][0] * (fitComNew.z);
fitComNewRot.y=ur[0][1] * (fitComNew.x) + ur[1][1] * (fitComNew.y) + ur[2][1] * (fitComNew.z);
fitComNewRot.z=ur[0][2] * (fitComNew.x) + ur[1][2] * (fitComNew.y) + ur[2][2] * (fitComNew.z);
var a=this.com.subC$com_actelion_research_chem_Coordinates(this.molCom);
var b=fitComNewRot.scale$D(-1.0);
var ra=a.dist$();
var rb=b.dist$();
var Sdirec=a.unitC$().dot$com_actelion_research_chem_Coordinates(b.unitC$());
if (Sdirec < 0 ) Sdirec=0.0;
var a_b=a.subC$com_actelion_research_chem_Coordinates(b).dist$();
var comScore=1.0;
var dirScore=1.0;
if (useDirectionality) {
var fitDir1=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[fitTriangle.dirs[0]]);
var fitDir2=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[fitTriangle.dirs[1]]);
var fitDir3=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[fitTriangle.dirs[2]]);
if (fitTriangle.f[0] == $I$(6).ACCEPTOR.getIndex$() || fitTriangle.f[0] == $I$(6).DONOR.getIndex$() ) fitDir1.rotate$DAA(ur);
if (fitTriangle.f[1] == $I$(6).ACCEPTOR.getIndex$() || fitTriangle.f[1] == $I$(6).DONOR.getIndex$() ) fitDir2.rotate$DAA(ur);
if (fitTriangle.f[2] == $I$(6).ACCEPTOR.getIndex$() || fitTriangle.f[2] == $I$(6).DONOR.getIndex$() ) fitDir3.rotate$DAA(ur);
dirScore=0.33333 * (Math.max(0, fitDir1.dot$com_actelion_research_chem_Coordinates(this.dirs[0])) + Math.max(0, fitDir2.dot$com_actelion_research_chem_Coordinates(this.dirs[1])) + Math.max(0, fitDir3.dot$com_actelion_research_chem_Coordinates(this.dirs[2])) );
comScore=(1 - ((1 - Math.exp(-0.25 * Math.sqrt(ra * rb))) * (1 - Sdirec))) * Math.exp(-0.125 * (a_b * a_b));
}return ppFit * dirScore * comScore ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
