(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.calculator"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.calculator.IntQueue','java.util.LinkedList',['com.actelion.research.chem.descriptor.flexophore.calculator.StructureCalculator','.Item'],'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.Molecule','com.actelion.research.util.ArrayUtils','java.util.Arrays',['com.actelion.research.chem.descriptor.flexophore.calculator.StructureCalculator','.Node'],'java.util.Collections','java.util.TreeSet','com.actelion.research.chem.descriptor.flexophore.calculator.GeometryCalculator','com.actelion.research.chem.Coordinates','java.util.HashMap','java.util.HashSet','com.actelion.research.chem.io.pdb.converter.MoleculeGrid','com.actelion.research.chem.conf.VDWRadii']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureCalculator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Item',10],['Node',26]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getConnexComponents$com_actelion_research_chem_Molecule3D',  function (mol) {
var groups=C$.getAtomToGroups$com_actelion_research_chem_Molecule3D(mol);
var nGroups=0;
for (var i=0; i < groups.length; i++) {
if (groups[i] > nGroups) nGroups=groups[i];
}
var r=Clazz.new_($I$(1,1));
for (var i=0; i < nGroups; i++) r.add$O(Clazz.new_($I$(1,1)));

for (var i=0; i < groups.length; i++) {
r.get$I(groups[i] - 1).add$O(Integer.valueOf$I(i));
}
return r;
}, 1);

Clazz.newMeth(C$, 'getAtomToGroups$com_actelion_research_chem_Molecule3D',  function (mol) {
return C$.getAtomToGroups$com_actelion_research_chem_Molecule3D$java_util_List(mol, null);
}, 1);

Clazz.newMeth(C$, 'getAtomToGroups$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, seeds) {
var res=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var q=Clazz.new_($I$(2,1));
var nGroups=0;
for (var i=0; i < res.length; i++) {
if (res[i] > 0) continue;
if (seeds != null ) seeds.add$O(Integer.valueOf$I(i));
q.push$I(i);
++nGroups;
while (!q.isEmpty$()){
var a=q.pop$();
res[a]=nGroups;
for (var j=0; j < mol.getAllConnAtoms$I(a); j++) {
var a2=mol.getConnAtom$I$I(a, j);
if (a2 < mol.getAtoms$()) {
if (res[a2] == 0) {
q.push$I(a2);
res[a2]=-1;
}}}
}
q.clear$();
}
return res;
}, 1);

Clazz.newMeth(C$, 'getLongestChain$com_actelion_research_chem_Molecule3D$I',  function (mol, atm) {
var q=Clazz.new_($I$(3,1));
q.add$O(Clazz.new_($I$(4,1).c$$I,[atm]));
var seen=Clazz.array(Boolean.TYPE, [mol.getAllBonds$() * 2]);
try {
while (true){
var item=q.removeFirst$();
var a=item.a;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var b=mol.getConnBond$I$I(a, i);
var a2=mol.getConnAtom$I$I(a, i);
var bi=b * 2 + (a2 > a ? 1 : 0);
if (seen[bi]) continue;
seen[bi]=true;
if (mol.getAtomicNo$I(a2) <= 1) continue;
var ni=Clazz.new_($I$(4,1).c$$I,[a2]);
ni.a=a2;
ni.path=item.path.clone$();
ni.path.add$O(Integer.valueOf$I(a2));
q.add$O(ni);
}
if (q.isEmpty$()) return item.path;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getBackbones$com_actelion_research_chem_Molecule3D',  function (molecule) {
return C$.getBackbones$com_actelion_research_chem_Molecule3D$I(molecule, 70);
}, 1);

Clazz.newMeth(C$, 'getBackbones$com_actelion_research_chem_Molecule3D$I',  function (molecule, minChain) {
var inBackbone=Clazz.array(Boolean.TYPE, [molecule.getAllAtoms$()]);
var fragments=C$.getConnexComponents$com_actelion_research_chem_Molecule3D(molecule);
for (var i=0; i < fragments.size$(); i++) {
var markAll=false;
var fragment=fragments.get$I(i);
var l=null;
var root=(fragment.get$I(0)).$c();
if (markAll) {
for (var j=0; j < fragment.size$(); j++) {
inBackbone[(fragment.get$I(j)).intValue$()]=true;
}
} else {
l=C$.getLongestChain$com_actelion_research_chem_Molecule3D$I(molecule, root);
root=(l.get$I(l.size$() - 1)).intValue$();
l=C$.getLongestChain$com_actelion_research_chem_Molecule3D$I(molecule, root);
if (l.size$() < minChain && molecule.getAllAtoms$() > 80 ) markAll=true;
for (var j=0; j < l.size$(); j++) {
inBackbone[(l.get$I(j)).intValue$()]=true;
}
}}
return inBackbone;
}, 1);

Clazz.newMeth(C$, 'getNumberOfBondsBetweenAtoms$com_actelion_research_chem_Molecule3D$I$IAA',  function (mol, maxBonds, dist) {
if (dist == null ) dist=Clazz.array(Integer.TYPE, [mol.getAllAtoms$(), mol.getAllAtoms$()]);
var N=dist.length;
for (var i=0; i < N; i++) {
dist[i][i]=0;
for (var j=i + 1; j < N; j++) {
dist[i][j]=dist[j][i]=-1;
}
}
for (var j=0; j < maxBonds; j++) {
for (var i=0; i < mol.getAllBonds$(); i++) {
var a1=mol.getBondAtom$I$I(0, i);
var a2=mol.getBondAtom$I$I(1, i);
if (a1 >= N || a2 >= N ) continue;
for (var a0=0; a0 < N; a0++) {
if (dist[a0][a1] >= 0 && (dist[a0][a2] == -1 || dist[a0][a1] + 1 < dist[a0][a2] )  && dist[a0][a1] < maxBonds ) {
dist[a2][a0]=(dist[a0][a2]=(dist[a0][a1] + 1));
}if (dist[a0][a2] >= 0 && (dist[a0][a1] == -1 || dist[a0][a2] + 1 < dist[a0][a1] )  && dist[a0][a2] < maxBonds ) {
dist[a1][a0]=(dist[a0][a1]=(dist[a0][a2] + 1));
}}
}
}
return dist;
}, 1);

Clazz.newMeth(C$, 'getNumberOfAtomsBetweenBonds$com_actelion_research_chem_Molecule3D$I$IAA',  function (mol, maxAtoms, dist) {
if (dist == null ) dist=Clazz.array(Integer.TYPE, [mol.getAllBonds$(), mol.getAllBonds$()]);
var N=dist.length;
for (var i=0; i < N; i++) {
dist[i][i]=0;
for (var j=i + 1; j < N; j++) {
dist[i][j]=dist[j][i]=-1;
}
}
for (var iter=0; iter < maxAtoms; iter++) {
for (var a=0; a < mol.getAllAtoms$(); a++) {
for (var k1=0; k1 < mol.getConnAtoms$I(a); k1++) {
var b1=mol.getConnBond$I$I(a, k1);
for (var k2=k1 + 1; k2 < mol.getConnAtoms$I(a); k2++) {
var b2=mol.getConnBond$I$I(a, k2);
if (b1 >= N || b2 >= N ) continue;
for (var b0=0; b0 < N; b0++) {
if (dist[b0][b1] >= 0 && (dist[b0][b2] == -1 || dist[b0][b1] + 1 < dist[b0][b2] )  && dist[b0][b1] < maxAtoms ) {
dist[b2][b0]=dist[b0][b2]=dist[b0][b1] + 1;
}if (dist[b0][b2] >= 0 && (dist[b0][b1] == -1 || dist[b0][b2] + 1 < dist[b0][b1] )  && dist[b0][b2] < maxAtoms ) {
dist[b1][b0]=dist[b0][b1]=dist[b0][b2] + 1;
}}
}
}
}
}
return dist;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var sm=Clazz.new_($I$(5,1));
Clazz.new_($I$(6,1)).parse$com_actelion_research_chem_StereoMolecule$S(sm, "C1CCC1OCCCC");
var m=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[sm]);
var B=C$.getNumberOfAtomsBetweenBonds$com_actelion_research_chem_Molecule3D$I$IAA(m, m.getAllAtoms$(), null);
System.out.print$S("\t");
for (var j=0; j < B.length; j++) {
System.out.print$S("_" + j + "_\t" );
}
System.out.println$();
for (var i=0; i < B.length; i++) {
System.out.print$S("_" + i + "_\t" );
for (var j=0; j < B[i].length; j++) {
System.out.print$S((B[i][j] >= 0 ? Integer.valueOf$I(B[i][j]) : "") + "\t");
}
System.out.println$();
}
}, 1);

Clazz.newMeth(C$, 'getMaxValence$I',  function (atomicNo) {
if (atomicNo >= 171 && atomicNo <= 190 ) return 2;
switch (atomicNo) {
case 1:
return 1;
case 5:
return 3;
case 6:
return 4;
case 7:
return 3;
case 8:
return 2;
case 9:
return 1;
case 13:
return 3;
case 14:
return 4;
case 15:
return 3;
case 16:
return 2;
case 17:
return 1;
case 33:
return 3;
case 34:
return 2;
case 35:
return 1;
case 52:
return 2;
case 53:
return 1;
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getImplicitHydrogens$com_actelion_research_chem_Molecule3D$I',  function (mol, atm) {
var atomicNo=mol.getAtomicNo$I(atm);
var hydrogensToAdd=C$.getMaxValence$I(atomicNo);
if (atomicNo == 6) {
hydrogensToAdd-=Math.abs(mol.getAtomCharge$I(atm));
} else if ($I$(8).isAtomicNoElectronegative$I(atomicNo)) {
hydrogensToAdd+=mol.getAtomCharge$I(atm);
} else {
hydrogensToAdd-=mol.getAtomCharge$I(atm);
}for (var i=0; i < mol.getAllConnAtoms$I(atm); i++) {
if (mol.getAtomicNo$I(mol.getConnAtom$I$I(atm, i)) >= 1) hydrogensToAdd-=mol.getConnBondOrder$I$I(atm, i);
}
if (atomicNo == 15) return 0;
 else if (atomicNo == 16 && hydrogensToAdd < 0 ) hydrogensToAdd+=Math.min(4, -hydrogensToAdd);
 else if (atomicNo == 8 && mol.getAllConnAtoms$I(atm) == 1  && mol.getAtomicNo$I(mol.getConnAtom$I$I(atm, 0)) == 15 ) return 0;
return hydrogensToAdd;
}, 1);

Clazz.newMeth(C$, 'getMaxFreeValence$com_actelion_research_chem_Molecule3D$I',  function (mol, atm) {
switch (mol.getAtomicNo$I(atm)) {
case 15:
return 5 - C$.getValence$com_actelion_research_chem_Molecule3D$I(mol, atm);
case 16:
return 6 - C$.getValence$com_actelion_research_chem_Molecule3D$I(mol, atm);
default:
return C$.getImplicitHydrogens$com_actelion_research_chem_Molecule3D$I(mol, atm) + C$.getExplicitHydrogens$com_actelion_research_chem_Molecule3D$I(mol, atm);
}
}, 1);

Clazz.newMeth(C$, 'extractFragments$com_actelion_research_chem_Molecule3D',  function (mol) {
return null;
}, 1);

Clazz.newMeth(C$, 'extractLigands$com_actelion_research_chem_Molecule3D',  function (mol) {
var comps=C$.getConnexComponents$com_actelion_research_chem_Molecule3D(mol);
var res=Clazz.new_($I$(1,1));
for (var comp, $comp = comps.iterator$(); $comp.hasNext$()&&((comp=($comp.next$())),1);) {
var m=Clazz.new_($I$(7,1));
C$.extractFragment$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA(mol, m, $I$(9).toIntArray$java_util_Collection(comp));
if (m.getAllAtoms$() > 5 && m.isAtomFlag$I$I(0, 2) ) res.add$O(m);
}
return res;
}, 1);

Clazz.newMeth(C$, 'extractFragment$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, res, atoms) {
return C$.extractFragment$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA(mol, res, $I$(9).toIntArray$java_util_Collection(atoms));
}, 1);

Clazz.newMeth(C$, 'extractFragment$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA',  function (mol, res, atoms) {
res.clear$();
var oldToNew=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
$I$(10).fill$IA$I(oldToNew, -1);
for (var i=0; i < atoms.length; i++) {
oldToNew[atoms[i]]=res.addAtom$com_actelion_research_chem_Molecule3D$I(mol, atoms[i]);
for (var j=0; j < mol.getAllConnAtoms$I(atoms[i]); j++) {
var a=mol.getConnAtom$I$I(atoms[i], j);
if (oldToNew[a] < 0) continue;
res.addBond$I$I$I(oldToNew[atoms[i]], oldToNew[a], mol.getConnBondOrder$I$I(atoms[i], j));
}
}
return res;
}, 1);

Clazz.newMeth(C$, 'getRings$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, allRings) {
if (mol.getAllAtoms$() < 100) return C$.getRingsAccurate$com_actelion_research_chem_Molecule3D$java_util_List(mol, allRings);
return C$.getRingsFast$com_actelion_research_chem_Molecule3D$java_util_List(mol, allRings);
}, 1);

Clazz.newMeth(C$, 'getRingsAccurate$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, allRings) {
var connectables=Clazz.array($I$(1), [mol.getAllAtoms$()]);
var maxRingSize=0;
for (var atm=0; atm < mol.getAllAtoms$(); atm++) {
if (mol.getAtomicNo$I(atm) == 1) continue;
++maxRingSize;
var node=Clazz.new_($I$(11,1).c$$I$com_actelion_research_chem_descriptor_flexophore_calculator_StructureCalculator_Node$I,[atm, null, 0]);
connectables[atm]=Clazz.new_($I$(1,1));
connectables[atm].add$O(node);
}
if (maxRingSize > 50) maxRingSize=50;
var N=mol.getAllAtoms$();
var M=mol.getAllBonds$();
var coveredBonds=Clazz.array(Boolean.TYPE, [M]);
var visitedBonds=Clazz.array(Boolean.TYPE, [N, M * 2]);
var iteration=0;
while (iteration < maxRingSize){
++iteration;
for (var atm=0; atm < N; atm++) {
var lastListOfConnectables=connectables[atm];
if (lastListOfConnectables == null ) continue;
var newListOfConnectables=Clazz.new_($I$(1,1));
var iter=lastListOfConnectables.iterator$();
 loopPaths : while (iter.hasNext$()){
var node=iter.next$();
var atm2=node.atm;
for (var j=0; j < mol.getAllConnAtoms$I(atm2); j++) {
var atm3=mol.getConnAtom$I$I(atm2, j);
var bond=mol.getConnBond$I$I(atm2, j);
var orientedBond=bond + (atm3 < atm2 ? mol.getAllBonds$() : 0);
if (mol.getAtomicNo$I(atm3) == 1) continue;
if (iteration == 1 && atm3 < atm ) continue;
if (node.parent != null  && node.parent.atm == atm3 ) continue;
if (visitedBonds[atm][orientedBond]) continue;
visitedBonds[atm][orientedBond]=true;
if (atm3 == atm) {
var n=node;
var ring=Clazz.new_($I$(1,1));
var isCovering=true;
while (n != null ){
ring.add$I$O(0, Integer.valueOf$I(n.atm));
if (!coveredBonds[n.bond]) {
isCovering=false;
coveredBonds[n.bond]=true;
}n=n.parent;
}
if (isCovering) continue;
if (ring.size$() < 3) {
System.err.println$S("ring of size " + ring.size$() + "???" );
continue;
}var tmp=$I$(9).toIntArray$java_util_Collection(ring);
if (!C$.contains$java_util_List$IA(allRings, tmp)) {
allRings.add$O(tmp);
maxRingSize=maxRingSize - ((tmp.length - 1)/2|0);
}} else {
var n=node.parent;
while (n != null ){
if (n.atm == atm3) continue loopPaths;
n=n.parent;
}
n=Clazz.new_($I$(11,1).c$$I$com_actelion_research_chem_descriptor_flexophore_calculator_StructureCalculator_Node$I,[atm3, node, bond]);
newListOfConnectables.add$O(n);
}}
}
connectables[atm]=newListOfConnectables;
}
}
var atomToRing=Clazz.array($I$(1), [mol.getAllAtoms$()]);
for (var j=0; j < atomToRing.length; j++) atomToRing[j]=Clazz.new_($I$(1,1));

for (var i=0; i < allRings.size$(); i++) {
var atoms=allRings.get$I(i);
for (var j=0; j < atoms.length; j++) {
atomToRing[atoms[j]].add$O(Integer.valueOf$I(i));
}
}
return atomToRing;
}, 1);

Clazz.newMeth(C$, 'getRingsFast$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, allRings) {
var visitedBonds=Clazz.array(Boolean.TYPE, [mol.getAllBonds$()]);
for (var atm=0; atm < mol.getAllAtoms$(); atm++) {
if (mol.getAtomicNo$I(atm) <= 1) continue;
var previous=Clazz.new_($I$(1,1));
previous.add$O(Integer.valueOf$I(atm));
C$.doRings$com_actelion_research_chem_Molecule3D$java_util_List$java_util_List$ZA$I(mol, allRings, previous, visitedBonds, 7);
}
for (var i=0; i < allRings.size$(); i++) {
if (allRings.get$I(i).length < 6) continue;
var found=0;
for (var j=0; j < allRings.size$(); j++) {
if (i == j || allRings.get$I(j).length >= 6 ) continue;
var atomNotFound=0;
 nextAtom : for (var a, $a = 0, $$a = allRings.get$I(j); $a<$$a.length&&((a=($$a[$a])),1);$a++) {
for (var a2, $a2 = 0, $$a2 = allRings.get$I(i); $a2<$$a2.length&&((a2=($$a2[$a2])),1);$a2++) {
if (a == a2) continue nextAtom;
}
++atomNotFound;
}
if (atomNotFound <= 1) ++found;
}
if (found >= 2) {
allRings.remove$I(i--);
}}
$I$(12,"sort$java_util_List$java_util_Comparator",[allRings, ((P$.StructureCalculator$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "StructureCalculator$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$IA$IA','compare$O$O'],  function (o1, o2) {
return o1.length - o2.length;
});
})()
), Clazz.new_(P$.StructureCalculator$1.$init$,[this, null]))]);
var atomToRing=Clazz.array($I$(1), [mol.getAllAtoms$()]);
for (var j=0; j < atomToRing.length; j++) atomToRing[j]=Clazz.new_($I$(1,1));

for (var r=0; r < allRings.size$(); r++) {
for (var a, $a = 0, $$a = allRings.get$I(r); $a<$$a.length&&((a=($$a[$a])),1);$a++) {
atomToRing[a].add$O(Integer.valueOf$I(r));
}
}
return atomToRing;
}, 1);

Clazz.newMeth(C$, 'doRings$com_actelion_research_chem_Molecule3D$java_util_List$java_util_List$ZA$I',  function (mol, allRings, previous, visitedBonds, depth) {
if (depth <= 0) return;
var firstAtom=(previous.get$I(0)).$c();
var lastAtom=(previous.get$I(previous.size$() - 1)).$c();
for (var i=0; i < mol.getAllConnAtoms$I(lastAtom); i++) {
var b=mol.getConnBond$I$I(lastAtom, i);
var a=mol.getConnAtom$I$I(lastAtom, i);
if (visitedBonds[b]) continue;
if (mol.getAtomicNo$I(a) <= 1) continue;
if (a < firstAtom) continue;
if (a == firstAtom && previous.size$() > 2 ) {
if ((previous.get$I(1)).$c() > (previous.get$I(previous.size$() - 1)).$c() ) continue;
var ring=$I$(9).toIntArray$java_util_Collection(previous);
allRings.add$O(ring);
} else {
visitedBonds[b]=true;
previous.add$O(Integer.valueOf$I(a));
C$.doRings$com_actelion_research_chem_Molecule3D$java_util_List$java_util_List$ZA$I(mol, allRings, previous, visitedBonds, depth - 1);
previous.remove$I(previous.size$() - 1);
visitedBonds[b]=false;
}}
}, 1);

Clazz.newMeth(C$, 'contains$java_util_List$IA',  function (rings, ring) {
var iter=rings.iterator$();
 next : while (iter.hasNext$()){
var r=iter.next$();
if (r.length != ring.length) continue;
for (var i=0; i < r.length; i++) {
var found=false;
for (var j=0; j < ring.length; j++) {
if (ring[j] == r[i]) found=true;
}
if (!found) continue next;
}
return true;
}
return false;
}, 1);

Clazz.newMeth(C$, 'getInterMolecularInteractions$com_actelion_research_chem_Molecule3D',  function (mol) {
return null;
}, 1);

Clazz.newMeth(C$, 'getAtomsOnPath$com_actelion_research_chem_Molecule3D$I$I',  function (mol, a1, a2) {
if (a1 >= mol.getAllAtoms$() || a2 >= mol.getAllAtoms$() ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Invalid atom number"]);
var visited=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
var set=Clazz.new_($I$(13,1));
var leaves=Clazz.new_($I$(1,1));
var n=Clazz.new_($I$(11,1).c$$I$com_actelion_research_chem_descriptor_flexophore_calculator_StructureCalculator_Node$I,[a1, null, -1]);
leaves.add$O(n);
var timeout=-1;
for (var loop=0; loop < mol.getAllBonds$() && timeout != 0  && leaves.size$() > 0 ; loop++, timeout--) {
n=leaves.remove$I(0);
var a=n.atm;
if (a == a2) {
for (var tmp=n; tmp.parent != null ; tmp=tmp.parent) {
set.add$O(Integer.valueOf$I(tmp.atm));
}
timeout=5;
continue;
}if (visited[a]) continue;
visited[a]=true;
for (var j=0; j < mol.getAllConnAtoms$I(a); j++) {
var atm=mol.getConnAtom$I$I(a, j);
if (visited[atm]) continue;
var leaf=Clazz.new_([atm, n, mol.getConnBond$I$I(a, j)],$I$(11,1).c$$I$com_actelion_research_chem_descriptor_flexophore_calculator_StructureCalculator_Node$I);
leaves.add$O(leaf);
}
}
if (timeout >= 0) {
set.add$O(Integer.valueOf$I(a1));
set.add$O(Integer.valueOf$I(a2));
}var res=Clazz.array(Integer.TYPE, [set.size$()]);
var count=0;
for (var a, $a = set.iterator$(); $a.hasNext$()&&((a=($a.next$()).intValue$()),1);) {
res[count++]=a;
}
return res;
}, 1);

Clazz.newMeth(C$, 'getValence$com_actelion_research_chem_Molecule3D$I',  function (mol, atm) {
var res=0;
for (var i=0; i < mol.getAllConnAtoms$I(atm); i++) {
if (mol.getAtomicNo$I(mol.getConnAtom$I$I(atm, i)) > 1) res+=mol.getConnBondOrder$I$I(atm, i);
}
return res;
}, 1);

Clazz.newMeth(C$, 'getExplicitHydrogens$com_actelion_research_chem_Molecule3D$I',  function (mol, atm) {
var n=0;
for (var i=0; i < mol.getAllConnAtoms$I(atm); i++) {
if (mol.getAtomicNo$I(mol.getConnAtom$I$I(atm, i)) == 1) ++n;
}
return n;
}, 1);

Clazz.newMeth(C$, 'getStructureCenter$com_actelion_research_chem_Molecule3D$IA$IAA',  function (lig, rotatables, dists) {
return C$.getStructureCenter$com_actelion_research_chem_Molecule3D$I$IA$IAA(lig, 0, rotatables, dists);
}, 1);

Clazz.newMeth(C$, 'getStructureCenter$com_actelion_research_chem_Molecule3D$I$IA$IAA',  function (lig, a, rotatables, dists) {
var backbone=C$.getBackbone$com_actelion_research_chem_Molecule3D$I(lig, a);
backbone=C$.getBackbone$com_actelion_research_chem_Molecule3D$I(lig, (backbone.get$I(0)).$c());
var bbCenter=(backbone.get$I((backbone.size$()/2|0))).$c();
return bbCenter;
}, 1);

Clazz.newMeth(C$, 'getBackbone$com_actelion_research_chem_Molecule3D$I',  function (lig, a) {
var backbone=C$.getLongestChain$com_actelion_research_chem_Molecule3D$I(lig, a);
backbone=C$.getLongestChain$com_actelion_research_chem_Molecule3D$I(lig, (backbone.get$I(backbone.size$() - 1)).$c());
return backbone;
}, 1);

Clazz.newMeth(C$, 'dfs$com_actelion_research_chem_Molecule3D$I$java_util_Set',  function (lig, start, seen) {
return C$.dfs$com_actelion_research_chem_Molecule3D$I$java_util_Set$I$Z(lig, start, seen, 99, false);
}, 1);

Clazz.newMeth(C$, 'dfs$com_actelion_research_chem_Molecule3D$I$java_util_Set$I$Z',  function (lig, start, seen, depth, takeRingsAsWhole) {
return -1;
}, 1);

Clazz.newMeth(C$, 'extractLigand$com_actelion_research_chem_Molecule3D',  function (mol) {
if (mol == null ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["The mol is null"]);
if (mol.getNMovables$() == mol.getAllAtoms$()) return Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule3D,[mol]);
var res=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule3D,[mol]);
var oldToNew=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
$I$(10).fill$IA$I(oldToNew, -1);
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.isAtomFlag$I$I(i, 2) && oldToNew[i] < 0 ) {
oldToNew[i]=res.addAtom$com_actelion_research_chem_Molecule3D$I(mol, i);
for (var j=0; j < mol.getAllConnAtoms$I(i); j++) {
var a=mol.getConnAtom$I$I(i, j);
if (oldToNew[a] < 0) continue;
res.addBond$I$I$I(oldToNew[i], oldToNew[a], mol.getConnBondOrder$I$I(i, j));
}
}}
return res;
}, 1);

Clazz.newMeth(C$, 'insertLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates',  function (mol, lig, center) {
var index=mol.fusion$com_actelion_research_chem_Molecule3D(lig);
for (var i=index; i < mol.getAllAtoms$(); i++) {
mol.setAtomFlag$I$I$Z(i, 34, true);
}
if (center != null  && $I$(14).getCenterGravity$com_actelion_research_chem_Molecule3D(lig).distance$com_actelion_research_chem_Coordinates(center) > 5  ) {
C$.translateLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates(mol, center.subC$com_actelion_research_chem_Coordinates($I$(14).getCenterGravity$com_actelion_research_chem_Molecule3D(lig)));
}}, 1);

Clazz.newMeth(C$, 'replaceLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D',  function (mol, lig) {
C$.replaceLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates(mol, lig, null);
}, 1);

Clazz.newMeth(C$, 'replaceLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates',  function (mol, lig, center) {
if (center == null ) center=C$.getLigandCenter$com_actelion_research_chem_Molecule3D(mol);
C$.removeLigand$com_actelion_research_chem_Molecule3D(mol);
if (lig != null ) C$.insertLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates(mol, lig, center);
}, 1);

Clazz.newMeth(C$, 'deleteHydrogens$com_actelion_research_chem_Molecule3D',  function (mol) {
var changed=false;
for (var i=mol.getAllAtoms$() - 1; i >= 0; i--) if (mol.getAtomicNo$I(i) <= 1) {
changed=true;
mol.deleteAtom$I(i);
}
return changed;
}, 1);

Clazz.newMeth(C$, 'addHydrogens$com_actelion_research_chem_Molecule3D',  function (mol) {
return C$.addHydrogens$com_actelion_research_chem_Molecule3D$Z(mol, false);
}, 1);

Clazz.newMeth(C$, 'addHydrogens$com_actelion_research_chem_Molecule3D$Z',  function (mol, alsoRigidAtoms) {
var changed=false;
var N=mol.getAllAtoms$();
var atomsToBeDeleted=Clazz.new_($I$(1,1));
var bounds=null;
if (alsoRigidAtoms) {
bounds=C$.getLigandBounds$com_actelion_research_chem_Molecule3D(mol);
bounds[0].sub$com_actelion_research_chem_Coordinates(Clazz.new_($I$(15,1).c$$D$D$D,[11, 11, 11]));
bounds[1].add$com_actelion_research_chem_Coordinates(Clazz.new_($I$(15,1).c$$D$D$D,[11, 11, 11]));
}for (var i=0; i < N; i++) {
if (!mol.isAtomFlag$I$I(i, 1)) {
} else if (!alsoRigidAtoms) {
continue;
} else {
if (!mol.getCoordinates$I(i).insideBounds$com_actelion_research_chem_CoordinatesA(bounds)) continue;
}var n=C$.getImplicitHydrogens$com_actelion_research_chem_Molecule3D$I(mol, i);
if (n < 0) {
for (var j=0; j < mol.getAllConnAtoms$I(i) && n < 0 ; j++) {
var a=mol.getConnAtom$I$I(i, j);
if (mol.getAtomicNo$I(a) == 1) {
atomsToBeDeleted.add$O(Integer.valueOf$I(a));
changed=true;
++n;
}}
} else if (n > 0) {
for (var j=0; j < n; j++) {
var a=mol.addAtom$I(1);
mol.setAtomFlags$I$I(a, mol.getAtomFlags$I(i) & ~32);
mol.addBond$I$I$I(i, a, 1);
mol.setCoordinates$I$com_actelion_research_chem_Coordinates(a, mol.getCoordinates$I(i));
}
changed=true;
}}
mol.deleteAtoms$java_util_List(atomsToBeDeleted);
return changed;
}, 1);

Clazz.newMeth(C$, 'addHydrogensAroundLigand$com_actelion_research_chem_Molecule3D$D',  function (mol, radius) {
return false;
}, 1);

Clazz.newMeth(C$, 'copyAtoms$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$java_util_List',  function (mol, res, atomsToBeAdded) {
var molToRes=Clazz.new_($I$(16,1));
for (var i=0; i < atomsToBeAdded.size$(); i++) {
var a=(atomsToBeAdded.get$I(i)).$c();
if (molToRes.containsKey$O(Integer.valueOf$I(a))) continue;
var n=res.addAtom$com_actelion_research_chem_Molecule3D$I(mol, a);
molToRes.put$O$O(Integer.valueOf$I(a), Integer.valueOf$I(n));
}
for (var i=0; i < mol.getAllBonds$(); i++) {
var mol1=mol.getBondAtom$I$I(0, i);
var mol2=mol.getBondAtom$I$I(1, i);
var a1=molToRes.get$O(Integer.valueOf$I(mol1));
var a2=molToRes.get$O(Integer.valueOf$I(mol2));
if (a1 != null  && a2 != null  ) {
res.addBond$I$I$I(a1.intValue$(), a2.intValue$(), mol.getBondOrder$I(i));
}}
}, 1);

Clazz.newMeth(C$, 'removeWater$com_actelion_research_chem_Molecule3D',  function (mol) {
C$.removeWater$com_actelion_research_chem_Molecule3D$Z(mol, true);
}, 1);

Clazz.newMeth(C$, 'removeWater$com_actelion_research_chem_Molecule3D$Z',  function (mol, removeAlsoImportant) {
if (mol == null ) return;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 0) {
mol.deleteAtom$I(i);
--i;
}}
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 8 && (removeAlsoImportant || !mol.isAtomFlag$I$I(i, 16) ) ) {
if (mol.getAllConnAtoms$I(i) == 0) {
mol.deleteAtom$I(i);
--i;
} else if (mol.getAllConnAtoms$I(i) == 2 && mol.getAtomicNo$I(mol.getConnAtom$I$I(i, 0)) == 1  && mol.getAtomicNo$I(mol.getConnAtom$I$I(i, 1)) == 1 ) {
var atms=Clazz.array(Integer.TYPE, -1, [mol.getAllConnAtoms$I(i), mol.getConnAtom$I$I(i, 0), mol.getConnAtom$I$I(i, 1)]);
$I$(10).sort$IA(atms);
for (var j=2; j >= 0; j--) mol.deleteAtom$I(atms[j]);

i-=3;
}}}
}, 1);

Clazz.newMeth(C$, 'removeWaterSalts$com_actelion_research_chem_Molecule3D',  function (mol) {
var groups=C$.getConnexComponents$com_actelion_research_chem_Molecule3D(mol);
var toRemove=Clazz.new_($I$(1,1));
for (var i=0; i < groups.size$(); i++) {
var group=groups.get$I(i);
if (group.size$() > 20 || group.size$() > (mol.getAtoms$()/30|0)  || mol.isAtomFlag$I$I((group.get$I(0)).$c(), 2) ) continue;
toRemove.addAll$java_util_Collection(groups.get$I(i));
}
mol.deleteAtoms$java_util_List(toRemove);
}, 1);

Clazz.newMeth(C$, 'removeLigand$com_actelion_research_chem_Molecule3D',  function (mol) {
for (var i=mol.getAllAtoms$() - 1; i >= 0; i--) {
if (mol.isAtomFlag$I$I(i, 2)) {
mol.deleteAtom$I(i);
}}
}, 1);

Clazz.newMeth(C$, 'crop$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates$D',  function (mol, center, radius) {
var res=Clazz.new_($I$(7,1));
var molToCrop=Clazz.new_($I$(16,1));
var nonIndivuals=Clazz.new_($I$(13,1));
for (var i=0; i < mol.getAllAtoms$(); i++) {
var c=mol.getCoordinates$I(i);
if (center.distance$com_actelion_research_chem_Coordinates(c) <= radius ) {
var n=res.addAtom$com_actelion_research_chem_Molecule3D$I(mol, i);
molToCrop.put$O$O(Integer.valueOf$I(i), Integer.valueOf$I(n));
if (mol.getAllConnAtoms$I(i) != 0) nonIndivuals.add$O(Integer.valueOf$I(n));
}}
for (var i=0; i < mol.getAllBonds$(); i++) {
var mol1=mol.getBondAtom$I$I(0, i);
var mol2=mol.getBondAtom$I$I(1, i);
var crop1=molToCrop.get$O(Integer.valueOf$I(mol1));
var crop2=molToCrop.get$O(Integer.valueOf$I(mol2));
if (crop1 != null  && crop2 != null  ) {
res.addBond$I$I$I(crop1.intValue$(), crop2.intValue$(), mol.getBondOrder$I(i));
}}
for (var i=res.getAllAtoms$() - 1; i >= 0; i--) {
if (res.getAllConnAtoms$I(i) == 0 && nonIndivuals.contains$O(Integer.valueOf$I(i)) ) {
res.deleteAtom$I(i);
}}
res.setName$S(mol.getName$() + (res.getAllAtoms$() < mol.getAllAtoms$() ? " Crop" : ""));
res.getAuxiliaryInfos$().putAll$java_util_Map(mol.getAuxiliaryInfos$());
return res;
}, 1);

Clazz.newMeth(C$, 'cropLigand$com_actelion_research_chem_Molecule3D$D',  function (mol, radius) {
return null;
}, 1);

Clazz.newMeth(C$, 'markLigand$com_actelion_research_chem_Molecule3D$I',  function (mol, n) {
return -1;
}, 1);

Clazz.newMeth(C$, 'markLigands$com_actelion_research_chem_Molecule3D',  function (mol) {
var l=C$.getConnexComponents$com_actelion_research_chem_Molecule3D(mol);
var potentials=Clazz.new_($I$(17,1));
for (var i=0; i < l.size$(); i++) {
var group=l.get$I(i);
if (l.size$() > 1 && (group.size$() > 90 || group.size$() < 7 ) ) continue;
potentials.add$O(Integer.valueOf$I(i));
}
for (var i=0; i < l.size$(); i++) {
var group=l.get$I(i);
for (var j=0; j < group.size$(); j++) {
var atom=(group.get$I(j)).$c();
if (potentials.contains$O(Integer.valueOf$I(i))) {
mol.setAtomFlag$I$I$Z(atom, 2, true);
mol.setAtomFlag$I$I$Z(atom, 1, false);
} else {
mol.setAtomFlag$I$I$Z(atom, 1, true);
mol.setAtomFlag$I$I$Z(atom, 2, false);
}}
}
}, 1);

Clazz.newMeth(C$, 'markLigand$com_actelion_research_chem_Molecule3D',  function (mol) {
return true;
}, 1);

Clazz.newMeth(C$, 'getCenter$com_actelion_research_chem_Molecule3D',  function (mol) {
var sum=Clazz.new_($I$(15,1));
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
sum=sum.addC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(i));
++n;
}
return n == 0 ? null : sum.scaleC$D(1.0 / n);
}, 1);

Clazz.newMeth(C$, 'getLigandCenter$com_actelion_research_chem_Molecule3D',  function (mol) {
var sum=Clazz.new_($I$(15,1));
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) > 1 && mol.isAtomFlag$I$I(i, 2) ) {
sum=sum.addC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(i));
++n;
}}
return n == 0 ? null : sum.scaleC$D(1.0 / n);
}, 1);

Clazz.newMeth(C$, 'getLigandBounds$com_actelion_research_chem_Molecule3D',  function (mol) {
return C$.getBounds$com_actelion_research_chem_Molecule3D$I(mol, 2);
}, 1);

Clazz.newMeth(C$, 'getBounds$com_actelion_research_chem_Molecule3D',  function (mol) {
return C$.getBounds$com_actelion_research_chem_Molecule3D$I(mol, 0);
}, 1);

Clazz.newMeth(C$, 'getBounds$com_actelion_research_chem_Molecule3D$I',  function (mol, flags) {
var min=Clazz.new_($I$(15,1).c$$D$D$D,[1.7976931348623157E308, 1.7976931348623157E308, 1.7976931348623157E308]);
var max=Clazz.new_($I$(15,1).c$$D$D$D,[-1.7976931348623157E308, -1.7976931348623157E308, -1.7976931348623157E308]);
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (flags == 0 || (mol.getAtomFlags$I(i) & flags) > 0 ) {
min.x=Math.min(min.x, mol.getAtomX$I(i));
min.y=Math.min(min.y, mol.getAtomY$I(i));
min.z=Math.min(min.z, mol.getAtomZ$I(i));
max.x=Math.max(max.x, mol.getAtomX$I(i));
max.y=Math.max(max.y, mol.getAtomY$I(i));
max.z=Math.max(max.z, mol.getAtomZ$I(i));
}}
if (min.x > max.x ) return null;
return Clazz.array($I$(15), -1, [min, max]);
}, 1);

Clazz.newMeth(C$, 'getLigandRMSD$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D',  function (mol1, mol2) {
var sumSq=0;
var n=0;
for (var i1=0; i1 < mol1.getAllAtoms$(); i1++) {
if (!mol1.isAtomFlag$I$I(i1, 2) || mol1.getAtomicNo$I(i1) <= 1 ) continue;
var s1=C$.getAtomHashkey$com_actelion_research_chem_Molecule3D$I(mol1, i1);
var bestDistSq=1.7976931348623157E308;
var bestAtom=-1;
for (var i2=0; i2 < mol2.getAllAtoms$(); i2++) {
if (!mol2.isAtomFlag$I$I(i2, 2) || mol2.getAtomicNo$I(i2) != mol1.getAtomicNo$I(i1) ) continue;
var s2=C$.getAtomHashkey$com_actelion_research_chem_Molecule3D$I(mol2, i2);
if (Long.$ne(s1,s2 )) continue;
var distSq=mol1.getCoordinates$I(i1).distSquareTo$com_actelion_research_chem_Coordinates(mol2.getCoordinates$I(i2));
if (distSq < bestDistSq ) {
bestDistSq=distSq;
bestAtom=i2;
}}
if (bestAtom < 0) return -1;
sumSq+=bestDistSq;
++n;
}
var res=Math.sqrt(sumSq / n);
return res;
}, 1);

Clazz.newMeth(C$, 'translateLigand$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates',  function (mol, v) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.isAtomFlag$I$I(i, 2)) {
mol.setCoordinates$I$com_actelion_research_chem_Coordinates(i, mol.getCoordinates$I(i).addC$com_actelion_research_chem_Coordinates(v));
}}
}, 1);

Clazz.newMeth(C$, 'rotateLigand$com_actelion_research_chem_Molecule3D$D$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates',  function (mol, angle, normal, center) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.isAtomFlag$I$I(i, 2)) {
mol.setCoordinates$I$com_actelion_research_chem_Coordinates(i, mol.getCoordinates$I(i).subC$com_actelion_research_chem_Coordinates(center).rotate$com_actelion_research_chem_Coordinates$D(normal, angle).addC$com_actelion_research_chem_Coordinates(center));
}}
}, 1);

Clazz.newMeth(C$, 'vibrateLigand$com_actelion_research_chem_Molecule3D$D',  function (mol, radius) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.isAtomFlag$I$I(i, 2)) {
var v=Clazz.new_([Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5],$I$(15,1).c$$D$D$D);
if (v.dist$() > 0 ) {
v=v.unitC$().scaleC$D(Math.random() * radius);
}mol.setCoordinates$I$com_actelion_research_chem_Coordinates(i, mol.getCoordinates$I(i).addC$com_actelion_research_chem_Coordinates(v));
}}
}, 1);

Clazz.newMeth(C$, 'getAtomHashkey$com_actelion_research_chem_Molecule3D$I',  function (mol, a) {
var res=0;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var a1=mol.getConnAtom$I$I(a, i);
if (mol.getAtomicNo$I(a1) <= 1) continue;
(res=Long.$add(res,((mol.getAtomicNo$I(a1) * 10 + mol.getConnBondOrder$I$I(a, i)) * 100)));
for (var j=0; j < mol.getAllConnAtoms$I(a1); j++) {
var a2=mol.getConnAtom$I$I(a1, j);
if (mol.getAtomicNo$I(a2) <= 1) continue;
(res=Long.$add(res,((mol.getAtomicNo$I(a2) * 10 + mol.getConnBondOrder$I$I(a1, j)))));
}
}
res=Long.$add(Long.$mul(res,100),mol.getAtomicNo$I(a));
return res;
}, 1);

Clazz.newMeth(C$, 'makeProteinFlexible$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates$D$Z',  function (mol, center, radius, keepBackboneRigid) {
return -1;
}, 1);

Clazz.newMeth(C$, 'makeProteinRigid$com_actelion_research_chem_Molecule3D',  function (mol) {
for (var a=mol.getAllAtoms$() - 1; a >= 0; a--) {
if (!mol.isAtomFlag$I$I(a, 2)) {
if (mol.getAtomicNo$I(a) <= 1) mol.deleteAtom$I(a);
mol.setAtomFlag$I$I$Z(a, 1, true);
}}
}, 1);

Clazz.newMeth(C$, 'getHDonorsAcceptors$com_actelion_research_chem_ExtendedMolecule',  function (m) {
var res=Clazz.array(Integer.TYPE, [2]);
for (var i=0; i < m.getAllAtoms$(); i++) {
if (m.getAtomicNo$I(i) != 8 && m.getAtomicNo$I(i) != 7 ) continue;
if (m.getAllHydrogens$I(i) > 0) ++res[0];
++res[1];
}
return res;
}, 1);

Clazz.newMeth(C$, 'isDonor$com_actelion_research_chem_Molecule3D$I',  function (m, a) {
var atomicNo=m.getAtomicNo$I(a);
var isPolar=(atomicNo == 7 || atomicNo == 8  || atomicNo == 15  || atomicNo == 16 );
if (!isPolar) return false;
return C$.getExplicitHydrogens$com_actelion_research_chem_Molecule3D$I(m, a) > 0 || C$.getImplicitHydrogens$com_actelion_research_chem_Molecule3D$I(m, a) > 0 ;
}, 1);

Clazz.newMeth(C$, 'isAcceptor$com_actelion_research_chem_Molecule3D$I',  function (m, a) {
return false;
}, 1);

Clazz.newMeth(C$, 'flagBackbone$com_actelion_research_chem_Molecule3D',  function (mol) {
var backbone=C$.getBackbones$com_actelion_research_chem_Molecule3D(mol);
for (var i=0; i < backbone.length; i++) {
mol.setAtomFlag$I$I$Z(i, 4, backbone[i]);
}
}, 1);

Clazz.newMeth(C$, 'connected$com_actelion_research_chem_Molecule3D$I$I$I',  function (mol, a, atomicNo, bondOrder) {
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var atm=mol.getConnAtom$I$I(a, i);
if (atomicNo >= 0 && mol.getAtomicNo$I(atm) != atomicNo ) continue;
if (bondOrder > 0 && mol.getConnBondOrder$I$I(a, i) != bondOrder ) continue;
return atm;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'rotateBond$com_actelion_research_chem_Molecule3D$I$I$D',  function (mol, a2, a3, angle) {
var seen=Clazz.new_($I$(17,1));
seen.add$O(Integer.valueOf$I(a2));
C$.dfs$com_actelion_research_chem_Molecule3D$I$java_util_Set(mol, a3, seen);
var normal=mol.getCoordinates$I(a3).subC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a2)).unitC$();
for (var j, $j = seen.iterator$(); $j.hasNext$()&&((j=($j.next$()).intValue$()),1);) {
var c=mol.getCoordinates$I(j).subC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a3));
mol.setCoordinates$I$com_actelion_research_chem_Coordinates(j, c.rotate$com_actelion_research_chem_Coordinates$D(normal, angle).addC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a3)));
}
}, 1);

Clazz.newMeth(C$, 'removeLonePairs$com_actelion_research_chem_Molecule3D',  function (mol) {
var changed=false;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 0) {
mol.deleteAtom$I(i);
--i;
changed=true;
}}
return changed;
}, 1);

Clazz.newMeth(C$, 'getDistanceMatrix$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D',  function (m1, m2) {
var dist=Clazz.array(Double.TYPE, [m1.getAllAtoms$(), m2.getAllAtoms$()]);
for (var a1=0; a1 < m1.getAllAtoms$(); a1++) {
for (var a2=0; a2 < m2.getAllAtoms$(); a2++) {
dist[a1][a2]=m1.getCoordinates$I(a1).distance$com_actelion_research_chem_Coordinates(m2.getCoordinates$I(a2));
}
}
return dist;
}, 1);

Clazz.newMeth(C$, 'getOverlap$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D',  function (m1, m2) {
var N1=m1.getAllAtoms$();
var N2=m2.getAllAtoms$();
var dist=C$.getDistanceMatrix$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D(m1, m2);
for (var a1=0; a1 < N1; a1++) {
for (var a2=0; a2 < N2; a2++) {
if (m1.getAtomicNo$I(a1) != m2.getAtomicNo$I(a2)) dist[a1][a2]+=0.3;
}
}
var seen=Clazz.array(Boolean.TYPE, [N2]);
var sum1=0;
var sum2=0;
while (true){
var min=null;
for (var a2=0; a2 < N2; a2++) {
if (m2.getAtomicNo$I(a2) <= 1) continue;
if (seen[a2]) continue;
for (var a1=0; a1 < N1; a1++) {
if (m1.getAtomicNo$I(a1) <= 1) continue;
if (min == null  || dist[a1][a2] < dist[min[0]][min[1]]  ) min=Clazz.array(Integer.TYPE, -1, [a1, a2]);
}
}
if (min == null ) break;
seen[min[1]]=true;
var d=dist[min[0]][min[1]];
if (d < 0.75 ) {
++sum1;
} else if (d < 1.4 ) {
++sum2;
}}
return Clazz.array(Integer.TYPE, -1, [sum1, sum2]);
}, 1);

Clazz.newMeth(C$, 'getMolecularPathCount$com_actelion_research_chem_Molecule3D$I',  function (mol, length) {
var dists=C$.getNumberOfBondsBetweenAtoms$com_actelion_research_chem_Molecule3D$I$IAA(mol, length, null);
var count=0;
for (var i=0; i < dists.length; i++) {
for (var j=i; j < dists.length; j++) {
if (dists[i][j] == length) ++count;
}
}
return count;
}, 1);

Clazz.newMeth(C$, 'getFragmentMatches$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D',  function (fragment, mol) {
var res=Clazz.new_($I$(1,1));
C$.getFragmentMatchesRec$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA$I$java_util_List(fragment, mol, Clazz.array(Integer.TYPE, [fragment.getAllAtoms$()]), 0, res);
return res;
}, 1);

Clazz.newMeth(C$, 'getFragmentMatchesRec$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA$I$java_util_List',  function (fragment, mol, match, fragmentMatchIndex, res) {
if (fragmentMatchIndex >= fragment.getAllAtoms$()) {
res.add$O(match.clone$());
} else {
 atomLoop : for (var a=0; a < mol.getNMovables$(); a++) {
if (fragment.getAtomicNo$I(fragmentMatchIndex) != 6 && fragment.getAtomicNo$I(fragmentMatchIndex) != mol.getAtomicNo$I(a) ) continue atomLoop;
for (var i=0; i < fragmentMatchIndex; i++) {
if (match[i] == a) continue atomLoop;
}
for (var j=0; j < fragment.getConnAtoms$I(fragmentMatchIndex); j++) {
var connAtom=fragment.getConnAtom$I$I(fragmentMatchIndex, j);
if (connAtom >= fragmentMatchIndex) continue;
var b=mol.getBond$I$I(a, match[connAtom]);
if (b < 0) continue atomLoop;
}
match[fragmentMatchIndex]=a;
C$.getFragmentMatchesRec$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$IA$I$java_util_List(fragment, mol, match, fragmentMatchIndex + 1, res);
}
}}, 1);

Clazz.newMeth(C$, 'getHBonds$com_actelion_research_chem_Molecule3D',  function (m) {
var donor=Clazz.array(Integer.TYPE, [m.getAllAtoms$()]);
var acceptor=Clazz.array(Integer.TYPE, [m.getAllAtoms$()]);
for (var i=0; i < m.getAllAtoms$(); i++) {
if (m.getAtomicNo$I(i) != 8 && m.getAtomicNo$I(i) != 7  && m.getAtomicNo$I(i) != 16 ) continue;
donor[i]=C$.getImplicitHydrogens$com_actelion_research_chem_Molecule3D$I(m, i) + C$.getExplicitHydrogens$com_actelion_research_chem_Molecule3D$I(m, i);
acceptor[i]=m.getAtomicNo$I(i) == 8 ? 2 : m.getAtomicNo$I(i) == 7 ? 1 : 0;
}
var res=Clazz.new_($I$(1,1));
var grid=Clazz.new_($I$(18,1).c$$com_actelion_research_chem_StereoMolecule,[m]);
for (var i=0; i < m.getNMovables$(); i++) {
if (!m.isAtomFlag$I$I(i, 2)) continue;
if (donor[i] == 0 && acceptor[i] == 0 ) continue;
var neighbours=grid.getNeighbours$com_actelion_research_chem_Coordinates$D(m.getCoordinates$I(i), 5);
for (var iter=neighbours.iterator$(); iter.hasNext$(); ) {
var a=(iter.next$()).intValue$();
if (m.isAtomFlag$I$I(a, 2)) continue;
if (!((donor[i] > 0 && acceptor[a] > 0 ) || (donor[a] > 0 && acceptor[i] > 0 ) )) continue;
var d=Math.sqrt(m.getCoordinates$I(a).distSquareTo$com_actelion_research_chem_Coordinates(m.getCoordinates$I(i)));
var vdw=$I$(19).VDW_RADIUS[m.getAtomicNo$I(a)] + $I$(19).VDW_RADIUS[m.getAtomicNo$I(i)];
if (d > vdw - 0.5  && d < vdw + 0.5  ) {
var hbond=false;
for (var j=0; j < m.getAllConnAtoms$I(i); j++) {
if (m.getAtomicNo$I(m.getConnAtom$I$I(i, j)) <= 1) continue;
for (var k=0; k < m.getAllConnAtoms$I(a); k++) {
if (m.getAtomicNo$I(m.getConnAtom$I$I(a, k)) <= 1) continue;
var c1=m.getCoordinates$I(i).subC$com_actelion_research_chem_Coordinates(m.getCoordinates$I(m.getConnAtom$I$I(i, j)));
var c2=m.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(m.getCoordinates$I(m.getConnAtom$I$I(a, k)));
var angle=c1.getAngle$com_actelion_research_chem_Coordinates(c2);
if (Math.abs(2.0943951023931953 - angle) < 0.3141592653589793 ) hbond=true;
if (Math.abs(1.0471975511965976 - angle) < 0.3141592653589793 ) hbond=true;
}
}
if (hbond) {
res.add$O(Clazz.array(Integer.TYPE, -1, [i, a]));
}}}
}
return res;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.StructureCalculator, "Item", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.path=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['I',['a'],'O',['path','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$$I',  function (a) {
;C$.$init$.apply(this);
this.a=a;
this.path.add$O(Integer.valueOf$I(a));
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.StructureCalculator, "Node", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atm','bond'],'O',['parent','com.actelion.research.chem.descriptor.flexophore.calculator.StructureCalculator.Node']]]

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_descriptor_flexophore_calculator_StructureCalculator_Node$I',  function (value, parent, bondToParent) {
;C$.$init$.apply(this);
this.atm=value;
this.parent=parent;
this.bond=bondToParent;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
var n=this.parent;
var r="{" + this.atm;
while (n != null ){
r+="," + n.atm;
n=n.parent;
}
return r + "}";
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
