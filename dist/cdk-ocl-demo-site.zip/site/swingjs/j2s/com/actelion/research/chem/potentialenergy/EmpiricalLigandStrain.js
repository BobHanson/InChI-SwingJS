(function(){var P$=Clazz.newPackage("com.actelion.research.chem.potentialenergy"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','com.actelion.research.chem.docking.scoring.idoscore.InteractionTerm','com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionTerm','java.util.HashSet',['java.util.AbstractMap','.SimpleEntry']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EmpiricalLigandStrain", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['conf','com.actelion.research.chem.conf.Conformer','strain','java.util.List','torsionHelper','com.actelion.research.chem.conf.BondRotationHelper','ligAtomPairs','java.util.List','atomTypes','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$IA$com_actelion_research_chem_conf_BondRotationHelper',  function (conf, atomTypes, torsionHelper) {
;C$.$init$.apply(this);
this.conf=conf;
this.atomTypes=atomTypes;
this.torsionHelper=torsionHelper;
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
var mol=this.conf.getMolecule$();
this.strain=Clazz.new_($I$(1,1));
this.ligAtomPairs=Clazz.new_($I$(1,1));
var ligAtomTypesList=Clazz.new_($I$(1,1));
for (var a=0; a < mol.getAtoms$(); a++) ligAtomTypesList.add$O(Integer.valueOf$I($I$(2).getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, a)));

p$1.findLigAtomPairs.apply(this, []);
for (var pair, $pair = this.ligAtomPairs.iterator$(); $pair.hasNext$()&&((pair=($pair.next$())),1);) {
var at1=pair[0];
var at2=pair[1];
var term=$I$(3).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$IA(this.conf, this.conf, at1, at2, this.atomTypes, this.atomTypes);
if (term == null ) continue;
this.strain.add$O(term);
}
for (var b=0; b < this.conf.getMolecule$().getBonds$(); b++) {
for (var rotBondIndex=0; rotBondIndex < this.torsionHelper.getRotatableBonds$().length; rotBondIndex++) {
var rotBond=this.torsionHelper.getRotatableBonds$()[rotBondIndex];
if (b == rotBond) {
var torsionAtoms=this.torsionHelper.getTorsionAtoms$()[rotBondIndex];
var torsionID=this.torsionHelper.getTorsionIDs$()[rotBondIndex];
var term=$I$(4).create$com_actelion_research_chem_conf_Conformer$IA$S(this.conf, torsionAtoms, torsionID);
if (term == null ) continue;
this.strain.add$O(term);
break;
}}
}
}, p$1);

Clazz.newMeth(C$, 'findLigAtomPairs',  function () {
var invalidPairs=Clazz.new_($I$(5,1));
var mol=this.conf.getMolecule$();
for (var a=0; a < mol.getAtoms$(); a++) {
for (var i=0; i < mol.getConnAtoms$I(a); i++) {
var aa=mol.getConnAtom$I$I(a, i);
var entry=a < aa ? Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aa)],$I$(6,1).c$$O$O) : Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aa)],$I$(6,1).c$$O$O);
invalidPairs.add$O(entry);
for (var j=0; j < mol.getConnAtoms$I(aa); j++) {
var aaa=mol.getConnAtom$I$I(aa, j);
entry=a < aaa ? Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aaa)],$I$(6,1).c$$O$O) : Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aaa)],$I$(6,1).c$$O$O);
invalidPairs.add$O(entry);
for (var k=0; k < mol.getConnAtoms$I(aaa); k++) {
var aaaa=mol.getConnAtom$I$I(aaa, k);
entry=a < aaaa ? Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aaaa)],$I$(6,1).c$$O$O) : Clazz.new_([Integer.valueOf$I(a), Integer.valueOf$I(aaaa)],$I$(6,1).c$$O$O);
invalidPairs.add$O(entry);
}
}
}
}
for (var i=0; i < mol.getAtoms$(); i++) {
for (var j=i + 1; j < mol.getAtoms$(); j++) {
var entry=Clazz.new_([Integer.valueOf$I(i), Integer.valueOf$I(j)],$I$(6,1).c$$O$O);
if (invalidPairs.contains$O(entry)) continue;
 else this.ligAtomPairs.add$O(Clazz.array(Integer.TYPE, -1, [i, j]));
}
}
}, p$1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (grad) {
var energy=0.0;
for (var term, $term = this.strain.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
energy+=term.getFGValue$DA(grad);
}
return energy;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
