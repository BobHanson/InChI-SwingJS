(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ForceField");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-03-26 13:45:24 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
