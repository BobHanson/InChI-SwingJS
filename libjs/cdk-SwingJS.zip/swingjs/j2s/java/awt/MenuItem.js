(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MenuItem", null, 'swingjs.a2s.MenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (label) {
;C$.superclazz.c$$S.apply(this,[label]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_MenuShortcut',  function (label, s) {
;C$.superclazz.c$$S$java_awt_MenuShortcut.apply(this,[label, s]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-17 16:36:51 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
