(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.gif"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "GIFStreamMetadataFormatResources", null, 'java.util.ListResourceBundle');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getContents$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["Version", "The file version, either 87a or 89a"]), Clazz.array(java.lang.Object, -1, ["LogicalScreenDescriptor", "The logical screen descriptor, except for the global color table"]), Clazz.array(java.lang.Object, -1, ["GlobalColorTable", "The global color table"]), Clazz.array(java.lang.Object, -1, ["ColorTableEntry", "A global color table entry"]), Clazz.array(java.lang.Object, -1, ["Version/value", "The version string"]), Clazz.array(java.lang.Object, -1, ["LogicalScreenDescriptor/logicalScreenWidth", "The width in pixels of the whole picture"]), Clazz.array(java.lang.Object, -1, ["LogicalScreenDescriptor/logicalScreenHeight", "The height in pixels of the whole picture"]), Clazz.array(java.lang.Object, -1, ["LogicalScreenDescriptor/colorResolution", "The number of bits of color resolution, beteen 1 and 8"]), Clazz.array(java.lang.Object, -1, ["LogicalScreenDescriptor/pixelAspectRatio", "If 0, indicates square pixels, else W/H = (value + 15)/64"]), Clazz.array(java.lang.Object, -1, ["GlobalColorTable/sizeOfGlobalColorTable", "The number of entries in the global color table"]), Clazz.array(java.lang.Object, -1, ["GlobalColorTable/backgroundColorIndex", "The index of the color table entry to be used as a background"]), Clazz.array(java.lang.Object, -1, ["GlobalColorTable/sortFlag", "True if the global color table is sorted by frequency"]), Clazz.array(java.lang.Object, -1, ["ColorTableEntry/index", "The index of the color table entry"]), Clazz.array(java.lang.Object, -1, ["ColorTableEntry/red", "The red value for the color table entry"]), Clazz.array(java.lang.Object, -1, ["ColorTableEntry/green", "The green value for the color table entry"]), Clazz.array(java.lang.Object, -1, ["ColorTableEntry/blue", "The blue value for the color table entry"])]);
});
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-17 16:36:42 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
