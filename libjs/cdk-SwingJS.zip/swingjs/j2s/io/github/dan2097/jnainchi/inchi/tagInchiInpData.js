(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagInchiInpData", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.szErrMsg=Clazz.array(Byte.TYPE, [256]);
},1);

C$.$fields$=[['I',['bChiral'],'O',['pInp','io.github.dan2097.jnainchi.inchi.tagINCHI_Input','szErrMsg','byte[]']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["pInp", "bChiral", "szErrMsg"])]);
});

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_inchi_tagINCHI_Input$I$BA',  function (pInp, bChiral, szErrMsg) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.pInp=pInp;
this.bChiral=bChiral;
if ((szErrMsg.length != this.szErrMsg.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.szErrMsg=szErrMsg;
}, 1);

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_inchi_tagINCHI_Input',  function (pInp) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.pInp=pInp;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-11 17:50:54 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
