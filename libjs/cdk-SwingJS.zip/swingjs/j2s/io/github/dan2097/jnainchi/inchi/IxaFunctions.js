(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_ATOMID'],'com.sun.jna.Pointer',['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_STATUS_HANDLE'],'io.github.dan2097.jnainchi.inchi.InchiLibrary',['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_MOL_HANDLE'],['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_BONDID'],['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_STEREOID'],['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_INCHIBUILDER_HANDLE'],['io.github.dan2097.jnainchi.inchi.IxaFunctions','.IXA_INCHIKEYBUILDER_HANDLE']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IxaFunctions", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['IXA_ATOMID',9],['IXA_BONDID',9],['IXA_INCHIBUILDER_HANDLE',9],['IXA_INCHIKEYBUILDER_HANDLE',9],['IXA_MOL_HANDLE',9],['IXA_POLYMERUNITID',9],['IXA_STATUS_HANDLE',9],['IXA_STEREOID',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['IXA_ATOMID_IMPLICIT_H','io.github.dan2097.jnainchi.inchi.IxaFunctions.IXA_ATOMID']]]

Clazz.newMeth(C$, 'IXA_STATUS_Create$',  function () {
return Clazz.new_([$I$(4).IXA_STATUS_Create$()],$I$(3,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_Clear$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
$I$(4,"IXA_STATUS_Clear$com_sun_jna_Pointer",[hStatus.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
$I$(4,"IXA_STATUS_Destroy$com_sun_jna_Pointer",[hStatus.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_HasError$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return $I$(4,"IXA_STATUS_HasError$com_sun_jna_Pointer",[hStatus.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_HasWarning$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return $I$(4,"IXA_STATUS_HasWarning$com_sun_jna_Pointer",[hStatus.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetCount$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return $I$(4,"IXA_STATUS_GetCount$com_sun_jna_Pointer",[hStatus.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetSeverity$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$I',  function (hStatus, vIndex) {
return $I$(4,"IXA_STATUS_GetSeverity$com_sun_jna_Pointer$I",[hStatus.getPointer$(), vIndex]);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetMessage$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$I',  function (hStatus, vIndex) {
return $I$(4,"IXA_STATUS_GetMessage$com_sun_jna_Pointer$I",[hStatus.getPointer$(), vIndex]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return Clazz.new_([$I$(4,"IXA_MOL_Create$com_sun_jna_Pointer",[hStatus.getPointer$()])],$I$(5,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Clear$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
$I$(4,"IXA_MOL_Clear$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
$I$(4,"IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReadMolfile$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$S',  function (hStatus, hMolecule, pBytes) {
$I$(4,"IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus.getPointer$(), hMolecule.getPointer$(), C$.fromString$S(pBytes)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReadInChI$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$S',  function (hStatus, hMolecule, pInChI) {
$I$(4,"IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus.getPointer$(), hMolecule.getPointer$(), C$.fromString$S(pInChI)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetChiral$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$Z',  function (hStatus, hMolecule, vChiral) {
$I$(4,"IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z",[hStatus.getPointer$(), hMolecule.getPointer$(), vChiral]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetChiral$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
return $I$(4,"IXA_MOL_GetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateAtom$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
return Clazz.new_([$I$(4,"IXA_MOL_CreateAtom$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomElement$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$S',  function (hStatus, hMolecule, vAtom, pElement) {
$I$(4,"IXA_MOL_SetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), C$.fromString$S(pElement)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomAtomicNumber$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vAtomicNumber) {
$I$(4,"IXA_MOL_SetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vAtomicNumber]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomMass$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vMassNumber) {
$I$(4,"IXA_MOL_SetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vMassNumber]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomCharge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vCharge) {
$I$(4,"IXA_MOL_SetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vCharge]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomRadical$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vRadical) {
$I$(4,"IXA_MOL_SetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vRadical]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber, vHydrogenCount) {
$I$(4,"IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vHydrogenMassNumber, vHydrogenCount]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomX$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D',  function (hStatus, hMolecule, vAtom, vX) {
$I$(4,"IXA_MOL_SetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vX]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomY$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D',  function (hStatus, hMolecule, vAtom, vY) {
$I$(4,"IXA_MOL_SetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vY]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomZ$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D',  function (hStatus, hMolecule, vAtom, vZ) {
$I$(4,"IXA_MOL_SetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vZ]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom1, vAtom2) {
return Clazz.new_([$I$(4,"IXA_MOL_CreateBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom1.getPointer$(), vAtom2.getPointer$()])],$I$(6,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetBondType$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$I',  function (hStatus, hMolecule, vBond, vType) {
$I$(4,"IXA_MOL_SetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$(), vType]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vBond, vRefAtom, vDirection) {
$I$(4,"IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$(), vRefAtom.getPointer$(), vDirection]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetDblBondConfig$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$I',  function (hStatus, hMolecule, vBond, vConfig) {
$I$(4,"IXA_MOL_SetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$(), vConfig]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoTetrahedron$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
return Clazz.new_([$I$(4,"IXA_MOL_CreateStereoTetrahedron$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vCentralAtom.getPointer$(), vVertex1.getPointer$(), vVertex2.getPointer$(), vVertex3.getPointer$(), vVertex4.getPointer$()])],$I$(7,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoRectangle$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vCentralBond, vVertex1, vVertex2, vVertex3, vVertex4) {
return Clazz.new_([$I$(4,"IXA_MOL_CreateStereoRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vCentralBond.getPointer$(), vVertex1.getPointer$(), vVertex2.getPointer$(), vVertex3.getPointer$(), vVertex4.getPointer$()])],$I$(7,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoAntiRectangle$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
return Clazz.new_([$I$(4,"IXA_MOL_CreateStereoAntiRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vCentralAtom.getPointer$(), vVertex1.getPointer$(), vVertex2.getPointer$(), vVertex3.getPointer$(), vVertex4.getPointer$()])],$I$(7,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetStereoParity$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID$I',  function (hStatus, hMolecule, vStereo, vParity) {
$I$(4,"IXA_MOL_SetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$(), vParity]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReserveSpace$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$I$I$I',  function (hStatus, hMolecule, num_atoms, num_bonds, num_stereos) {
return $I$(4,"IXA_MOL_ReserveSpace$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I$I",[hStatus.getPointer$(), hMolecule.getPointer$(), num_atoms, num_bonds, num_stereos]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumAtoms$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
return $I$(4,"IXA_MOL_GetNumAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumBonds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
return $I$(4,"IXA_MOL_GetNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomId$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$I',  function (hStatus, hMolecule, vAtomIndex) {
return Clazz.new_([$I$(4,"IXA_MOL_GetAtomId$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtomIndex])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondId$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$I',  function (hStatus, hMolecule, vBondIndex) {
return Clazz.new_([$I$(4,"IXA_MOL_GetBondId$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vBondIndex])],$I$(6,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomIndex$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondIndex$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID',  function (hStatus, hMolecule, vBond) {
return $I$(4,"IXA_MOL_GetBondIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomNumBonds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vBondIndex) {
return Clazz.new_([$I$(4,"IXA_MOL_GetAtomBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vBondIndex])],$I$(6,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetCommonBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom1, vAtom2) {
return Clazz.new_([$I$(4,"IXA_MOL_GetCommonBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom1.getPointer$(), vAtom2.getPointer$()])],$I$(6,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom1$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID',  function (hStatus, hMolecule, vBond) {
return Clazz.new_([$I$(4,"IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$()])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom2$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID',  function (hStatus, hMolecule, vBond) {
return Clazz.new_([$I$(4,"IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$()])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondOtherAtom$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vBond, vAtom) {
return Clazz.new_([$I$(4,"IXA_MOL_GetBondOtherAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$(), vAtom.getPointer$()])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomElement$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomAtomicNumber$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomMass$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomCharge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomRadical$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber) {
return $I$(4,"IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$(), vHydrogenMassNumber]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomX$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomY$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomZ$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vAtom) {
return $I$(4,"IXA_MOL_GetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondType$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID',  function (hStatus, hMolecule, vBond) {
return $I$(4,"IXA_MOL_GetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID',  function (hStatus, hMolecule, vBond, vRefAtom) {
return $I$(4,"IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$(), vRefAtom.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetDblBondConfig$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID',  function (hStatus, hMolecule, vBond) {
return $I$(4,"IXA_MOL_GetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vBond.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumStereos$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hMolecule) {
return $I$(4,"IXA_MOL_GetNumStereos$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoId$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$I',  function (hStatus, hMolecule, vStereoIndex) {
return Clazz.new_([$I$(4,"IXA_MOL_GetStereoId$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereoIndex])],$I$(7,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoIndex$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return $I$(4,"IXA_MOL_GetStereoIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoTopology$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return $I$(4,"IXA_MOL_GetStereoTopology$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralAtom$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return Clazz.new_([$I$(4,"IXA_MOL_GetStereoCentralAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return Clazz.new_([$I$(4,"IXA_MOL_GetStereoCentralBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()])],$I$(6,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoNumVertices$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return $I$(4,"IXA_MOL_GetStereoNumVertices$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoVertex$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID$I',  function (hStatus, hMolecule, vStereo, vVertexIndex) {
return Clazz.new_([$I$(4,"IXA_MOL_GetStereoVertex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$(), vVertexIndex])],$I$(1,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoParity$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID',  function (hStatus, hMolecule, vStereo) {
return $I$(4,"IXA_MOL_GetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hMolecule.getPointer$(), vStereo.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return Clazz.new_([$I$(4,"IXA_INCHIBUILDER_Create$com_sun_jna_Pointer",[hStatus.getPointer$()])],$I$(8,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetMolecule$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE',  function (hStatus, hInChIBuilder, hMolecule) {
$I$(4,"IXA_INCHIBUILDER_SetMolecule$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), hMolecule.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChI$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE',  function (hStatus, hInChIBuilder) {
return $I$(4,"IXA_INCHIBUILDER_GetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChIEx$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE',  function (hStatus, hBuilder) {
return $I$(4,"IXA_INCHIBUILDER_GetInChIEx$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetAuxInfo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE',  function (hStatus, hInChIBuilder) {
return $I$(4,"IXA_INCHIBUILDER_GetAuxInfo$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetLog$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE',  function (hStatus, hInChIBuilder) {
return $I$(4,"IXA_INCHIBUILDER_GetLog$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE',  function (hStatus, hInChIBuilder) {
$I$(4,"IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z',  function (hStatus, hInChIBuilder, vOption, vValue) {
$I$(4,"IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vOption, vValue]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I',  function (hStatus, hInChIBuilder, vValue) {
$I$(4,"IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vValue]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I',  function (hStatus, hInChIBuilder, vValue) {
$I$(4,"IXA_INCHIBUILDER_SetOption_Timeout$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vValue]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$J',  function (hStatus, hInChIBuilder, vValue) {
$I$(4,"IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$com_sun_jna_Pointer$com_sun_jna_Pointer$J",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vValue]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I',  function (hStatus, hInChIBuilder, vOption) {
return $I$(4,"IXA_INCHIBUILDER_CheckOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vOption]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I',  function (hStatus, hInChIBuilder, vValue) {
return $I$(4,"IXA_INCHIBUILDER_CheckOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I",[hStatus.getPointer$(), hInChIBuilder.getPointer$(), vValue]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE',  function (hStatus) {
return Clazz.new_([$I$(4,"IXA_INCHIKEYBUILDER_Create$com_sun_jna_Pointer",[hStatus.getPointer$()])],$I$(9,1).c$$com_sun_jna_Pointer);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_SetInChI$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIKEYBUILDER_HANDLE$S',  function (hStatus, hInChIKeyBuilder, pInChI) {
$I$(4,"IXA_INCHIKEYBUILDER_SetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus.getPointer$(), hInChIKeyBuilder.getPointer$(), C$.fromString$S(pInChI)]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_GetInChIKey$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIKEYBUILDER_HANDLE',  function (hStatus, hInChIKeyBuilder) {
return $I$(4,"IXA_INCHIKEYBUILDER_GetInChIKey$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIKeyBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIKEYBUILDER_HANDLE',  function (hStatus, hInChIKeyBuilder) {
$I$(4,"IXA_INCHIKEYBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus.getPointer$(), hInChIKeyBuilder.getPointer$()]);
}, 1);

Clazz.newMeth(C$, 'fromString$S',  function (jstr) {
var strLen=jstr.length$();
var cstr=Clazz.array(Byte.TYPE, [strLen + 1]);
for (var i=0; i < strLen; i++) {
cstr[i]=(jstr.charAt$I(i).$c()|0);
}
cstr[strLen]=("\u0000".$c()|0);
return cstr;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.IXA_ATOMID_IMPLICIT_H=Clazz.new_([$I$(2,"createConstant$J",[(Long.$neg(1))])],$I$(1,1).c$$com_sun_jna_Pointer);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_ATOMID", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_BONDID", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_INCHIBUILDER_HANDLE", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_INCHIKEYBUILDER_HANDLE", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_MOL_HANDLE", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_POLYMERUNITID", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_STATUS_HANDLE", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.IxaFunctions, "IXA_STEREOID", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'com.sun.jna.PointerType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer',  function (address) {
;C$.superclazz.c$$com_sun_jna_Pointer.apply(this,[address]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-11 17:50:54 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
