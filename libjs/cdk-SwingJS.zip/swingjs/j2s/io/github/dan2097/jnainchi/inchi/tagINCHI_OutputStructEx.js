(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'com.sun.jna.NativeLong','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagINCHI_OutputStructEx", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.WarningFlags=Clazz.array($I$(1), [(4)]);
},1);

C$.$fields$=[['H',['num_atoms','num_stereo0D'],'S',['szMessage','szLog'],'O',['atom','io.github.dan2097.jnainchi.inchi.tagInchiAtom','stereo0D','io.github.dan2097.jnainchi.inchi.tagINCHIStereo0D','WarningFlags','com.sun.jna.NativeLong[]','polymer','io.github.dan2097.jnainchi.inchi.inchi_Input_Polymer','v3000','io.github.dan2097.jnainchi.inchi.inchi_Input_V3000']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(2,"asList$OA",[Clazz.array(String, -1, ["atom", "stereo0D", "num_atoms", "num_stereo0D", "szMessage", "szLog", "WarningFlags", "polymer", "v3000"])]);
});

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_inchi_tagInchiAtom$io_github_dan2097_jnainchi_inchi_tagINCHIStereo0D$H$H$S$S$com_sun_jna_NativeLongA$io_github_dan2097_jnainchi_inchi_inchi_Input_Polymer$io_github_dan2097_jnainchi_inchi_inchi_Input_V3000',  function (atom, stereo0D, num_atoms, num_stereo0D, szMessage, szLog, WarningFlags, polymer, v3000) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.atom=atom;
this.stereo0D=stereo0D;
this.num_atoms=num_atoms;
this.num_stereo0D=num_stereo0D;
this.szMessage=szMessage;
this.szLog=szLog;
if ((WarningFlags.length != this.WarningFlags.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.WarningFlags=WarningFlags;
this.polymer=polymer;
this.v3000=v3000;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-11 17:50:54 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
