(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InchiKeyOutput");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['inchiKey','szXtra1','szXtra2'],'O',['status','io.github.dan2097.jnainchi.InchiKeyStatus']]]

Clazz.newMeth(C$, 'c$$S$io_github_dan2097_jnainchi_InchiKeyStatus$S$S',  function (inchiKey, status, szXtra1, szXtra2) {
;C$.$init$.apply(this);
this.inchiKey=inchiKey;
this.status=status;
this.szXtra1=szXtra1;
this.szXtra2=szXtra2;
}, 1);

Clazz.newMeth(C$, 'getInchiKey$',  function () {
return this.inchiKey;
});

Clazz.newMeth(C$, 'getStatus$',  function () {
return this.status;
});

Clazz.newMeth(C$, 'getBlock1HashExtension$',  function () {
return this.szXtra1;
});

Clazz.newMeth(C$, 'getBlock2HashExtension$',  function () {
return this.szXtra2;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-14 06:39:30 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
