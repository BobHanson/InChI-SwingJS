(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),p$1={},p$2={},I$=[[0,'io.github.dan2097.jnainchi.InchiBondType',['io.github.dan2097.jnainchi.InchiAPI','.Acid'],'io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.inchi.InchiLibrary','java.util.HashMap','com.sun.jna.Platform',['io.github.dan2097.jnainchi.InchiOptions','.InchiOptionsBuilder'],'io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiOptions','io.github.dan2097.jnainchi.inchi.IXA','io.github.dan2097.jnainchi.InchiRadical','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.InchiStereoType','io.github.dan2097.jnainchi.InchiStereoParity','io.github.dan2097.jnainchi.InchiStereo','io.github.dan2097.jnainchi.InchiOutput','io.github.dan2097.jnainchi.InchiStatus','StringBuilder','io.github.dan2097.jnainchi.InchiKeyOutput','io.github.dan2097.jnainchi.InchiKeyStatus','io.github.dan2097.jnainchi.InchiCheckStatus','io.github.dan2097.jnainchi.InchiKeyCheckStatus','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.InchiInputFromAuxinfoOutput','io.github.dan2097.jnainchi.InchiInputFromInchiOutput','java.util.Locale','java.util.HashSet','java.util.ArrayList','io.github.dan2097.jnainchi.InchiAtom',['io.github.dan2097.jnainchi.InchiAPI','.Amide']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiAPI", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Amide',10],['Acid',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['isJS'],'S',['inchiLibName'],'O',['libraryLoadingError','Throwable','aveMass','java.util.Map']]]

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {
var wasmName=C$.inchiLibName;
{
if (!J2S) { alert("J2S has not been installed");
System.exit(0);
} var t = [];
var f = function(){ if (J2S.wasm && J2S.wasm[wasmName] && J2S.wasm[wasmName].$ready) { t[0] && clearInterval(t[0]);
System.out.println("InChI WASM initialized successfully");
r && r.run$();
return true;
} System.out.println("InChI WASM initializing...");
};
if (f()) { return;} t[0] = setInterval(f, 50);
}
}, 1);

Clazz.newMeth(C$, 'checkLibrary$',  function () {
if (C$.libraryLoadingError != null ) {
var platform=(C$.isJS ? "WASM" : $I$(6).RESOURCE_PREFIX);
throw Clazz.new_(Clazz.load('RuntimeException').c$$S$Throwable,["Error loading InChI native code. Please check that the binaries for your platform (" + platform + ") have been included on the classpath." , C$.libraryLoadingError]);
}}, 1);

Clazz.newMeth(C$, 'getInChIFromInchiInput$io_github_dan2097_jnainchi_InchiInput$S',  function (inchiInput, options) {
return C$.toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(inchiInput, C$.parseOptions$S(options)).getInchi$();
}, 1);

Clazz.newMeth(C$, 'parseOptions$S',  function (options) {
if (options == null ) return null;
var builder=Clazz.new_($I$(7,1));
var s=options.split$S("\\s");
for (var i=0; i < s.length; i++) {
var flag=$I$(8).getFlagFromName$S(s[i]);
if (flag == null ) {
System.err.println$S("InchiAPI unrecognized flag " + s[i]);
} else {
builder.withFlag$io_github_dan2097_jnainchi_InchiFlagA(Clazz.array($I$(8), -1, [flag]));
}}
return builder.build$();
}, 1);

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput',  function (inchiInput) {
return C$.toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(inchiInput, $I$(9).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions',  function (inchiInput, options) {
C$.checkLibrary$();
var atoms=inchiInput.getAtoms$();
var atomCount=atoms.size$();
if (atomCount > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["InChI is limited to 32767 atoms, input contained " + atomCount + " atoms" ]);
}var bonds=inchiInput.getBonds$();
var stereos=inchiInput.getStereos$();
if (stereos.size$() > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Too many stereochemistry elements in input"]);
}var hStatus=$I$(10).IXA_STATUS_Create$();
var hMolecule=$I$(10).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
$I$(10,"IXA_MOL_ReserveSpace$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I$I",[hStatus, hMolecule, atomCount, bonds.size$(), stereos.size$()]);
try {
var atomToNativeAtom=C$.addAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List(hMolecule, hStatus, atoms);
C$.addBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List$java_util_Map(hMolecule, hStatus, bonds, atomToNativeAtom);
C$.addStereos$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List$java_util_Map(hMolecule, hStatus, stereos, atomToNativeAtom);
return C$.buildInchi$com_sun_jna_Pointer$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiOptions(hStatus, hMolecule, options);
} finally {
$I$(10).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(null, hMolecule);
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
}
}, 1);

Clazz.newMeth(C$, 'addAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List',  function (hMolecule, hStatus, atoms) {
var atomToNativeAtom=Clazz.new_($I$(5,1));
for (var atom, $atom = atoms.iterator$(); $atom.hasNext$()&&((atom=($atom.next$())),1);) {
var v;
var iv;
var sv;
var vAtom=$I$(10).IXA_MOL_CreateAtom$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
atomToNativeAtom.put$O$O(atom, vAtom);
if ((v=atom.getX$()) != 0 ) {
$I$(10).IXA_MOL_SetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, v);
}if ((v=atom.getY$()) != 0 ) {
$I$(10).IXA_MOL_SetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, v);
}if ((v=atom.getZ$()) != 0 ) {
$I$(10).IXA_MOL_SetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, v);
}if (!(sv=atom.getElName$()).equals$O("C")) {
if (sv.length$() > 5) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Element name was too long: " + sv]);
}$I$(10).IXA_MOL_SetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, vAtom, sv);
}if ((iv=atom.getIsotopicMass$()) != 0) {
$I$(10).IXA_MOL_SetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, iv);
}if ((iv=atom.getCharge$()) != 0) {
$I$(10).IXA_MOL_SetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, iv);
}if ((iv=$I$(11,"getCodeObj$O",[atom.getRadical$()])) != 0) {
$I$(10).IXA_MOL_SetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, iv);
}if ((iv=atom.getImplicitHydrogen$()) != 0) {
$I$(10).IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I(hStatus, hMolecule, vAtom, 0, iv);
}if ((iv=atom.getImplicitProtium$()) != 0) {
$I$(10).IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I(hStatus, hMolecule, vAtom, 1, iv);
}if ((iv=atom.getImplicitDeuterium$()) != 0) {
$I$(10).IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I(hStatus, hMolecule, vAtom, 2, iv);
}if ((iv=atom.getImplicitTritium$()) != 0) {
$I$(10).IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I(hStatus, hMolecule, vAtom, 3, iv);
}}
return atomToNativeAtom;
}, 1);

Clazz.newMeth(C$, 'addBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List$java_util_Map',  function (hMolecule, hStatus, bonds, atomToNativeAtom) {
for (var bond, $bond = bonds.iterator$(); $bond.hasNext$()&&((bond=($bond.next$())),1);) {
var vAtom1=atomToNativeAtom.get$O(bond.getStart$());
var vAtom2=atomToNativeAtom.get$O(bond.getEnd$());
if (vAtom1 == null  || vAtom2 == null  ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Bond referenced an atom that was not provided"]);
}var vBond=$I$(10).IXA_MOL_CreateBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom1, vAtom2);
var iv;
if ((iv=$I$(1,"getCodeObj$O",[bond.getType$()])) != 1) {
$I$(10).IXA_MOL_SetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, iv);
}switch (iv=$I$(12,"getCodeObj$O",[bond.getStereo$()])) {
case 3:
$I$(10).IXA_MOL_SetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, 1);
break;
case 6:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom1, 2);
break;
case 4:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom1, 3);
break;
case 1:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom1, 1);
break;
case -6:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom2, 2);
break;
case -4:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom2, 3);
break;
case -1:
$I$(10).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vAtom2, 1);
break;
default:
case 0:
break;
}
}
}, 1);

Clazz.newMeth(C$, 'addStereos$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_List$java_util_Map',  function (hMolecule, hStatus, stereos, atomToNativeAtom) {
for (var stereo, $stereo = stereos.iterator$(); $stereo.hasNext$()&&((stereo=($stereo.next$())),1);) {
var type=$I$(13,"getCodeObj$O",[stereo.getType$()]);
if (type == 0) {
continue;
}var neighbors=stereo.getAtoms$();
var vVertex1=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[0]);
var vVertex2=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[1]);
var vVertex3=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[2]);
var vVertex4=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[3]);
var vStereo;
var vCentralAtom;
switch (type) {
case 2:
{
vCentralAtom=C$.getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map(stereo, atomToNativeAtom);
vStereo=$I$(10).IXA_MOL_CreateStereoTetrahedron$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4);
break;
}case 3:
{
vCentralAtom=C$.getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map(stereo, atomToNativeAtom);
vStereo=$I$(10).IXA_MOL_CreateStereoAntiRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4);
break;
}case 1:
{
var vCommonBond=$I$(10).IXA_MOL_GetCommonBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vVertex2, vVertex3);
if (vCommonBond == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Could not find olefin/cumulene central bond"]);
}vStereo=$I$(10,"IXA_MOL_CreateStereoRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer",[hStatus, hMolecule, vCommonBond, vVertex1, $I$(10).ATOM_IMPLICIT_H, $I$(10).ATOM_IMPLICIT_H, vVertex4]);
break;
}default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI stereo type:" + type]);
}
var parity=$I$(14,"getCodeObj$O",[stereo.getParity$()]);
$I$(10).IXA_MOL_SetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vStereo, parity);
}
}, 1);

Clazz.newMeth(C$, 'getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map',  function (stereo, atomToNativeAtom) {
var centralAtom=stereo.getCentralAtom$();
var vCentral=atomToNativeAtom.get$O(centralAtom);
if (vCentral == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration central atom referenced an atom that does not exist"]);
}return vCentral;
}, 1);

Clazz.newMeth(C$, 'getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom',  function (atomToNativeAtom, inchiAtom) {
if ($I$(15).STEREO_IMPLICIT_H === inchiAtom ) {
return $I$(10).ATOM_IMPLICIT_H;
}var vVertex=atomToNativeAtom.get$O(inchiAtom);
if (vVertex == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration referenced an atom that does not exist"]);
}return vVertex;
}, 1);

Clazz.newMeth(C$, 'buildInchi$com_sun_jna_Pointer$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiOptions',  function (hStatus, hMolecule, options) {
if (options == null ) options=$I$(9).DEFAULT_OPTIONS;
var hBuilder=$I$(10).IXA_INCHIBUILDER_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_INCHIBUILDER_SetMolecule$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder, hMolecule);
var timeoutMilliSecs=options.getTimeoutMilliSeconds$();
if (Long.$ne(timeoutMilliSecs,0 )) {
$I$(10).IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$com_sun_jna_Pointer$com_sun_jna_Pointer$J(hStatus, hBuilder, timeoutMilliSecs);
}for (var flag, $flag = options.getFlags$().iterator$(); $flag.hasNext$()&&((flag=($flag.next$())),1);) {
switch (flag) {
case $I$(8).AuxNone:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 9, true);
break;
case $I$(8).ChiralFlagOFF:
$I$(10).IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z(hStatus, hMolecule, false);
break;
case $I$(8).ChiralFlagON:
$I$(10).IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z(hStatus, hMolecule, true);
break;
case $I$(8).DoNotAddH:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 1, true);
break;
case $I$(8).FixedH:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 4, true);
break;
case $I$(8).KET:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 6, true);
break;
case $I$(8).LargeMolecules:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 11, true);
break;
case $I$(8).NEWPSOFF:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 0, true);
break;
case $I$(8).OneFiveT:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 7, true);
break;
case $I$(8).RecMet:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 5, true);
break;
case $I$(8).SLUUD:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 3, true);
break;
case $I$(8).SNon:
$I$(10).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hBuilder, 1);
break;
case $I$(8).SRac:
$I$(10).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hBuilder, 3);
break;
case $I$(8).SRel:
$I$(10).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hBuilder, 2);
break;
case $I$(8).SUCF:
$I$(10).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hBuilder, 4);
break;
case $I$(8).SAbs:
$I$(10).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hBuilder, 0);
break;
case $I$(8).SUU:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 2, true);
break;
case $I$(8).SaveOpt:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 8, true);
break;
case $I$(8).WarnOnEmptyStructure:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 10, true);
break;
case $I$(8).NoWarnings:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 24, true);
break;
case $I$(8).LooseTSACheck:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 22, true);
break;
case $I$(8).Polymers:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 12, true);
break;
case $I$(8).Polymers105:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 13, true);
break;
case $I$(8).FoldCRU:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 20, true);
break;
case $I$(8).NoFrameShift:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 19, true);
break;
case $I$(8).NoEdits:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 21, true);
break;
case $I$(8).NPZz:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 17, true);
break;
case $I$(8).SAtZz:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 18, true);
break;
case $I$(8).OutErrInChI:
$I$(10).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hBuilder, 23, true);
break;
default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI option flag: " + flag]);
}
}
var inchi=$I$(10).IXA_INCHIBUILDER_GetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
var auxInfo=$I$(10).IXA_INCHIBUILDER_GetAuxInfo$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
var log=$I$(10).IXA_INCHIBUILDER_GetLog$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
var status=C$.getStatus$com_sun_jna_Pointer(hStatus);
var messages=C$.getMessages$com_sun_jna_Pointer(hStatus);
return Clazz.new_($I$(16,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus,[inchi, auxInfo, messages, log, status]);
} finally {
$I$(10).IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
}
}, 1);

Clazz.newMeth(C$, 'getStatus$com_sun_jna_Pointer',  function (hStatus) {
return ($I$(10).IXA_STATUS_HasError$com_sun_jna_Pointer(hStatus) ? $I$(17).ERROR : $I$(10).IXA_STATUS_HasWarning$com_sun_jna_Pointer(hStatus) ? $I$(17).WARNING : $I$(17).SUCCESS);
}, 1);

Clazz.newMeth(C$, 'getMessages$com_sun_jna_Pointer',  function (hStatus) {
var sb=Clazz.new_($I$(18,1));
var messageCount=$I$(10).IXA_STATUS_GetCount$com_sun_jna_Pointer(hStatus);
for (var i=0; i < messageCount; i++) {
if (i > 0) {
sb.append$S("; ");
}sb.append$S($I$(10).IXA_STATUS_GetMessage$com_sun_jna_Pointer$I(hStatus, i));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'molToInchi$S',  function (molText) {
return C$.molToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molText, $I$(9).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'molToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (molText, options) {
return C$.molFileToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molText, options);
}, 1);

Clazz.newMeth(C$, 'molFileToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (molText, options) {
C$.checkLibrary$();
var hStatus=$I$(10).IXA_STATUS_Create$();
var hMolecule=$I$(10).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, molText);
if ($I$(10).IXA_STATUS_HasError$com_sun_jna_Pointer(hStatus)) {
return Clazz.new_(["", "", C$.getMessages$com_sun_jna_Pointer(hStatus), "", $I$(17).ERROR],$I$(16,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus);
}return C$.buildInchi$com_sun_jna_Pointer$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiOptions(hStatus, hMolecule, options);
} finally {
$I$(10).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
}
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromMolFile$S',  function (molText) {
return C$.getInchiInputFromMolFile$S$S(molText, null);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromMolFile$S$S',  function (molText, outputOptions) {
C$.checkLibrary$();
var hStatus=$I$(10).IXA_STATUS_Create$();
var hMolecule=$I$(10).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, molText);
return C$.getInchiInputFromMoleculeHandle$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, outputOptions);
} finally {
$I$(10).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
}
}, 1);

Clazz.newMeth(C$, 'inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
C$.checkLibrary$();
var hStatus=$I$(10).IXA_STATUS_Create$();
var hMolecule=$I$(10).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, inchi);
return C$.buildInchi$com_sun_jna_Pointer$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiOptions(hStatus, hMolecule, options);
} finally {
$I$(10).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
}
}, 1);

Clazz.newMeth(C$, 'getInChIKeyFromInChI$S',  function (inchi) {
return C$.inchiToInchiKeyIXA$S(inchi).getInchiKey$();
}, 1);

Clazz.newMeth(C$, 'inchiToInchiKeyIXA$S',  function (inchi) {
C$.checkLibrary$();
var hStatus=$I$(10).IXA_STATUS_Create$();
var hBuilder=$I$(10).IXA_INCHIKEYBUILDER_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_INCHIKEYBUILDER_SetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hBuilder, inchi);
var key=$I$(10).IXA_INCHIKEYBUILDER_GetInChIKey$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
var ret=(key == null  ? 1 : 0);
return Clazz.new_([key, $I$(20,"of$I",[($b$[0] = ret, $b$[0])]), "", ""],$I$(19,1).c$$S$io_github_dan2097_jnainchi_InchiKeyStatus$S$S);
} finally {
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
$I$(10).IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(null, hBuilder);
}
}, 1);

Clazz.newMeth(C$, 'inchiToInchiKey$S',  function (inchi) {
C$.checkLibrary$();
var inchiKeyBytes=Clazz.array(Byte.TYPE, [28]);
var szXtra1Bytes=Clazz.array(Byte.TYPE, [65]);
var szXtra2Bytes=Clazz.array(Byte.TYPE, [65]);
var ret=$I$(20,"of$I",[$I$(4).GetINCHIKeyFromINCHI$S$I$I$BA$BA$BA(inchi, 1, 1, inchiKeyBytes, szXtra1Bytes, szXtra2Bytes)]);
try {
var inchiKeyStr= String.instantialize(inchiKeyBytes, "UTF-8").trim$();
var szXtra1= String.instantialize(szXtra1Bytes, "UTF-8").trim$();
var szXtra2= String.instantialize(szXtra2Bytes, "UTF-8").trim$();
return Clazz.new_($I$(19,1).c$$S$io_github_dan2097_jnainchi_InchiKeyStatus$S$S,[inchiKeyStr, ret, szXtra1, szXtra2]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.UnsupportedEncodingException")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'checkInchi$S$Z',  function (inchi, strict) {
C$.checkLibrary$();
return $I$(21,"of$I",[$I$(4).CheckINCHI$S$Z(inchi, strict)]);
}, 1);

Clazz.newMeth(C$, 'checkInchiKey$S',  function (inchiKey) {
C$.checkLibrary$();
return $I$(22,"of$I",[$I$(4).CheckINCHIKey$S(inchiKey)]);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromAuxInfo$S$Z$Z',  function (auxInfo, doNotAddH, diffUnkUndfStereo) {
C$.checkLibrary$();
var inchiInput=Clazz.new_($I$(23,1));
var status=$I$(17).ERROR;
var message="No IXA interface for INCHI from auxinfo";
var chiralFlag=null;
return Clazz.new_($I$(24,1).c$$io_github_dan2097_jnainchi_InchiInput$Boolean$S$io_github_dan2097_jnainchi_InchiStatus,[inchiInput, chiralFlag, message, status]);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S',  function (inchi) {
return C$.getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions$S(inchi, $I$(9).DEFAULT_OPTIONS, null);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInChI$S$S',  function (inchi, outputOptions) {
return C$.getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions$S(inchi, $I$(9).DEFAULT_OPTIONS, outputOptions).getInchiInput$();
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
return C$.getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions$S(inchi, options, null);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions$S',  function (inchi, options, outputOptions) {
C$.checkLibrary$();
var hStatus=$I$(10).IXA_STATUS_Create$();
var hMolecule=$I$(10).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
try {
$I$(10).IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, inchi);
var inchiInput=C$.getInchiInputFromMoleculeHandle$com_sun_jna_Pointer$com_sun_jna_Pointer$S(hStatus, hMolecule, outputOptions);
var message=C$.getMessages$com_sun_jna_Pointer(hStatus);
var log="";
var warningFlags=Clazz.array(Long.TYPE, [2, 2]);
return Clazz.new_([inchiInput, message, log, C$.getStatus$com_sun_jna_Pointer(hStatus), warningFlags],$I$(25,1).c$$io_github_dan2097_jnainchi_InchiInput$S$S$io_github_dan2097_jnainchi_InchiStatus$JAA);
} catch (t) {
System.err.println$O(t);
return null;
} finally {
$I$(10).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
$I$(10).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(null, hMolecule);
}
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromMoleculeHandle$com_sun_jna_Pointer$com_sun_jna_Pointer$S',  function (hStatus, hMolecule, outputOptions) {
var setNoStereo=null;
var setO=null;
var acids=null;
var amides=null;
if (outputOptions != null  && outputOptions.toLowerCase$java_util_Locale($I$(26).ROOT).indexOf$S("fixamide") >= 0 ) {
setNoStereo=Clazz.new_($I$(27,1));
setO=Clazz.new_($I$(27,1));
amides=Clazz.new_($I$(28,1));
}if (outputOptions != null  && outputOptions.toLowerCase$java_util_Locale($I$(26).ROOT).indexOf$S("fixacid") >= 0 ) {
acids=Clazz.new_($I$(5,1));
}var atoms=Clazz.new_($I$(28,1));
var bonds=Clazz.new_($I$(28,1));
var inchiInput=Clazz.new_($I$(23,1));
var mapNativeToJavaAtom=Clazz.new_($I$(5,1));
C$.nativeToJavaAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$java_util_List$java_util_Set(hStatus, hMolecule, mapNativeToJavaAtom, atoms, setO);
C$.nativeToJavaBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$java_util_List$java_util_Set$java_util_Set$java_util_Map$java_util_List(hStatus, hMolecule, mapNativeToJavaAtom, bonds, setO, setNoStereo, acids, amides);
for (var i=0, n=atoms.size$(); i < n; i++) {
inchiInput.addAtom$io_github_dan2097_jnainchi_InchiAtom(atoms.get$I(i));
}
for (var i=0, n=bonds.size$(); i < n; i++) {
inchiInput.addBond$io_github_dan2097_jnainchi_InchiBond(bonds.get$I(i));
}
C$.nativeToJavaStereos$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$io_github_dan2097_jnainchi_InchiInput$java_util_Set(hStatus, hMolecule, mapNativeToJavaAtom, inchiInput, setNoStereo);
C$.checkStatus$com_sun_jna_Pointer(hStatus);
return inchiInput;
}, 1);

Clazz.newMeth(C$, 'nativeToJavaAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$java_util_List$java_util_Set',  function (hStatus, hMolecule, mapNativeToJavaAtom, atoms, setO) {
var nAtoms=$I$(10).IXA_MOL_GetNumAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
for (var i=0; i < nAtoms; i++) {
var hAtom=$I$(10).IXA_MOL_GetAtomId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, i);
var elSymbol=$I$(10).IXA_MOL_GetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
var charge=$I$(10).IXA_MOL_GetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
var x=$I$(10).IXA_MOL_GetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
var y=$I$(10).IXA_MOL_GetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
var z=$I$(10).IXA_MOL_GetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
var atom=Clazz.new_($I$(29,1).c$$S$D$D$D,[elSymbol, x, y, z]);
var nh=$I$(10).IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, hAtom, 0);
atom.setImplicitHydrogen$I(nh);
if (setO != null  && charge == 0  && "O".equals$O(elSymbol)  && (nh == 1 || nh == -1 && $I$(10).IXA_MOL_GetAtomNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom) == 1  ) ) setO.add$O(atom);
atom.setImplicitProtium$I($I$(10).IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, hAtom, 1));
atom.setImplicitDeuterium$I($I$(10).IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, hAtom, 2));
atom.setImplicitTritium$I($I$(10).IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, hAtom, 3));
var isotopicMass=$I$(10).IXA_MOL_GetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom);
if (isotopicMass >= 9900 && isotopicMass <= 10100 ) {
var baseMass=(C$.aveMass.getOrDefault$O$O(elSymbol, Integer.valueOf$I(0))).$c();
var delta=isotopicMass - 10000;
isotopicMass=baseMass + delta;
}atom.setIsotopicMass$I(isotopicMass);
atom.setCharge$I(charge);
atom.setRadical$io_github_dan2097_jnainchi_InchiRadical($I$(11,"of$B",[($b$[0] = $I$(10).IXA_MOL_GetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hAtom), $b$[0])]));
atoms.add$O(atom);
mapNativeToJavaAtom.put$O$O((hAtom), atom);
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$java_util_List$java_util_Set$java_util_Set$java_util_Map$java_util_List',  function (hStatus, hMolecule, mapNativeToJavaAtom, bonds, setO, setNoStereo, acids, amides) {
var numBonds=$I$(10).IXA_MOL_GetNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
var mapNC=(setNoStereo == null  ? null : Clazz.new_($I$(5,1)));
var mapCO=(setNoStereo == null  ? null : Clazz.new_($I$(5,1)));
for (var i=0; i < numBonds; i++) {
var hBond=$I$(10).IXA_MOL_GetBondId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, i);
var bondType=$I$(1,"of$B",[($b$[0] = $I$(10).IXA_MOL_GetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hBond), $b$[0])]);
var a1=$I$(10).IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hBond);
var a2=$I$(10).IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hBond);
var bondStereo=C$.getSingleStereoCode$I$I($I$(10).IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hBond, a1), $I$(10).IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hBond, a2));
var atom1=mapNativeToJavaAtom.get$O(a1);
var atom2=mapNativeToJavaAtom.get$O(a2);
var b=Clazz.new_($I$(3,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atom1, atom2, bondType, bondStereo]);
if (amides != null ) {
$I$(30).check$I$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiBond$java_util_List$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$java_util_Map$java_util_Map$java_util_Set$java_util_Set$java_util_List(i, hBond, b, bonds, atom1, atom2, mapNC, mapCO, setO, setNoStereo, amides);
}if (acids != null ) {
$I$(2).check$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$java_util_Map(atom1, atom2, bondType, acids);
}bonds.add$O(b);
}
if (acids != null  && acids.size$() > 0 ) $I$(2).fix$java_util_Map(acids);
if (amides != null  && amides.size$() > 0 ) $I$(30).fix$java_util_List$java_util_List(amides, bonds);
}, 1);

Clazz.newMeth(C$, 'getSingleStereoCode$I$I',  function (direction, reverse_direction) {
switch (direction) {
case 0:
switch (reverse_direction) {
case 0:
return $I$(12).NONE;
case 1:
return $I$(12).SINGLE_2UP;
case 2:
return $I$(12).SINGLE_2DOWN;
case 3:
return $I$(12).SINGLE_2EITHER;
default:
return $I$(12).NONE;
}
case 1:
return $I$(12).SINGLE_1UP;
case 2:
return $I$(12).SINGLE_1DOWN;
case 3:
return $I$(12).SINGLE_1EITHER;
default:
return $I$(12).NONE;
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaStereos$com_sun_jna_Pointer$com_sun_jna_Pointer$java_util_Map$io_github_dan2097_jnainchi_InchiInput$java_util_Set',  function (hStatus, hMolecule, mapNativeToJavaAtom, inchiInput, setNoStereo) {
var numStereo=$I$(10).IXA_MOL_GetNumStereos$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
for (var is=0; is < numStereo; is++) {
var atoms=Clazz.array($I$(29), [4]);
var hStereo=$I$(10).IXA_MOL_GetStereoId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, is);
for (var i=0; i < 4; i++) {
var vVertex=$I$(10).IXA_MOL_GetStereoVertex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, hStereo, i);
atoms[i]=mapNativeToJavaAtom.get$O(vVertex);
if (atoms[i] == null ) atoms[i]=$I$(15).STEREO_IMPLICIT_H;
}
C$.checkStatus$com_sun_jna_Pointer(hStatus);
var stereoType;
var topo=$I$(10).IXA_MOL_GetStereoTopology$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hStereo);
var hasCentralAtom=false;
switch (topo) {
case 2:
stereoType=$I$(13).Tetrahedral;
hasCentralAtom=true;
break;
case 3:
stereoType=$I$(13).DoubleBond;
var vCentralBond=$I$(10).IXA_MOL_GetStereoCentralBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hStereo);
if (setNoStereo != null  && setNoStereo.contains$O(vCentralBond) ) continue;
var vAtom1=$I$(10).IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralBond);
var vAtom2=$I$(10).IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralBond);
atoms[1]=mapNativeToJavaAtom.get$O(vAtom1);
atoms[2]=mapNativeToJavaAtom.get$O(vAtom2);
break;
case 4:
stereoType=$I$(13).Allene;
hasCentralAtom=true;
break;
default:
return;
}
var parity=$I$(14,"of$B",[($b$[0] = $I$(10).IXA_MOL_GetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hStereo), $b$[0])]);
var centralAtom=(hasCentralAtom ? centralAtom=mapNativeToJavaAtom.get$O($I$(10).IXA_MOL_GetStereoCentralAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, hStereo)) : null);
inchiInput.addStereo$io_github_dan2097_jnainchi_InchiStereo(Clazz.new_($I$(15,1).c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[atoms, centralAtom, stereoType, parity]));
}
}, 1);

Clazz.newMeth(C$, 'checkStatus$com_sun_jna_Pointer',  function (hStatus) {
var n=(hStatus == null  ? 0 : $I$(10).IXA_STATUS_GetCount$com_sun_jna_Pointer(hStatus));
if (n > 0) {
System.out.println$I(n);
System.out.println$S($I$(10).IXA_STATUS_GetMessage$com_sun_jna_Pointer$I(hStatus, n - 1));
}}, 1);

Clazz.newMeth(C$, 'getInchiLibraryVersion$',  function () {
return C$.getInChIVersion$Z(false);
}, 1);

Clazz.newMeth(C$, 'getJnaInchiVersion$',  function () {
{

}
}, 1);

Clazz.newMeth(C$, 'getInChIVersion$Z',  function (fullDescription) {
{
var module = J2S._module;
var ptr = module.ccall("IXA_INCHIBUILDER_GetInChIVersion", "number", ["number"], [fullDescription]);
var ret = module.UTF8ToString(ptr);
module._free(ptr);
return ret;
}
}, 1);

Clazz.newMeth(C$, 'getJSONFromInchiInput$io_github_dan2097_jnainchi_InchiInput',  function (inchiInput) {
var na=inchiInput.getAtoms$().size$();
var nb=inchiInput.getBonds$().size$();
var ns=inchiInput.getStereos$().size$();
var mapAtoms=Clazz.new_($I$(5,1));
var haveXYZ=false;
for (var i=0; i < na; i++) {
var a=inchiInput.getAtom$I(i);
if (a.getX$() != 0  || a.getY$() != 0   || a.getZ$() != 0  ) {
haveXYZ=true;
break;
}}
var s="{";
s+="\n\"atomCount\":" + na + ",\n" ;
s+="\"atoms\":[\n";
for (var i=0; i < na; i++) {
var a=inchiInput.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{";
s+=C$.toJSONInt$S$I$S("index", (Integer.valueOf$I(i)).$c(), "");
s+=C$.toJSONNotNone$S$O$S("elname", a.getElName$(), ",");
if (haveXYZ) {
s+=C$.toJSONDouble$S$D$S("x", a.getX$(), ",");
s+=C$.toJSONDouble$S$D$S("y", a.getY$(), ",");
s+=C$.toJSONDouble$S$D$S("z", a.getZ$(), ",");
}s+=C$.toJSONNotNone$S$O$S("radical", a.getRadical$(), ",");
s+=C$.toJSONNonZero$S$I$S("charge", a.getCharge$(), ",");
s+=C$.toJSONNonZero$S$I$S("isotopeMass", a.getIsotopicMass$(), ",");
if (a.getImplicitHydrogen$() > 0) s+=C$.toJSONNonZero$S$I$S("implicitH", a.getImplicitHydrogen$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitDeuterium", a.getImplicitDeuterium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitProtium", a.getImplicitProtium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitTritium", a.getImplicitTritium$(), ",");
s+="}";
}
s+="\n],";
s+="\n\"bondCount\":" + nb + "," ;
s+="\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{";
var b=inchiInput.getBond$I(i);
s+=C$.toJSONInt$S$I$S("originAtom", mapAtoms.get$O(b.getStart$()).intValue$(), "");
s+=C$.toJSONInt$S$I$S("targetAtom", mapAtoms.get$O(b.getEnd$()).intValue$(), ",");
var bt=b.getType$().toString().toUpperCase$java_util_Locale($I$(26).ROOT);
if (!bt.equals$O("SINGLE")) s+=C$.toJSONString$S$S$S("type", bt, ",");
s+=C$.toJSONNotNone$S$O$S("stereo", b.getStereo$().toString().toUpperCase$java_util_Locale($I$(26).ROOT), ",");
s+="}";
}
s+="\n]";
if (ns > 0) {
s+=",\n\"stereoCount\":" + ns + ",\n" ;
s+="\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{";
var d=inchiInput.getStereos$().get$I(i);
var a=d.getCentralAtom$();
s+=C$.toJSONNotNone$S$O$S("parity", d.getParity$(), "");
s+=C$.toJSONNotNone$S$O$S("type", d.getType$(), ",");
if (a != null ) s+=C$.toJSONInt$S$I$S("centralAtom", mapAtoms.get$O(a).intValue$(), ",");
var an=d.getAtoms$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(an[j]).intValue$();
}
s+=C$.toJSONArray$S$IA$S("neighbors", nbs, ",");
s+="}";
}
s+="\n]";
}s+="}";
return s;
}, 1);

Clazz.newMeth(C$, 'toJSONArray$S$IA$S',  function (key, val, term) {
var s=term + "\"" + key + "\":[" + val[0] ;
for (var i=1; i < val.length; i++) {
s+="," + val[i];
}
return s + "]";
}, 1);

Clazz.newMeth(C$, 'toJSONNonZero$S$I$S',  function (key, val, term) {
return (val == 0 ? "" : C$.toJSONInt$S$I$S(key, val, term));
}, 1);

Clazz.newMeth(C$, 'toJSONInt$S$I$S',  function (key, val, term) {
return term + "\"" + key + "\":" + val ;
}, 1);

Clazz.newMeth(C$, 'toJSONDouble$S$D$S',  function (key, val, term) {
var s;
if (val == 0 ) {
s="0";
} else {
s="" + (new Double(val + (val > 0  ? 1.0E-8 : -1.0E-8)).toString());
s=s.substring$I$I(0, s.indexOf$S(".") + 5);
var n=s.length$();
while (s.charAt$I(--n) == "0"){
}
s=s.substring$I$I(0, n + 1);
}return term + "\"" + key + "\":" + s ;
}, 1);

Clazz.newMeth(C$, 'toJSONString$S$S$S',  function (key, val, term) {
return term + "\"" + key + "\":\"" + val + "\"" ;
}, 1);

Clazz.newMeth(C$, 'toJSONNotNone$S$O$S',  function (key, val, term) {
var s=val.toString();
return ("NONE".equals$O(s) ? "" : term + "\"" + key + "\":\"" + s + "\"" );
}, 1);

Clazz.newMeth(C$, 'getCallCount$',  function () {
return $I$(10).ncalls;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isJS=(true ||false);
C$.libraryLoadingError=null;
{
try {
C$.inchiLibName=$I$(4).JNA_NATIVE_LIB.getName$();
} catch (e) {
e.printStackTrace$();
C$.libraryLoadingError=e;
}
};
C$.aveMass=Clazz.new_($I$(5,1));
{
C$.aveMass.put$O$O("H", Integer.valueOf$I(1));
C$.aveMass.put$O$O("D", Integer.valueOf$I(2));
C$.aveMass.put$O$O("T", Integer.valueOf$I(3));
C$.aveMass.put$O$O("He", Integer.valueOf$I(4));
C$.aveMass.put$O$O("Li", Integer.valueOf$I(7));
C$.aveMass.put$O$O("Be", Integer.valueOf$I(9));
C$.aveMass.put$O$O("B", Integer.valueOf$I(11));
C$.aveMass.put$O$O("C", Integer.valueOf$I(12));
C$.aveMass.put$O$O("N", Integer.valueOf$I(14));
C$.aveMass.put$O$O("O", Integer.valueOf$I(16));
C$.aveMass.put$O$O("F", Integer.valueOf$I(19));
C$.aveMass.put$O$O("Ne", Integer.valueOf$I(20));
C$.aveMass.put$O$O("Na", Integer.valueOf$I(23));
C$.aveMass.put$O$O("Mg", Integer.valueOf$I(24));
C$.aveMass.put$O$O("Al", Integer.valueOf$I(27));
C$.aveMass.put$O$O("Si", Integer.valueOf$I(28));
C$.aveMass.put$O$O("P", Integer.valueOf$I(31));
C$.aveMass.put$O$O("S", Integer.valueOf$I(32));
C$.aveMass.put$O$O("Cl", Integer.valueOf$I(35));
C$.aveMass.put$O$O("Ar", Integer.valueOf$I(40));
C$.aveMass.put$O$O("K", Integer.valueOf$I(39));
C$.aveMass.put$O$O("Ca", Integer.valueOf$I(40));
C$.aveMass.put$O$O("Sc", Integer.valueOf$I(45));
C$.aveMass.put$O$O("Ti", Integer.valueOf$I(48));
C$.aveMass.put$O$O("V", Integer.valueOf$I(51));
C$.aveMass.put$O$O("Cr", Integer.valueOf$I(52));
C$.aveMass.put$O$O("Mn", Integer.valueOf$I(55));
C$.aveMass.put$O$O("Fe", Integer.valueOf$I(56));
C$.aveMass.put$O$O("Co", Integer.valueOf$I(59));
C$.aveMass.put$O$O("Ni", Integer.valueOf$I(59));
C$.aveMass.put$O$O("Cu", Integer.valueOf$I(64));
C$.aveMass.put$O$O("Zn", Integer.valueOf$I(65));
C$.aveMass.put$O$O("Ga", Integer.valueOf$I(70));
C$.aveMass.put$O$O("Ge", Integer.valueOf$I(73));
C$.aveMass.put$O$O("As", Integer.valueOf$I(75));
C$.aveMass.put$O$O("Se", Integer.valueOf$I(79));
C$.aveMass.put$O$O("Br", Integer.valueOf$I(80));
C$.aveMass.put$O$O("Kr", Integer.valueOf$I(84));
C$.aveMass.put$O$O("Rb", Integer.valueOf$I(85));
C$.aveMass.put$O$O("Sr", Integer.valueOf$I(88));
C$.aveMass.put$O$O("Y", Integer.valueOf$I(89));
C$.aveMass.put$O$O("Zr", Integer.valueOf$I(91));
C$.aveMass.put$O$O("Nb", Integer.valueOf$I(93));
C$.aveMass.put$O$O("Mo", Integer.valueOf$I(96));
C$.aveMass.put$O$O("Tc", Integer.valueOf$I(98));
C$.aveMass.put$O$O("Ru", Integer.valueOf$I(101));
C$.aveMass.put$O$O("Rh", Integer.valueOf$I(103));
C$.aveMass.put$O$O("Pd", Integer.valueOf$I(106));
C$.aveMass.put$O$O("Ag", Integer.valueOf$I(108));
C$.aveMass.put$O$O("Cd", Integer.valueOf$I(112));
C$.aveMass.put$O$O("In", Integer.valueOf$I(115));
C$.aveMass.put$O$O("Sn", Integer.valueOf$I(119));
C$.aveMass.put$O$O("Sb", Integer.valueOf$I(122));
C$.aveMass.put$O$O("Te", Integer.valueOf$I(128));
C$.aveMass.put$O$O("I", Integer.valueOf$I(127));
C$.aveMass.put$O$O("Xe", Integer.valueOf$I(131));
C$.aveMass.put$O$O("Cs", Integer.valueOf$I(133));
C$.aveMass.put$O$O("Ba", Integer.valueOf$I(137));
C$.aveMass.put$O$O("La", Integer.valueOf$I(139));
C$.aveMass.put$O$O("Ce", Integer.valueOf$I(140));
C$.aveMass.put$O$O("Pr", Integer.valueOf$I(141));
C$.aveMass.put$O$O("Nd", Integer.valueOf$I(144));
C$.aveMass.put$O$O("Pm", Integer.valueOf$I(145));
C$.aveMass.put$O$O("Sm", Integer.valueOf$I(150));
C$.aveMass.put$O$O("Eu", Integer.valueOf$I(152));
C$.aveMass.put$O$O("Gd", Integer.valueOf$I(157));
C$.aveMass.put$O$O("Tb", Integer.valueOf$I(159));
C$.aveMass.put$O$O("Dy", Integer.valueOf$I(163));
C$.aveMass.put$O$O("Ho", Integer.valueOf$I(165));
C$.aveMass.put$O$O("Er", Integer.valueOf$I(167));
C$.aveMass.put$O$O("Tm", Integer.valueOf$I(169));
C$.aveMass.put$O$O("Yb", Integer.valueOf$I(173));
C$.aveMass.put$O$O("Lu", Integer.valueOf$I(175));
C$.aveMass.put$O$O("Hf", Integer.valueOf$I(178));
C$.aveMass.put$O$O("Ta", Integer.valueOf$I(181));
C$.aveMass.put$O$O("W", Integer.valueOf$I(184));
C$.aveMass.put$O$O("Re", Integer.valueOf$I(186));
C$.aveMass.put$O$O("Os", Integer.valueOf$I(190));
C$.aveMass.put$O$O("Ir", Integer.valueOf$I(192));
C$.aveMass.put$O$O("Pt", Integer.valueOf$I(195));
C$.aveMass.put$O$O("Au", Integer.valueOf$I(197));
C$.aveMass.put$O$O("Hg", Integer.valueOf$I(201));
C$.aveMass.put$O$O("Tl", Integer.valueOf$I(204));
C$.aveMass.put$O$O("Pb", Integer.valueOf$I(207));
C$.aveMass.put$O$O("Bi", Integer.valueOf$I(209));
C$.aveMass.put$O$O("Po", Integer.valueOf$I(209));
C$.aveMass.put$O$O("At", Integer.valueOf$I(210));
C$.aveMass.put$O$O("Rn", Integer.valueOf$I(222));
C$.aveMass.put$O$O("Fr", Integer.valueOf$I(223));
C$.aveMass.put$O$O("Ra", Integer.valueOf$I(226));
C$.aveMass.put$O$O("Ac", Integer.valueOf$I(227));
C$.aveMass.put$O$O("Th", Integer.valueOf$I(232));
C$.aveMass.put$O$O("Pa", Integer.valueOf$I(231));
C$.aveMass.put$O$O("U", Integer.valueOf$I(238));
C$.aveMass.put$O$O("Np", Integer.valueOf$I(237));
C$.aveMass.put$O$O("Pu", Integer.valueOf$I(244));
C$.aveMass.put$O$O("Am", Integer.valueOf$I(243));
C$.aveMass.put$O$O("Cm", Integer.valueOf$I(247));
C$.aveMass.put$O$O("Bk", Integer.valueOf$I(247));
C$.aveMass.put$O$O("Cf", Integer.valueOf$I(251));
C$.aveMass.put$O$O("Es", Integer.valueOf$I(252));
C$.aveMass.put$O$O("Fm", Integer.valueOf$I(257));
C$.aveMass.put$O$O("Md", Integer.valueOf$I(258));
C$.aveMass.put$O$O("No", Integer.valueOf$I(259));
C$.aveMass.put$O$O("Lr", Integer.valueOf$I(260));
C$.aveMass.put$O$O("Rf", Integer.valueOf$I(261));
C$.aveMass.put$O$O("Db", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Sg", Integer.valueOf$I(269));
C$.aveMass.put$O$O("Bh", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Hs", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Mt", Integer.valueOf$I(278));
C$.aveMass.put$O$O("Ds", Integer.valueOf$I(281));
C$.aveMass.put$O$O("Rg", Integer.valueOf$I(281));
C$.aveMass.put$O$O("Cn", Integer.valueOf$I(285));
C$.aveMass.put$O$O("Nh", Integer.valueOf$I(278));
C$.aveMass.put$O$O("Fl", Integer.valueOf$I(289));
C$.aveMass.put$O$O("Mc", Integer.valueOf$I(289));
C$.aveMass.put$O$O("Lv", Integer.valueOf$I(293));
C$.aveMass.put$O$O("Ts", Integer.valueOf$I(297));
C$.aveMass.put$O$O("Og", Integer.valueOf$I(294));
};
};
var $b$ = new Int8Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.InchiAPI, "Amide", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['revNC','revCO'],'I',['iNC','iCO'],'O',['aN','io.github.dan2097.jnainchi.InchiAtom','+aC','+aO','bNC','io.github.dan2097.jnainchi.InchiBond','+bCO','hNC','com.sun.jna.Pointer']]]

Clazz.newMeth(C$, 'c$$com_sun_jna_Pointer$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$Z',  function (ptr, index, b, a1, a2, isRev) {
;C$.$init$.apply(this);
if (ptr == null ) {
this.aC=a1;
this.aO=a2;
this.bCO=b;
this.iCO=index;
this.revCO=isRev;
} else {
this.hNC=ptr;
this.aN=a1;
this.aC=a2;
this.bNC=b;
this.iNC=index;
this.revNC=isRev;
}}, 1);

Clazz.newMeth(C$, 'check$I$com_sun_jna_Pointer$io_github_dan2097_jnainchi_InchiBond$java_util_List$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$java_util_Map$java_util_Map$java_util_Set$java_util_Set$java_util_List',  function (i, hBond, b, bonds, atom1, atom2, mapNC, mapCO, setO, setNoStereo, amides) {
var n1=atom1.getElName$();
var n2=atom2.getElName$();
var newAmide=null;
switch (b.getType$()) {
case $I$(1).SINGLE:
if (n1.equals$O("C") && n2.equals$O("O") && setO.contains$O(atom2)  ) {
var a=mapNC.get$O(atom1);
if (a == null ) {
mapCO.put$O$O(atom1, newAmide=Clazz.new_(C$.c$$com_sun_jna_Pointer$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$Z,[null, i, b, atom1, atom2, false]));
} else {
p$1.addO$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List.apply(a, [i, b, atom2, bonds]);
}} else if (n2.equals$O("C") && n1.equals$O("O") && setO.contains$O(atom1)  ) {
var a=mapNC.get$O(atom2);
if (a == null ) {
mapCO.put$O$O(atom1, newAmide=Clazz.new_(C$.c$$com_sun_jna_Pointer$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$Z,[null, i, b, atom2, atom1, true]));
} else {
setNoStereo.add$O(a.hNC);
p$1.addO$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List.apply(a, [i, b, atom1, bonds]);
}}break;
case $I$(1).DOUBLE:
if (n1.equals$O("N") && n2.equals$O("C") ) {
var a=mapCO.get$O(atom2);
if (a == null ) {
mapNC.put$O$O(atom2, newAmide=Clazz.new_(C$.c$$com_sun_jna_Pointer$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$Z,[hBond, i, b, atom1, atom2, false]));
} else {
setNoStereo.add$O(hBond);
p$1.addN$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List.apply(a, [i, b, atom1, bonds]);
}} else if (n2.equals$O("N") && n1.equals$O("C") ) {
var a=mapCO.get$O(atom1);
if (a == null ) {
mapNC.put$O$O(atom1, newAmide=Clazz.new_(C$.c$$com_sun_jna_Pointer$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$Z,[hBond, i, b, atom2, atom1, true]));
} else {
p$1.addN$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List.apply(a, [i, b, atom2, bonds]);
setNoStereo.add$O(hBond);
}}break;
default:
break;
}
if (newAmide != null ) amides.add$O(newAmide);
}, 1);

Clazz.newMeth(C$, 'addN$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List',  function (index, b, n, bonds) {
this.bNC=b;
this.aN=n;
this.iNC=index;
}, p$1);

Clazz.newMeth(C$, 'addO$I$io_github_dan2097_jnainchi_InchiBond$io_github_dan2097_jnainchi_InchiAtom$java_util_List',  function (index, b, o, bonds) {
this.bCO=b;
this.aO=o;
this.iCO=index;
}, p$1);

Clazz.newMeth(C$, 'fixAmide$java_util_List',  function (bonds) {
if (this.aO == null  || this.aN == null  ) return;
var htype=$I$(2).getImplicitHtype$io_github_dan2097_jnainchi_InchiAtom(this.aO);
if (htype != "\u0000") {
this.bNC=Clazz.new_([this.revNC ? this.aC : this.aN, this.revNC ? this.aN : this.aC, $I$(1).SINGLE],$I$(3,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType);
this.bCO=Clazz.new_([this.revCO ? this.aO : this.aC, this.revCO ? this.aC : this.aO, $I$(1).DOUBLE],$I$(3,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType);
bonds.set$I$O(this.iNC, this.bNC);
bonds.set$I$O(this.iCO, this.bCO);
switch (htype.$c()) {
case 72:
var n=this.aN.getImplicitHydrogen$();
this.aN.setImplicitHydrogen$I(n == -1 ? -1 : n + 1);
this.aO.setImplicitHydrogen$I(0);
break;
case 68:
this.aN.setImplicitDeuterium$I(this.aN.getImplicitDeuterium$() + 1);
this.aO.setImplicitDeuterium$I(0);
break;
case 84:
this.aN.setImplicitTritium$I(this.aN.getImplicitTritium$() + 1);
this.aO.setImplicitTritium$I(0);
break;
case 80:
this.aN.setImplicitProtium$I(this.aN.getImplicitProtium$() + 1);
this.aO.setImplicitProtium$I(0);
break;
}
}}, p$1);

Clazz.newMeth(C$, 'fix$java_util_List$java_util_List',  function (amides, bonds) {
for (var i=amides.size$(); --i >= 0; ) {
p$1.fixAmide$java_util_List.apply(amides.get$I(i), [bonds]);
}
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.InchiAPI, "Acid", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.htype="\u0000";
},1);

C$.$fields$=[['C',['htype'],'I',['charge'],'O',['aC','io.github.dan2097.jnainchi.InchiAtom','+aO1','+aO2']]]

Clazz.newMeth(C$, 'check$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$java_util_Map',  function (atom1, atom2, type, acids) {
if (atom1.getElName$().equals$O("C") && atom2.getElName$().equals$O("O") ) {
C$.addCO$java_util_Map$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType(acids, atom1, atom2, type);
} else if (atom1.getElName$().equals$O("O") && atom2.getElName$().equals$O("C") ) {
C$.addCO$java_util_Map$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType(acids, atom2, atom1, type);
}}, 1);

Clazz.newMeth(C$, 'addCO$java_util_Map$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType',  function (acids, aC, aO, type) {
switch (type) {
case $I$(1).SINGLE:
case $I$(1).DOUBLE:
if (aO.getCharge$() != 0 && aO.getCharge$() != -1 ) {
return;
}break;
default:
return;
}
var a=acids.get$O(aC);
if (a == null ) acids.put$O$O(aC, a=Clazz.new_(C$.c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType,[aC, aO, type]));
 else p$2.addO$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType.apply(a, [aO, type]);
}, 1);

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType',  function (aC, aO, type) {
;C$.$init$.apply(this);
this.aC=aC;
p$2.addO$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType.apply(this, [aO, type]);
}, 1);

Clazz.newMeth(C$, 'addO$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType',  function (aO, type) {
switch (type) {
case $I$(1).SINGLE:
this.aO1=aO;
this.charge=aO.getCharge$();
if (this.charge == 0) {
this.htype=C$.getImplicitHtype$io_github_dan2097_jnainchi_InchiAtom(aO);
}break;
case $I$(1).DOUBLE:
this.aO2=aO;
break;
default:
this.aC=null;
break;
}
}, p$2);

Clazz.newMeth(C$, 'getImplicitHtype$io_github_dan2097_jnainchi_InchiAtom',  function (aO) {
if (aO.getImplicitHydrogen$() == 1) return "H";
 else if (aO.getImplicitProtium$() == 1) return "P";
 else if (aO.getImplicitDeuterium$() == 1) return "D";
 else if (aO.getImplicitTritium$() == 1) return "T";
return "\u0000";
}, 1);

Clazz.newMeth(C$, 'fix$java_util_Map',  function (acids) {
var phenolate=null;
var carboxylic=null;
 out : for (var a, $a = acids.values$().iterator$(); $a.hasNext$()&&((a=($a.next$())),1);) {
if (a.aC == null ) continue;
switch (a.charge) {
case 0:
if (a.aO2 != null  && a.htype != "\u0000" ) {
carboxylic=a;
if (phenolate != null ) break out;
}break;
case -1:
if (a.aO2 == null ) {
phenolate=a;
if (carboxylic != null ) break out;
}break;
}
}
if (carboxylic == null  || phenolate == null  ) return;
carboxylic.aO1.setCharge$I(-1);
phenolate.aO1.setCharge$I(0);
switch (carboxylic.htype.$c()) {
case 72:
carboxylic.aO1.setImplicitHydrogen$I(0);
phenolate.aO1.setImplicitHydrogen$I(1);
break;
case 68:
carboxylic.aO1.setImplicitDeuterium$I(0);
phenolate.aO1.setImplicitDeuterium$I(1);
break;
case 84:
carboxylic.aO1.setImplicitTritium$I(0);
phenolate.aO1.setImplicitTritium$I(1);
break;
case 80:
carboxylic.aO1.setImplicitProtium$I(0);
phenolate.aO1.setImplicitProtium$I(1);
break;
}
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-14 06:39:30 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
