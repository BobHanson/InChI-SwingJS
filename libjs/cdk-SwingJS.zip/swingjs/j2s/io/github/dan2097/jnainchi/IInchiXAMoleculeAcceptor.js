(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "IInchiXAMoleculeAcceptor");
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-03-04 17:24:43 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
