(function(){var P$=Clazz.newPackage("com.actelion.research.calc.histogram"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConstantsHistogram");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
