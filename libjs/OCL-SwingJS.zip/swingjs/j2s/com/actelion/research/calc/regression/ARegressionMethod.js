(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ARegressionMethod", null, null, 'com.actelion.research.calc.regression.ICalculateModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['parameterRegressionMethod','<T extends com.actelion.research.calc.regression.ParameterRegressionMethod>','progressController','com.actelion.research.calc.ProgressController']]]

Clazz.newMeth(C$, 'setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod',  function (parameterRegressionMethod) {
this.parameterRegressionMethod=parameterRegressionMethod;
});

Clazz.newMeth(C$, 'getParameter$',  function () {
return this.parameterRegressionMethod;
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.parameterRegressionMethod.getName$();
});

Clazz.newMeth(C$, 'getProperties$',  function () {
return this.parameterRegressionMethod.getProperties$();
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.parameterRegressionMethod.decodeProperties2Parameter$();
});

Clazz.newMeth(C$, 'getProgressController$',  function () {
return this.progressController;
});

Clazz.newMeth(C$, 'setProgressController$com_actelion_research_calc_ProgressController',  function (progressController) {
this.progressController=progressController;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
