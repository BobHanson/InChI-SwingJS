(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.randomforest"),p$1={},I$=[[0,'java.text.DecimalFormat','StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod','java.io.File']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterRandomForest", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['fractionMTry'],'I',['nTrees','nodeSize','maxNodes']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["Random Forest regression"]);C$.$init$.apply(this);
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initialize',  function () {
this.setFractionMTry$D(0.333);
this.setMaxNodes$I(50);
this.setNodeSize$I(5);
this.setNumTrees$I(100);
}, p$1);

Clazz.newMeth(C$, 'getNumberOfTrees$',  function () {
return this.nTrees;
});

Clazz.newMeth(C$, 'getFractionMTry$',  function () {
return this.fractionMTry;
});

Clazz.newMeth(C$, 'getNodeSize$',  function () {
return this.nodeSize;
});

Clazz.newMeth(C$, 'getMaxNodes$',  function () {
return this.maxNodes;
});

Clazz.newMeth(C$, 'setFractionMTry$D',  function (fractionMTry) {
this.fractionMTry=fractionMTry;
this.properties.put$O$O("MTry", Double.toString$D(fractionMTry));
});

Clazz.newMeth(C$, 'setNumTrees$I',  function (nTrees) {
this.nTrees=nTrees;
this.properties.put$O$O("NumTrees", Integer.toString$I(nTrees));
});

Clazz.newMeth(C$, 'setNodeSize$I',  function (nodeSize) {
this.nodeSize=nodeSize;
this.properties.put$O$O("NodeSize", Integer.toString$I(nodeSize));
});

Clazz.newMeth(C$, 'setMaxNodes$I',  function (maxNodes) {
this.maxNodes=maxNodes;
this.properties.put$O$O("MaxNodes", Integer.toString$I(maxNodes));
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.nTrees=Integer.parseInt$S(this.properties.getProperty$S("NumTrees"));
this.fractionMTry=Double.parseDouble$S(this.properties.getProperty$S("MTry"));
this.nodeSize=Integer.parseInt$S(this.properties.getProperty$S("NodeSize"));
this.maxNodes=Integer.parseInt$S(this.properties.getProperty$S("MaxNodes"));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var p=o;
if (this.nTrees > p.nTrees) {
cmp=1;
} else if (this.nTrees < p.nTrees) {
cmp=-1;
}if (cmp == 0) {
if (this.fractionMTry > p.fractionMTry ) {
cmp=1;
} else if (this.fractionMTry < p.fractionMTry ) {
cmp=-1;
}}if (cmp == 0) {
if (this.nodeSize > p.nodeSize) {
cmp=1;
} else if (this.nodeSize < p.nodeSize) {
cmp=-1;
}}if (cmp == 0) {
if (this.maxNodes > p.maxNodes) {
cmp=1;
} else if (this.maxNodes < p.maxNodes) {
cmp=-1;
}}return cmp;
});

Clazz.newMeth(C$, 'toString',  function () {
var df=Clazz.new_($I$(1,1).c$$S,["0.0###"]);
var sb=Clazz.new_($I$(2,1).c$$S,["ParameterRNDForest{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$S(" trees=").append$I(this.nTrees);
sb.append$S(" frac variables=").append$D(this.fractionMTry);
sb.append$S(" nodeSize=").append$I(this.nodeSize);
sb.append$S(" maxNodes=").append$I(this.maxNodes);
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(3).getHeader$();
li.add$O("NumTrees");
li.add$O("MTry");
li.add$O("NodeSize");
li.add$O("MaxNodes");
return li;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dir=Clazz.new_($I$(4,1).c$$S,["/home/korffmo1/tmp/tmp00"]);
var fiProp=Clazz.new_($I$(4,1).c$$java_io_File$S,[dir, "randomForest.properties"]);
var parameter=Clazz.new_(C$);
parameter.nTrees=1000;
parameter.fractionMTry=0.321;
parameter.nodeSize=7;
parameter.maxNodes=42;
parameter.write$java_io_File(fiProp);
var parameterIn=Clazz.new_(C$);
parameterIn.read$java_io_File(fiProp);
System.out.println$S(parameterIn.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:55 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
