(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.conf.BondRotationHelper','com.actelion.research.chem.Coordinates','com.actelion.research.chem.optimization.MCHelper','java.util.Random','com.actelion.research.chem.alignment3d.transformation.RotationDerivatives','com.actelion.research.chem.alignment3d.transformation.Quaternion','com.actelion.research.chem.alignment3d.transformation.ExponentialMap','com.actelion.research.chem.conf.TorsionDB','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.alignment3d.transformation.Rotation','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','com.actelion.research.chem.potentialenergy.PositionConstraint']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "LigandPose", null, null, 'com.actelion.research.chem.optimization.Evaluable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['torsionHelper','com.actelion.research.chem.conf.BondRotationHelper','state','double[]','ligConf','com.actelion.research.chem.conf.Conformer','origCoords','com.actelion.research.chem.Coordinates[]','+cachedCoords','dRdvi1','double[][]','+dRdvi2','+dRdvi3','mol','com.actelion.research.chem.StereoMolecule','engine','com.actelion.research.chem.docking.scoring.AbstractScoringEngine','origCOM','com.actelion.research.chem.Coordinates','mcHelper','com.actelion.research.chem.optimization.MCHelper']]
,['D',['MOVE_AMPLITUDE'],'J',['SEED']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_docking_scoring_AbstractScoringEngine$D',  function (ligConf, engine, e0) {
;C$.$init$.apply(this);
this.engine=engine;
this.ligConf=ligConf;
p$1.init$D.apply(this, [e0]);
}, 1);

Clazz.newMeth(C$, 'setMCSBondConstraints$java_util_List',  function (constraints) {
var rotBonds=this.torsionHelper.getRotatableBonds$();
var allowedIndices=Clazz.new_($I$(1,1));
for (var rbIndex=0; rbIndex < rotBonds.length; rbIndex++) {
var rb=rotBonds[rbIndex];
if (!constraints.contains$O(Integer.valueOf$I(rb))) allowedIndices.add$O(Integer.valueOf$I(rbIndex));
}
var mcsRotBondIndeces=Clazz.array(Integer.TYPE, [allowedIndices.size$()]);
for (var i=0; i < allowedIndices.size$(); i++) {
mcsRotBondIndeces[i]=(allowedIndices.get$I(i)).$c();
}
this.mcHelper.setMcsRotBondIndeces$IA(mcsRotBondIndeces);
});

Clazz.newMeth(C$, 'init$D',  function (e0) {
this.mol=this.ligConf.getMolecule$();
this.torsionHelper=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$Z,[this.mol, true]);
this.engine.init$com_actelion_research_chem_docking_LigandPose$D(this, e0);
this.setInitialState$();
this.origCoords=Clazz.array($I$(3), [this.ligConf.getMolecule$().getAllAtoms$()]);
this.cachedCoords=Clazz.array($I$(3), [this.ligConf.getMolecule$().getAllAtoms$()]);
this.origCOM=Clazz.new_($I$(3,1));
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
this.origCoords[a]=Clazz.new_([this.ligConf.getCoordinates$I(a)],$I$(3,1).c$$com_actelion_research_chem_Coordinates);
this.cachedCoords[a]=Clazz.new_([this.ligConf.getCoordinates$I(a)],$I$(3,1).c$$com_actelion_research_chem_Coordinates);
this.origCOM.add$com_actelion_research_chem_Coordinates(this.cachedCoords[a]);
}
this.origCOM.scale$D(1.0 / this.cachedCoords.length);
this.dRdvi1=Clazz.array(Double.TYPE, [3, 3]);
this.dRdvi2=Clazz.array(Double.TYPE, [3, 3]);
this.dRdvi3=Clazz.array(Double.TYPE, [3, 3]);
this.mcHelper=Clazz.new_([this.torsionHelper, null, Clazz.new_($I$(5,1).c$$J,[C$.SEED])],$I$(4,1).c$$com_actelion_research_chem_conf_BondRotationHelper$IA$java_util_Random);
}, p$1);

Clazz.newMeth(C$, 'resetLigCoordinates',  function () {
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
this.ligConf.setX$I$D(a, this.origCoords[a].x);
this.ligConf.setY$I$D(a, this.origCoords[a].y);
this.ligConf.setZ$I$D(a, this.origCoords[a].z);
}
}, p$1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var coordGrad=Clazz.array(Double.TYPE, [this.ligConf.getMolecule$().getAllAtoms$() * 3]);
for (var i=0; i < gradient.length; i++) {
gradient[i]=0.0;
}
var energy=this.engine.getFGValue$DA(coordGrad);
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
gradient[0]+=coordGrad[3 * a];
gradient[1]+=coordGrad[3 * a + 1];
gradient[2]+=coordGrad[3 * a + 2];
}
var p=Clazz.array(Double.TYPE, -1, [this.state[3], this.state[4], this.state[5]]);
var transformDerivatives=Clazz.new_($I$(6,1).c$$DA,[p]);
transformDerivatives.dRdv$I$DAA(0, this.dRdvi1);
transformDerivatives.dRdv$I$DAA(1, this.dRdvi2);
transformDerivatives.dRdv$I$DAA(2, this.dRdvi3);
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
var vi=this.cachedCoords[a];
var Tj_vi=vi.rotateC$DAA(this.dRdvi1);
gradient[3]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
Tj_vi=vi.rotateC$DAA(this.dRdvi2);
gradient[4]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
Tj_vi=vi.rotateC$DAA(this.dRdvi3);
gradient[5]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
}
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var rotatedAtoms=this.torsionHelper.getSmallerSideAtomLists$()[b];
var j=this.torsionHelper.getRotationCenters$()[b];
var k=this.torsionHelper.getTorsionAtoms$()[b][1] == j ? this.torsionHelper.getTorsionAtoms$()[b][2] : this.torsionHelper.getTorsionAtoms$()[b][1];
var v1=this.ligConf.getCoordinates$I(k).subC$com_actelion_research_chem_Coordinates(this.ligConf.getCoordinates$I(j));
for (var i, $i = 0, $$i = rotatedAtoms; $i<$$i.length&&((i=($$i[$i])),1);$i++) {
var v2=this.ligConf.getCoordinates$I(i).subC$com_actelion_research_chem_Coordinates(this.ligConf.getCoordinates$I(j));
var dx_dphi=v1.cross$com_actelion_research_chem_Coordinates(v2);
gradient[6 + b]+=dx_dphi.x * coordGrad[3 * i] + dx_dphi.y * coordGrad[3 * i + 1] + dx_dphi.z * coordGrad[3 * i + 2];
}
}
return energy;
});

Clazz.newMeth(C$, 'getContributions$',  function () {
return this.engine.getContributions$();
});

Clazz.newMeth(C$, 'setInitialState$',  function () {
var elements=3 + 3 + this.torsionHelper.getRotatableBonds$().length ;
this.state=Clazz.array(Double.TYPE, [elements]);
this.state[0]=0.0;
this.state[1]=0.0;
this.state[2]=0.0;
var quat=Clazz.new_($I$(7,1).c$$D$D$D$D,[1.0, 0.0, 0.0, 0.0]);
var emap=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_alignment3d_transformation_Quaternion,[quat]);
this.state[3]=emap.getP$().x;
this.state[4]=emap.getP$().y;
this.state[5]=emap.getP$().z;
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var atoms=this.torsionHelper.getTorsionAtoms$()[b];
this.state[6 + b]=$I$(9).calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA(this.ligConf, atoms);
}
});

Clazz.newMeth(C$, 'updateLigandCoordinates$',  function () {
p$1.resetLigCoordinates.apply(this, []);
p$1.updateDihedralAngles.apply(this, []);
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
this.cachedCoords[a]=Clazz.new_([this.ligConf.getCoordinates$I(a)],$I$(3,1).c$$com_actelion_research_chem_Coordinates);
}
var eMap=Clazz.new_($I$(8,1).c$$D$D$D,[this.state[3], this.state[4], this.state[5]]);
var q=eMap.toQuaternion$();
var trans1=Clazz.new_([this.origCOM.scaleC$D(-1.0)],$I$(10,1).c$$com_actelion_research_chem_Coordinates);
var trans2=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_Coordinates,[this.origCOM]);
var rot=Clazz.new_([q.getRotMatrix$().getArray$()],$I$(11,1).c$$DAA);
var t=Clazz.new_($I$(10,1).c$$D$D$D,[this.state[0], this.state[1], this.state[2]]);
var transformation=Clazz.new_($I$(12,1));
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans1);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(rot);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans2);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(t);
transformation.apply$com_actelion_research_chem_conf_Conformer(this.ligConf);
});

Clazz.newMeth(C$, 'updateDihedralAngles',  function () {
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var targetTorsion=this.state[6 + b];
var atoms=this.torsionHelper.getTorsionAtoms$()[b];
var currentTorsion=$I$(9).calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA(this.ligConf, atoms);
var deltaTorsion=targetTorsion - currentTorsion;
this.torsionHelper.rotateAroundBond$I$D$com_actelion_research_chem_conf_Conformer$Z(b, deltaTorsion, this.ligConf, false);
}
}, p$1);

Clazz.newMeth(C$, 'setState$DA',  function (state) {
Clazz.assert(C$, this, function(){return this.state.length == state.length});
for (var i=0; i < state.length; i++) {
if (i > 5) {
if (state[i] > 3.141592653589793 ) {
state[i]-=6.283185307179586;
}}this.state[i]=state[i];
}
this.updateLigandCoordinates$();
});

Clazz.newMeth(C$, 'getState$DA',  function (v) {
for (var i=0; i < this.state.length; i++) {
v[i]=this.state[i];
}
return v;
});

Clazz.newMeth(C$, 'getCartState$',  function () {
var cartState=Clazz.array(Double.TYPE, [3 * this.ligConf.getMolecule$().getAllAtoms$()]);
for (var a=0; a < this.ligConf.getMolecule$().getAllAtoms$(); a++) {
cartState[3 * a]=this.ligConf.getCoordinates$I(a).x;
cartState[3 * a + 1]=this.ligConf.getCoordinates$I(a).y;
cartState[3 * a + 2]=this.ligConf.getCoordinates$I(a).z;
}
return cartState;
});

Clazz.newMeth(C$, 'getScore$',  function () {
return this.engine.getScore$();
});

Clazz.newMeth(C$, 'getState$',  function () {
return this.getState$DA(Clazz.array(Double.TYPE, [this.state.length]));
});

Clazz.newMeth(C$, 'randomPerturbation$',  function () {
this.mcHelper.randomPerturbation$com_actelion_research_chem_conf_Conformer$DA(this.ligConf, this.state);
this.updateLigandCoordinates$();
});

Clazz.newMeth(C$, 'addPositionalConstraints$D',  function (d) {
for (var a=0; a < this.ligConf.getMolecule$().getAtoms$(); a++) {
var constraint=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_conf_Conformer$I$D$D,[this.ligConf, a, 50.0, d]);
this.engine.addConstraint$com_actelion_research_chem_potentialenergy_PotentialEnergyTerm(constraint);
}
});

Clazz.newMeth(C$, 'addConstraint$com_actelion_research_chem_potentialenergy_PositionConstraint',  function (constraint) {
this.engine.addConstraint$com_actelion_research_chem_potentialenergy_PotentialEnergyTerm(constraint);
});

Clazz.newMeth(C$, 'removeConstraints$',  function () {
this.engine.removeConstraints$();
});

Clazz.newMeth(C$, 'getLigConf$',  function () {
return this.ligConf;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.MOVE_AMPLITUDE=2.0;
C$.SEED=12345;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:05 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
