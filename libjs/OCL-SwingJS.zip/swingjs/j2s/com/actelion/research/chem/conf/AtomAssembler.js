(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.conf.TorsionDB','com.actelion.research.chem.Coordinates','com.actelion.research.chem.conf.BondLengthSet','com.actelion.research.chem.conf.VDWRadii']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomAssembler");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMol','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMol=mol;
}, 1);

Clazz.newMeth(C$, 'addImplicitHydrogens$',  function () {
this.mMol.ensureHelperArrays$I(7);
var total=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) total+=p$1.addImplicitHydrogens$I$Z.apply(this, [atom, true]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) total+=p$1.addImplicitHydrogens$I$Z.apply(this, [atom, false]);

return total;
});

Clazz.newMeth(C$, 'addImplicitHydrogens$I',  function (atom) {
return p$1.addImplicitHydrogens$I$Z.apply(this, [atom, false]);
});

Clazz.newMeth(C$, 'addImplicitHydrogens$I$Z',  function (atom, skipRotatableHydrogens) {
var atomicNo=this.mMol.getAtomicNo$I(atom);
if (atomicNo == 0) return 0;
var count=this.mMol.getImplicitHydrogens$I(atom);
if (count == 0) return 0;
if (this.mMol.getConnAtoms$I(atom) == 0) return p$1.addHydrogensToSingleAtom$I$I.apply(this, [atom, count]);
var pi=this.mMol.getAtomPi$I(atom);
var sp=(atomicNo >= 15) ? 3 : (pi == 2) ? 1 : (pi == 1 || atomicNo == 5  || this.mMol.isFlatNitrogen$I(atom) ) ? 2 : 3;
var croot=this.mMol.getCoordinates$I(atom);
var bondLength=p$1.getHydrogenBondLength$I.apply(this, [atom]);
if (sp == 1) {
var cconn=this.mMol.getCoordinates$I(this.mMol.getConnAtom$I$I(atom, 0));
var cnew=croot.addC$com_actelion_research_chem_Coordinates(croot.subC$com_actelion_research_chem_Coordinates(cconn).unit$().scale$D(bondLength));
var newAtom=this.mMol.addAtom$I(1);
this.mMol.setAtomX$I$D(newAtom, cnew.x);
this.mMol.setAtomY$I$D(newAtom, cnew.y);
this.mMol.setAtomZ$I$D(newAtom, cnew.z);
this.mMol.addBond$I$I$I(atom, newAtom, 1);
return 1;
}var atomSequence=Clazz.array(Integer.TYPE, [4]);
atomSequence[2]=atom;
for (var i1=0; i1 < this.mMol.getConnAtoms$I(atom); i1++) {
atomSequence[1]=this.mMol.getConnAtom$I$I(atom, i1);
for (var i0=0; i0 < this.mMol.getConnAtoms$I(atomSequence[1]); i0++) {
atomSequence[0]=this.mMol.getConnAtom$I$I(atomSequence[1], i0);
if (atomSequence[0] != atom) {
if (this.mMol.getConnAtoms$I(atom) == 3) {
atomSequence[3]=-1;
var dihedral=$I$(1).calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$IA(this.mMol, atomSequence);
p$1.addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D.apply(this, [this.mMol.getCoordinates$I(atomSequence[0]), this.mMol.getCoordinates$I(atomSequence[1]), this.mMol.getCoordinates$I(atom), atom, 1.902408884673819, dihedral, bondLength]);
return 1;
}var angle=(sp == 2) ? 2.0943951023931953 : 1.902408884673819;
if (this.mMol.getConnAtoms$I(atom) == 2) {
if (count == 1 && skipRotatableHydrogens ) return 0;
for (var i3=0; i3 < this.mMol.getConnAtoms$I(atom); i3++) {
atomSequence[3]=this.mMol.getConnAtom$I$I(atom, i3);
if (atomSequence[3] != atomSequence[1]) {
var dihedral=$I$(1).calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$IA(this.mMol, atomSequence);
dihedral+=(sp == 2) ? 3.141592653589793 : 2.0943951023931953;
if (dihedral > 3.141592653589793 ) dihedral-=6.283185307179586;
p$1.addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D.apply(this, [this.mMol.getCoordinates$I(atomSequence[0]), this.mMol.getCoordinates$I(atomSequence[1]), this.mMol.getCoordinates$I(atom), atom, angle, dihedral, bondLength]);
if (count != 1) {
dihedral+=2.0943951023931953;
if (dihedral > 3.141592653589793 ) dihedral-=6.283185307179586;
p$1.addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D.apply(this, [this.mMol.getCoordinates$I(atomSequence[0]), this.mMol.getCoordinates$I(atomSequence[1]), this.mMol.getCoordinates$I(atom), atom, angle, dihedral, bondLength]);
}return count;
}}
}if (skipRotatableHydrogens) return 0;
for (var i=i0 + 1; i < this.mMol.getConnAtoms$I(atomSequence[1]); i++) {
var alternative=this.mMol.getConnAtom$I$I(atomSequence[1], i);
if (alternative != atom && this.mMol.getConnBondOrder$I$I(atomSequence[1], i) == 1 ) {
atomSequence[0]=alternative;
break;
}}
var dihedral=3.141592653589793;
if (sp == 3) {
dihedral=p$1.getMostBlockedDihedral$IA$D.apply(this, [atomSequence, bondLength]);
if (count == 3) dihedral+=1.0471975511965976;
 else if (count == 2) dihedral+=2.0943951023931953;
 else if (count == 1) dihedral+=3.141592653589793;
}for (var i=0; i < count; i++) {
p$1.addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D.apply(this, [this.mMol.getCoordinates$I(atomSequence[0]), this.mMol.getCoordinates$I(atomSequence[1]), this.mMol.getCoordinates$I(atom), atom, angle, dihedral, bondLength]);
dihedral+=(sp == 2) ? 3.141592653589793 : 2.0943951023931953;
}
return count;
}}
}
if (count == 1 && sp == this.mMol.getConnAtoms$I(atom) ) {
var v=Clazz.new_($I$(2,1));
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) v.add$com_actelion_research_chem_Coordinates(croot.subC$com_actelion_research_chem_Coordinates(this.mMol.getCoordinates$I(this.mMol.getConnAtom$I$I(atom, i))).unit$());

v.unit$();
var hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, croot.x + bondLength * v.x);
this.mMol.setAtomY$I$D(hydrogen, croot.y + bondLength * v.y);
this.mMol.setAtomZ$I$D(hydrogen, croot.z + bondLength * v.z);
return 1;
}var angle=(sp == 2) ? 2.0943951023931953 : 1.911135530933791;
var rotationDif=(sp == 2) ? 3.141592653589793 : 2.0943951023931953;
var rearAtom=this.mMol.getConnAtom$I$I(atom, 0);
var v=croot.subC$com_actelion_research_chem_Coordinates(this.mMol.getCoordinates$I(rearAtom));
var vIsParallelToZ=(v.z != 0  && (Math.abs(v.x) + Math.abs(v.y)) / Math.abs(v.z) < 0.01  );
var upsideDown=false;
if (vIsParallelToZ) {
if (v.z < 0 ) upsideDown=true;
} else {
if (v.x == 0 ) {
if (v.y < 0 ) upsideDown=true;
} else {
if (v.x < 0 ) upsideDown=true;
}}var rotation=0.0;
if (this.mMol.getConnAtoms$I(atom) == 2) {
var otherAtom=this.mMol.getConnAtom$I$I(atom, 1);
if (vIsParallelToZ) {
rearAtom=otherAtom;
otherAtom=this.mMol.getConnAtom$I$I(atom, 0);
v=croot.subC$com_actelion_research_chem_Coordinates(this.mMol.getCoordinates$I(rearAtom));
vIsParallelToZ=false;
}var dummyCoords=Clazz.new_([this.mMol.getCoordinates$I(rearAtom)],$I$(2,1).c$$com_actelion_research_chem_Coordinates);
dummyCoords.add$D$D$D(0, 0, 1);
rotation=p$1.calculateDihedral$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates.apply(this, [dummyCoords, this.mMol.getCoordinates$I(rearAtom), this.mMol.getCoordinates$I(atom), this.mMol.getCoordinates$I(otherAtom)]);
rotation+=rotationDif;
}if (vIsParallelToZ) {
var dz=-Math.cos(angle) * bondLength;
if (upsideDown) {
rotation+=3.141592653589793;
dz=-dz;
}var r=bondLength * Math.sin(3.141592653589793 - angle);
for (var i=0; i < count; i++) {
var hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, croot.x + r * Math.sin(rotation));
this.mMol.setAtomY$I$D(hydrogen, croot.y + r * Math.cos(rotation));
this.mMol.setAtomZ$I$D(hydrogen, croot.z + dz);
rotation+=rotationDif;
}
return count;
} else {
for (var i=0; i < count; i++) {
var c1=Clazz.new_([this.mMol.getCoordinates$I(rearAtom)],$I$(2,1).c$$com_actelion_research_chem_Coordinates);
c1.add$D$D$D(0, 0, upsideDown ? -1 : 1);
var c2=this.mMol.getCoordinates$I(rearAtom);
var c3=this.mMol.getCoordinates$I(atom);
p$1.addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D.apply(this, [c1, c2, c3, atom, angle, rotation, bondLength]);
rotation+=rotationDif;
}
return count;
}}, p$1);

Clazz.newMeth(C$, 'addHydrogensToSingleAtom$I$I',  function (atom, count) {
var p=this.mMol.getCoordinates$I(atom);
var length=p$1.getHydrogenBondLength$I.apply(this, [atom]);
switch (count) {
case 1:
var hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + length);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z);
return 1;
case 2:
var angle=0.017453292519943295 * (this.mMol.getAtomicNo$I(atom) == 8 ? 104.45 : this.mMol.getAtomicNo$I(atom) == 16 ? 92.1 : 109.5);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + length);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + length * Math.cos(angle));
this.mMol.setAtomY$I$D(hydrogen, p.y + length * Math.sin(angle));
this.mMol.setAtomZ$I$D(hydrogen, p.z);
return 2;
case 3:
angle=0.3665191429188092;
var dx=length * Math.cos(angle);
var dz=length * Math.sin(angle);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + dx);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z - dz);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x - 0.5 * dx);
this.mMol.setAtomY$I$D(hydrogen, p.y + 0.866 * dx);
this.mMol.setAtomZ$I$D(hydrogen, p.z - dz);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x - 0.5 * dx);
this.mMol.setAtomY$I$D(hydrogen, p.y - 0.866 * dx);
this.mMol.setAtomZ$I$D(hydrogen, p.z - dz);
return 3;
case 4:
angle=0.34033920413889424;
dx=length * Math.cos(angle);
dz=length * Math.sin(angle);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x - dx);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z + dz);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + 0.5 * dx);
this.mMol.setAtomY$I$D(hydrogen, p.y + 0.866 * dx);
this.mMol.setAtomZ$I$D(hydrogen, p.z + dz);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x + 0.5 * dx);
this.mMol.setAtomY$I$D(hydrogen, p.y - 0.866 * dx);
this.mMol.setAtomZ$I$D(hydrogen, p.z + dz);
hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(atom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z - length);
return 4;
}
return 0;
}, p$1);

Clazz.newMeth(C$, 'getHydrogenBondLength$I',  function (atom) {
var index=$I$(3,"getBondIndex$I$Z$Z$I$I$I$I",[1, false, false, this.mMol.getAtomicNo$I(atom), 1, this.mMol.getAtomPi$I(atom), 0]);
return (index == -1) ? 1.09 : $I$(3).getBondLength$I(index);
}, p$1);

Clazz.newMeth(C$, 'calculateDihedral$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates',  function (c1, c2, c3, c4) {
var v1=c2.subC$com_actelion_research_chem_Coordinates(c1);
var v2=c3.subC$com_actelion_research_chem_Coordinates(c2);
var v3=c4.subC$com_actelion_research_chem_Coordinates(c3);
var n1=v1.cross$com_actelion_research_chem_Coordinates(v2);
var n2=v2.cross$com_actelion_research_chem_Coordinates(v3);
return -Math.atan2(v2.getLength$() * v1.dot$com_actelion_research_chem_Coordinates(n2), n1.dot$com_actelion_research_chem_Coordinates(n2));
}, p$1);

Clazz.newMeth(C$, 'getMostBlockedDihedral$IA$D',  function (atomSequence, bondLength) {
var croot=this.mMol.getCoordinates$I(atomSequence[2]);
var cconn=this.mMol.getCoordinates$I(atomSequence[2]);
var ctest=croot.addC$com_actelion_research_chem_Coordinates(croot.subC$com_actelion_research_chem_Coordinates(cconn).unit$().scale$D(0.5 * bondLength));
var angle=1.902408884673819;
var orbitRadius=bondLength * Math.sin(1.902408884673819);
var FACTOR=0.85;
var maxCollision=0.0;
var maxTorsion=NaN;
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
if (atom != atomSequence[1] && atom != atomSequence[2] ) {
var catom=this.mMol.getCoordinates$I(atom);
var minDist=orbitRadius + 0.85 * $I$(4).getVDWRadius$I(1) + $I$(4,"getVDWRadius$I",[this.mMol.getAtomicNo$I(atom)]);
var dx=Math.abs(ctest.x - catom.x);
if (dx < minDist ) {
var dy=Math.abs(ctest.y - catom.y);
if (dy < minDist ) {
var dz=Math.abs(ctest.z - catom.z);
if (dz < minDist ) {
if (Math.sqrt(dx * dx + dy * dy + dz * dz) < minDist ) {
atomSequence[3]=atom;
var dihedral=(atom == atomSequence[0]) ? 0.0 : $I$(1).calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$IA(this.mMol, atomSequence);
var p=p$1.getCoordinatesWithConstraints$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D$D$D.apply(this, [this.mMol.getCoordinates$I(atomSequence[0]), this.mMol.getCoordinates$I(atomSequence[1]), this.mMol.getCoordinates$I(atomSequence[2]), 1.902408884673819, dihedral, bondLength]);
dx=Math.abs(p.x - catom.x);
dy=Math.abs(p.y - catom.y);
dz=Math.abs(p.z - catom.z);
var distance=Math.sqrt(dx * dx + dy * dy + dz * dz);
var collision=minDist - orbitRadius - distance ;
if (maxCollision < collision ) {
maxCollision=collision;
maxTorsion=dihedral;
}}}}}}}
return maxTorsion;
}, p$1);

Clazz.newMeth(C$, 'addHydrogen$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$I$D$D$D',  function (c1, c2, c3, rootAtom, angle, dihedral, bondLength) {
var p=p$1.getCoordinatesWithConstraints$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D$D$D.apply(this, [c1, c2, c3, angle, dihedral, bondLength]);
var hydrogen=this.mMol.addAtom$I(1);
this.mMol.addBond$I$I$I(rootAtom, hydrogen, 1);
this.mMol.setAtomX$I$D(hydrogen, p.x);
this.mMol.setAtomY$I$D(hydrogen, p.y);
this.mMol.setAtomZ$I$D(hydrogen, p.z);
}, p$1);

Clazz.newMeth(C$, 'getCoordinatesWithConstraints$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D$D$D',  function (c1, c2, c3, angle, dihedral, bondLength) {
var r=bondLength * Math.sin(3.141592653589793 - angle);
var x=-r * Math.sin(dihedral);
var y=r * Math.cos(dihedral);
var z=bondLength * Math.cos(3.141592653589793 - angle);
var axisZ=c3.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var axisX=c1.subC$com_actelion_research_chem_Coordinates(c2).cross$com_actelion_research_chem_Coordinates(axisZ).unit$();
var axisY=axisX.cross$com_actelion_research_chem_Coordinates(axisZ).unit$();
var m=Clazz.array(Double.TYPE, [3, 3]);
m[0][0]=-axisX.x;
m[0][1]=-axisX.y;
m[0][2]=-axisX.z;
m[1][0]=-axisY.x;
m[1][1]=-axisY.y;
m[1][2]=-axisY.z;
m[2][0]=axisZ.x;
m[2][1]=axisZ.y;
m[2][2]=axisZ.z;
return Clazz.new_($I$(2,1).c$$D$D$D,[x, y, z]).rotate$DAA(m).add$com_actelion_research_chem_Coordinates(c3);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
