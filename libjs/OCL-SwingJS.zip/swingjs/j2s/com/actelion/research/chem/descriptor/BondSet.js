(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BondSet", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMask','int[]']]]

Clazz.newMeth(C$, 'c$$IA$I$I',  function (bond, usedBonds, bondCount) {
;C$.$init$.apply(this);
this.mMask=Clazz.array(Integer.TYPE, [((bondCount + 31)/32|0)]);
for (var i=0; i < usedBonds; i++) this.mMask[(bond[i]/32|0)]|=(1 << (bond[i] % 32));

}, 1);

Clazz.newMeth(C$, 'equals$com_actelion_research_chem_descriptor_BondSet',  function (bs) {
for (var i=0; i < this.mMask.length; i++) if (bs.mMask[i] != this.mMask[i]) return false;

return true;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_BondSet','compareTo$O'],  function (bs) {
for (var i=0; i < this.mMask.length; i++) if (bs.mMask[i] != this.mMask[i]) return bs.mMask[i] < this.mMask[i] ? -1 : 1;

return 0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
