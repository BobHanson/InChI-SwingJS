(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MDHIndexTables");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['liArrAtPairsBonds','java.util.List','+liConnectionTable']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.MDHIndexTables']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) C$.INSTANCE=Clazz.new_(C$);
return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.liArrAtPairsBonds=Clazz.new_($I$(1,1));
this.liArrAtPairsBonds.add$I$O(0, null);
this.liArrAtPairsBonds.add$I$O(1, null);
for (var i=2; i < 51; i++) {
this.liArrAtPairsBonds.add$I$O(i, p$1.createBondTable$I.apply(this, [i]));
}
this.liConnectionTable=Clazz.new_($I$(1,1));
this.liConnectionTable.add$I$O(0, null);
this.liConnectionTable.add$I$O(1, null);
for (var i=2; i < 51; i++) {
this.liConnectionTable.add$I$O(i, p$1.createConnectionTable$I.apply(this, [i]));
}
}, p$1);

Clazz.newMeth(C$, 'createBondTable$I',  function (nodes) {
var bonds=(((nodes * nodes) - nodes)/2|0);
var arrAtPairsBonds=Clazz.array(Integer.TYPE, [2, bonds]);
var cc=0;
for (var i=0; i < nodes; i++) {
for (var j=i + 1; j < nodes; j++) {
arrAtPairsBonds[0][cc]=i;
arrAtPairsBonds[1][cc]=j;
++cc;
}
}
return arrAtPairsBonds;
}, p$1);

Clazz.newMeth(C$, 'createConnectionTable$I',  function (nodes) {
var arrAtPairsBonds=this.liArrAtPairsBonds.get$I(nodes);
var bonds=(((nodes * nodes) - nodes)/2|0);
var arrConnBond=Clazz.array(Integer.TYPE, [nodes, nodes - 1]);
var arrNumBonds=Clazz.array(Integer.TYPE, [nodes]);
for (var bnd=0; bnd < bonds; bnd++) {
var at1=arrAtPairsBonds[0][bnd];
var at2=arrAtPairsBonds[1][bnd];
arrConnBond[at1][arrNumBonds[at1]++]=bnd;
arrConnBond[at2][arrNumBonds[at2]++]=bnd;
}
return arrConnBond;
}, p$1);

Clazz.newMeth(C$, 'getAtomPairsBondsTable$I',  function (nodes) {
return this.liArrAtPairsBonds.get$I(nodes);
});

Clazz.newMeth(C$, 'getConnectionTable$I',  function (nodes) {
return this.liConnectionTable.get$I(nodes);
});

C$.$static$=function(){C$.$static$=0;
C$.INSTANCE=null;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
