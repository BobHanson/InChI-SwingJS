(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','java.util.ArrayList','com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher','com.actelion.research.chem.descriptor.DescriptorConstants','StringBuilder','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode','java.nio.charset.StandardCharsets','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTreeGenerator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerPTree", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.pharmacophoretree.DescriptorHandlerPTree','FAILED_OBJECT','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree']]]

Clazz.newMeth(C$, ['getSimilarity$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree','getSimilarity$O$O'],  function (pt1, pt2) {
var sim=0.0;
if (pt1.getNodes$().size$() == 1 || pt2.getNodes$().size$() == 1 ) sim=pt1.getDirectSim$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(pt2);
 else {
var matcher=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree,[pt1, pt2]);
var matching=matcher.matchSearch$();
sim=matching.getSim$();
}return sim;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(4).DESCRIPTOR_PTREE.version;
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(4).DESCRIPTOR_PTREE;
});

Clazz.newMeth(C$, ['encode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree','encode$O'],  function (pTree) {
var sb=Clazz.new_($I$(5,1));
for (var ppNode, $ppNode = pTree.getNodes$().iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) {
sb.append$S($I$(6).encode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode(ppNode));
sb.append$S(";");
}
sb.deleteCharAt$I(sb.length$() - 1);
sb.append$S(":");
for (var edge, $edge = pTree.getEdges$().iterator$(); $edge.hasNext$()&&((edge=($edge.next$())),1);) {
sb.append$I(edge[0]);
sb.append$S(" ");
sb.append$I(edge[1]);
sb.append$S(":");
}
sb.deleteCharAt$I(sb.length$() - 1);
return sb.toString();
});

Clazz.newMeth(C$, 'getDecodedObject$S',  function (s) {
var splitString=s.split$S(":");
var nodeStrings=splitString[0].split$S(";");
var nodes=Clazz.new_($I$(2,1));
var edges=Clazz.new_($I$(2,1));
for (var nodeString, $nodeString = 0, $$nodeString = nodeStrings; $nodeString<$$nodeString.length&&((nodeString=($$nodeString[$nodeString])),1);$nodeString++) nodes.add$O($I$(6).decode$S(nodeString));

for (var i=1; i < splitString.length; i++) {
var edgeStrings=splitString[i].split$S(" ");
edges.add$O(Clazz.array(Integer.TYPE, -1, [(Integer.valueOf$S(edgeStrings[0])).valueOf(), (Integer.valueOf$S(edgeStrings[1])).valueOf()]));
}
return Clazz.new_($I$(1,1).c$$java_util_List$java_util_List,[nodes, edges]);
}, p$1);

Clazz.newMeth(C$, 'decode$BA',  function (arr) {
return this.decode$S( String.instantialize(arr, $I$(7).UTF_8));
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
try {
return s == null  || s.length$() == 0  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : p$1.getDecodedObject$S.apply(this, [s]);
} catch (e1) {
if (Clazz.exceptionOf(e1,"RuntimeException")){
return C$.FAILED_OBJECT;
} else {
throw e1;
}
}
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (m) {
var mol=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_Molecule,[m]);
mol.stripSmallFragments$();
var pharmTree=$I$(9).generate$com_actelion_research_chem_StereoMolecule(mol);
if (pharmTree.getNodes$().size$() > 40) pharmTree=C$.FAILED_OBJECT;
return pharmTree;
});

Clazz.newMeth(C$, ['calculationFailed$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree','calculationFailed$O'],  function (o) {
var failed=o.getNodes$().size$() == 0 ? true : false;
return failed;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return Clazz.new_(C$);
});

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.new_([Clazz.new_($I$(2,1)), Clazz.new_($I$(2,1))],$I$(1,1).c$$java_util_List$java_util_List);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:05 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
