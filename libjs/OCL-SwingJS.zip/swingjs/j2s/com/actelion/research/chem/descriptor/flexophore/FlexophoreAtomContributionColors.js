(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorHandlerFlexophore','java.awt.Color']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FlexophoreAtomContributionColors");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMolFlexophore','com.actelion.research.chem.descriptor.flexophore.MolDistHist','+mRefFlexophore','mRefARGB','int[]','+mMolARGB','mRefRadius','float[]','+mMolRadius']]
,['O',['cDiverseColor','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist$I$I',  function (molFlexophore, refFlexophore, molAtomCount, refAtomCount) {
;C$.$init$.apply(this);
var NODE_SIMILARITY_FACTOR=4.0;
this.mMolFlexophore=molFlexophore;
this.mRefFlexophore=refFlexophore;
if (molAtomCount != 0 && refAtomCount != 0  && molFlexophore != null   && refFlexophore != null  ) {
var molNodeAtom=molFlexophore.getNodeAtoms$();
var refNodeAtom=refFlexophore.getNodeAtoms$();
if (molNodeAtom != null  && refNodeAtom != null  ) {
var dhFlexophore=Clazz.new_($I$(1,1));
var objectiveBlurFlexophoreHardMatchUncovered=dhFlexophore.getObjectiveCompleteGraph$();
var modelSolutionSimilarity=dhFlexophore.getBestMatch$com_actelion_research_chem_descriptor_flexophore_MolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist(molFlexophore, refFlexophore);
if (modelSolutionSimilarity != null ) {
this.mMolARGB=Clazz.array(Integer.TYPE, [molAtomCount]);
this.mRefARGB=Clazz.array(Integer.TYPE, [refAtomCount]);
this.mMolRadius=Clazz.array(Float.TYPE, [molAtomCount]);
this.mRefRadius=Clazz.array(Float.TYPE, [refAtomCount]);
var matchingNodeCount=modelSolutionSimilarity.getSizeHeap$();
objectiveBlurFlexophoreHardMatchUncovered.setBase$com_actelion_research_chem_descriptor_flexophore_IMolDistHist(molFlexophore);
objectiveBlurFlexophoreHardMatchUncovered.setQuery$com_actelion_research_chem_descriptor_flexophore_IMolDistHist(refFlexophore);
var colorList=C$.createDiverseColorList$I(matchingNodeCount);
for (var i=0; i < matchingNodeCount; i++) {
var molNode=modelSolutionSimilarity.getIndexBaseFromHeap$I(i);
var refNode=modelSolutionSimilarity.getIndexQueryFromHeap$I(i);
var nodeSimilarity=modelSolutionSimilarity.getSimilarityNode$I(i);
var edgeSimilarity=objectiveBlurFlexophoreHardMatchUncovered.getSimilarityHistogramsForNode$com_actelion_research_util_graph_complete_SolutionCompleteGraph$I(modelSolutionSimilarity, i);
if (nodeSimilarity > 0.0 ) {
nodeSimilarity=Math.max(0.0, Math.min(1.0, Math.round(nodeSimilarity * 4.0 - 4.0 + 1.0)));
for (var atom, $atom = 0, $$atom = molNodeAtom[molNode]; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
var alpha=Math.round(nodeSimilarity * 255);
this.mMolARGB[atom]=(alpha << 24) | colorList[i];
this.mMolRadius[atom]=edgeSimilarity;
}
for (var atom, $atom = 0, $$atom = refNodeAtom[refNode]; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
var alpha=Math.round(nodeSimilarity * 255);
this.mRefARGB[atom]=(alpha << 24) | colorList[i];
this.mRefRadius[atom]=edgeSimilarity;
}
}}
}}}}, 1);

Clazz.newMeth(C$, 'getMolFlexophore$',  function () {
return this.mMolFlexophore;
});

Clazz.newMeth(C$, 'getRefFlexophore$',  function () {
return this.mRefFlexophore;
});

Clazz.newMeth(C$, 'getMolARGB$',  function () {
return this.mMolARGB;
});

Clazz.newMeth(C$, 'getRefARGB$',  function () {
return this.mRefARGB;
});

Clazz.newMeth(C$, 'getMolRadius$',  function () {
return this.mMolRadius;
});

Clazz.newMeth(C$, 'getRefRadius$',  function () {
return this.mRefRadius;
});

Clazz.newMeth(C$, 'createDiverseColorList$I',  function (colorCount) {
if (colorCount <= C$.cDiverseColor.length) return C$.cDiverseColor;
var divisor=((colorCount & 1) == 0) ? colorCount : colorCount + 1;
var s=Clazz.array(Float.TYPE, -1, [1.0, 0.4, 0.8, 1.0, 1.0, 0.6, 0.8, 1.0]);
var b=Clazz.array(Float.TYPE, -1, [0.8, 1.0, 1.0, 0.6, 0.8, 1.0, 1.0, 0.4]);
var colorList=Clazz.array(Integer.TYPE, [colorCount]);
for (var i=0; i < colorCount; i++) {
var hue=i / divisor;
colorList[i]=$I$(2).HSBtoRGB$F$F$F(hue, s[i & 7], b[i & 7]);
}
return colorList;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.cDiverseColor=Clazz.array(Integer.TYPE, -1, [4784383, 16711722, 44390, 16776960, 5231096, 14524662, 16755481, 12648400, 16711896, 11168600, 12369084, 6187814, 7143168, 16759959, 11847474, 10878976]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
