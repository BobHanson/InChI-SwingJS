(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.completegraphmatcher"),I$=[[0,'com.actelion.research.calc.Matrix','com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable','StringBuilder','com.actelion.research.util.datamodel.table.TableModelString','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','java.util.ArrayList','com.actelion.research.util.Formatter','com.actelion.research.chem.descriptor.flexophore.PPNode','java.util.Collections','com.actelion.research.calc.statistics.median.MedianStatisticFunctions','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPNodeSimilarity", null, null, 'com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.IPPNodeSimilarity');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['verbose'],'D',['threshSimilarityHardMatch'],'I',['similarityMode'],'O',['interactionSimilarityTable','com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable','maSimilarity','com.actelion.research.calc.Matrix']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.PPNodeSimilarity']]]

Clazz.newMeth(C$, 'c$$I$I',  function (versionInteractionTable, modePPNodeSimilarity) {
;C$.$init$.apply(this);
this.maSimilarity=Clazz.new_($I$(1,1).c$$I$I,[20, 20]);
this.interactionSimilarityTable=$I$(2).getInstance$();
this.similarityMode=modePPNodeSimilarity;
this.threshSimilarityHardMatch=0.9;
}, 1);

Clazz.newMeth(C$, 'setThreshSimilarityHardMatch$D',  function (threshSimilarityHardMatch) {
this.threshSimilarityHardMatch=threshSimilarityHardMatch;
});

Clazz.newMeth(C$, 'toStringParameter$',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$S("ObjectiveFlexophoreHardMatchUncovered, similarity mode ");
switch (this.similarityMode) {
case 0:
sb.append$S("simple");
break;
case 1:
sb.append$S("hard thresh multiplicative");
sb.append$S(", threshold=");
sb.append$D(this.threshSimilarityHardMatch);
break;
case 2:
sb.append$S("hard thresh average");
sb.append$S(", threshold=");
sb.append$D(this.threshSimilarityHardMatch);
break;
case 3:
sb.append$S("hard thresh optimistic");
sb.append$S(", percentile=");
sb.append$D(0.75);
sb.append$S(", threshold=");
sb.append$D(this.threshSimilarityHardMatch);
break;
case 4:
sb.append$S("carbon");
break;
}
return sb.toString();
});

Clazz.newMeth(C$, 'getInstance$I$I',  function (versionInteractionTable, modePPNodeSimilarity) {
if (C$.INSTANCE == null ) {
{
C$.INSTANCE=Clazz.new_(C$.c$$I$I,[versionInteractionTable, modePPNodeSimilarity]);
}}return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'setVerbose$Z',  function (v) {
this.verbose=v;
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_descriptor_flexophore_IPPNode$com_actelion_research_chem_descriptor_flexophore_IPPNode',  function (query, base) {
var similarity=0;
switch (this.similarityMode) {
case 0:
similarity=this.getSimilaritySimple$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
break;
case 1:
similarity=this.getSimilarityHardMatchMultiplicative$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
break;
case 2:
similarity=this.getSimilarityHardMatchAverage$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
break;
case 3:
similarity=this.getSimilarityHardMatchOptimistic$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
break;
case 4:
similarity=this.getSimilarityExtraCarbonConsideration$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
break;
}
return similarity;
});

Clazz.newMeth(C$, 'getSimilaritySimple$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
this.maSimilarity.set$D(0);
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionTypeQuery=query.getInteractionType$I(i);
for (var j=0; j < base.getInteractionTypeCount$(); j++) {
var interactionTypeBase=base.getInteractionType$I(j);
var similarity=1.0 - this.interactionSimilarityTable.getDistance$I$I(interactionTypeQuery, interactionTypeBase);
this.maSimilarity.set$I$I$D(i, j, similarity);
}
}
if (this.verbose) {
System.out.println$S("PPNodeSimilarityMultiplicative");
var tableModelString=Clazz.new_([query.getInteractionTypeCount$(), base.getInteractionTypeCount$()],$I$(4,1).c$$I$I);
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionType=query.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setRowName$I$S(i, s);
}
for (var i=0; i < base.getInteractionTypeCount$(); i++) {
var interactionType=base.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setColName$I$S(i, s);
}
tableModelString.set$com_actelion_research_calc_Matrix$I(this.maSimilarity, 2);
System.out.println$S(tableModelString.toString());
}var liSimilarities=Clazz.new_($I$(6,1));
if (base.getInteractionTypeCount$() > query.getInteractionTypeCount$()) {
for (var col=0; col < base.getInteractionTypeCount$(); col++) {
var maxSimInCol=0;
for (var row=0; row < query.getInteractionTypeCount$(); row++) {
if (this.maSimilarity.get$I$I(row, col) > maxSimInCol ) {
maxSimInCol=this.maSimilarity.get$I$I(row, col);
}}
liSimilarities.add$O(Double.valueOf$D(maxSimInCol));
}
} else {
for (var row=0; row < query.getInteractionTypeCount$(); row++) {
var maxSimInRow=0;
for (var col=0; col < base.getInteractionTypeCount$(); col++) {
if (this.maSimilarity.get$I$I(row, col) > maxSimInRow ) {
maxSimInRow=this.maSimilarity.get$I$I(row, col);
}}
liSimilarities.add$O(Double.valueOf$D(maxSimInRow));
}
}var sim=0;
if (liSimilarities.size$() > 0) {
sim=1;
for (var simPart, $simPart = liSimilarities.iterator$(); $simPart.hasNext$()&&((simPart=($simPart.next$())),1);) {
sim*=(simPart).$c();
}
}if (this.verbose) {
System.out.println$S("Sim " + $I$(7,"format2$Double",[Double.valueOf$D(sim)]));
System.out.println$();
}return sim;
});

Clazz.newMeth(C$, 'getSimilarityHardMatchMultiplicative$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
var queryCmp=query;
var baseCmp=base;
if (base.hasHeteroAtom$() && query.hasHeteroAtom$() ) {
queryCmp=$I$(8).getHeteroOnlyNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query);
baseCmp=$I$(8).getHeteroOnlyNode$com_actelion_research_chem_descriptor_flexophore_PPNode(base);
}var liSimilarities=this.getSimilarityList$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(queryCmp, baseCmp);
var sim=0;
if (liSimilarities.size$() > 0) {
sim=1;
for (var simPart, $simPart = liSimilarities.iterator$(); $simPart.hasNext$()&&((simPart=($simPart.next$()).objectValue$()),1);) {
if (simPart < this.threshSimilarityHardMatch ) {
sim=0;
break;
}sim*=simPart;
}
}if (this.verbose) {
System.out.println$S("Sim " + $I$(7,"format2$Double",[Double.valueOf$D(sim)]));
System.out.println$();
}return sim;
});

Clazz.newMeth(C$, 'getSimilarityList$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
this.maSimilarity.set$D(0);
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionTypeQuery=query.getInteractionType$I(i);
for (var j=0; j < base.getInteractionTypeCount$(); j++) {
var interactionTypeBase=base.getInteractionType$I(j);
try {
var similarity=1.0 - this.interactionSimilarityTable.getDistance$I$I(interactionTypeQuery, interactionTypeBase);
this.maSimilarity.set$I$I$D(i, j, similarity);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Error in PPNodeSimilarity");
System.err.println$S("interactionTypeQuery " + interactionTypeQuery);
System.err.println$S("interactionTypeBase " + interactionTypeBase);
throw Clazz.new_(Clazz.load('RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
}
}
if (this.verbose) {
System.out.println$S("PPNodeSimilarity");
var tableModelString=Clazz.new_([query.getInteractionTypeCount$(), base.getInteractionTypeCount$()],$I$(4,1).c$$I$I);
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionType=query.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setRowName$I$S(i, s);
}
for (var i=0; i < base.getInteractionTypeCount$(); i++) {
var interactionType=base.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setColName$I$S(i, s);
}
tableModelString.set$com_actelion_research_calc_Matrix$I(this.maSimilarity, 2);
System.out.println$S(tableModelString.toString());
}var arrMaxSim=C$.getTopValues$com_actelion_research_calc_Matrix$I$I$D(this.maSimilarity, query.getInteractionTypeCount$(), base.getInteractionTypeCount$(), this.threshSimilarityHardMatch);
var liSimilarities=Clazz.new_($I$(6,1).c$$I,[arrMaxSim.length]);
for (var v, $v = 0, $$v = arrMaxSim; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
liSimilarities.add$O(Double.valueOf$D(v));
}
return liSimilarities;
});

Clazz.newMeth(C$, 'getTopValues$com_actelion_research_calc_Matrix$I$I$D',  function (maSimilarity, rows, cols, thresh) {
var arrTopSim=Clazz.array(Double.TYPE, [Math.max(rows, cols)]);
if (rows == 1 && cols == 1 ) {
arrTopSim[0]=maSimilarity.get$I$I(0, 0);
return arrTopSim;
}if (cols > rows) {
for (var col=0; col < cols; col++) {
var maxSimInCol=0;
for (var row=0; row < rows; row++) {
if (maSimilarity.get$I$I(row, col) > maxSimInCol ) {
maxSimInCol=maSimilarity.get$I$I(row, col);
}}
arrTopSim[col]=maxSimInCol;
}
} else if (cols < rows) {
for (var row=0; row < rows; row++) {
var maxSimInRow=0;
for (var col=0; col < cols; col++) {
if (maSimilarity.get$I$I(row, col) > maxSimInRow ) {
maxSimInRow=maSimilarity.get$I$I(row, col);
}}
arrTopSim[row]=maxSimInRow;
}
} else {
var invalidCol=false;
var sumCol=0;
var arrTopSimCol=Clazz.array(Double.TYPE, [cols]);
for (var col=0; col < cols; col++) {
var maxSimInCol=0;
for (var row=0; row < rows; row++) {
var v=maSimilarity.get$I$I(row, col);
if (v > maxSimInCol ) {
maxSimInCol=v;
}}
arrTopSimCol[col]=maxSimInCol;
sumCol+=maxSimInCol;
if (maxSimInCol < thresh ) {
invalidCol=true;
}}
var arrTopSimRow=Clazz.array(Double.TYPE, [rows]);
var invalidRow=false;
var sumRow=0;
for (var row=0; row < rows; row++) {
var maxSimInRow=0;
for (var col=0; col < cols; col++) {
var v=maSimilarity.get$I$I(row, col);
if (v > maxSimInRow ) {
maxSimInRow=v;
}}
arrTopSimRow[row]=maxSimInRow;
sumRow+=maxSimInRow;
if (maxSimInRow < thresh ) {
invalidRow=true;
}}
if (invalidCol && invalidRow ) {
if (sumCol > sumRow ) {
arrTopSim=arrTopSimCol;
} else {
arrTopSim=arrTopSimRow;
}} else if (invalidCol) {
arrTopSim=arrTopSimRow;
} else if (invalidRow) {
arrTopSim=arrTopSimCol;
} else {
if (sumCol > sumRow ) {
arrTopSim=arrTopSimCol;
} else {
arrTopSim=arrTopSimRow;
}}}return arrTopSim;
}, 1);

Clazz.newMeth(C$, 'getSimilarityHardMatchAverage$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
var liSimilarities=this.getSimilarityList$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
var sumSim=0;
if (liSimilarities.size$() > 0) {
for (var simPart, $simPart = liSimilarities.iterator$(); $simPart.hasNext$()&&((simPart=($simPart.next$()).objectValue$()),1);) {
if (simPart < this.threshSimilarityHardMatch ) {
sumSim=0;
break;
}sumSim+=simPart;
}
}var sim=sumSim / liSimilarities.size$();
if (this.verbose) {
System.out.println$S("Sim " + $I$(7,"format2$Double",[Double.valueOf$D(sim)]));
System.out.println$();
}return sim;
});

Clazz.newMeth(C$, 'getSimilarityHardMatchOptimistic$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
var liSimilarities=this.getSimilarityList$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode(query, base);
var sim=0;
if (liSimilarities.size$() > 0) {
if (liSimilarities.size$() == 1) {
sim=(liSimilarities.get$I(0)).valueOf();
} else {
$I$(9).sort$java_util_List(liSimilarities);
sim=$I$(10).getPercentileFromSorted$java_util_List$D(liSimilarities, 0.75);
}}if (this.verbose) {
System.out.println$S("Sim " + $I$(7,"format2$Double",[Double.valueOf$D(sim)]));
System.out.println$();
}return sim;
});

Clazz.newMeth(C$, 'getSimilarityExtraCarbonConsideration$com_actelion_research_chem_descriptor_flexophore_PPNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (query, base) {
this.maSimilarity.set$D(0);
var valNoInteraction=-1;
var lowCarbonFractionQuery=(query.getFractionCarbonInteractions$() < 0.6 ) ? true : false;
var lowCarbonFractionBase=(base.getFractionCarbonInteractions$() < 0.6 ) ? true : false;
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionTypeQuery=query.getInteractionType$I(i);
var carbonInteractionQuery=$I$(5).isCarbonInteraction$I(interactionTypeQuery);
if (carbonInteractionQuery) {
if (lowCarbonFractionQuery) {
for (var j=0; j < base.getInteractionTypeCount$(); j++) {
this.maSimilarity.set$I$I$D(i, j, -1.0);
}
continue;
}}for (var j=0; j < base.getInteractionTypeCount$(); j++) {
var interactionTypeBase=base.getInteractionType$I(j);
var carbonInteractionBase=$I$(5).isCarbonInteraction$I(interactionTypeBase);
if (carbonInteractionBase) {
if (lowCarbonFractionBase) {
this.maSimilarity.set$I$I$D(i, j, -1.0);
continue;
}}var similarity=-1.0;
if (carbonInteractionBase == carbonInteractionQuery ) {
similarity=1.0 - this.interactionSimilarityTable.getDistance$I$I(interactionTypeQuery, interactionTypeBase);
}this.maSimilarity.set$I$I$D(i, j, similarity);
}
}
if (this.verbose) {
System.out.println$S("PPNodeSimilarityMultiplicative");
var tableModelString=Clazz.new_([query.getInteractionTypeCount$(), base.getInteractionTypeCount$()],$I$(4,1).c$$I$I);
for (var i=0; i < query.getInteractionTypeCount$(); i++) {
var interactionType=query.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setRowName$I$S(i, s);
}
for (var i=0; i < base.getInteractionTypeCount$(); i++) {
var interactionType=base.getInteractionType$I(i);
var s=$I$(5).getString$I(interactionType);
tableModelString.setColName$I$S(i, s);
}
tableModelString.set$com_actelion_research_calc_Matrix$I(this.maSimilarity, 2);
System.out.println$S(tableModelString.toString());
}var liSimilarities=Clazz.new_($I$(6,1));
if (base.getInteractionTypeCount$() > query.getInteractionTypeCount$()) {
for (var col=0; col < base.getInteractionTypeCount$(); col++) {
var interactionTypeQuery=-1;
var interactionTypeBase=-1;
var maxSimInCol=-1.0;
for (var row=0; row < query.getInteractionTypeCount$(); row++) {
if (this.maSimilarity.get$I$I(row, col) > maxSimInCol ) {
maxSimInCol=this.maSimilarity.get$I$I(row, col);
interactionTypeBase=base.getInteractionType$I(col);
interactionTypeQuery=query.getInteractionType$I(row);
}}
if (Math.abs(maxSimInCol - -1.0) < 1.0E-7 ) {
continue;
}liSimilarities.add$O(Double.valueOf$D(maxSimInCol));
}
} else {
for (var row=0; row < query.getInteractionTypeCount$(); row++) {
var interactionTypeQuery=-1;
var interactionTypeBase=-1;
var maxSimInRow=-1.0;
for (var col=0; col < base.getInteractionTypeCount$(); col++) {
if (this.maSimilarity.get$I$I(row, col) > maxSimInRow ) {
maxSimInRow=this.maSimilarity.get$I$I(row, col);
interactionTypeBase=base.getInteractionType$I(col);
interactionTypeQuery=query.getInteractionType$I(row);
}}
if (Math.abs(maxSimInRow - -1.0) < 1.0E-7 ) {
continue;
}liSimilarities.add$O(Double.valueOf$D(maxSimInRow));
}
}var sim=0;
if (liSimilarities.size$() > 0) {
sim=1;
for (var simPart, $simPart = liSimilarities.iterator$(); $simPart.hasNext$()&&((simPart=($simPart.next$())),1);) {
sim*=(simPart).$c();
}
}if (this.verbose) {
System.out.println$S("Sim " + $I$(7,"format2$Double",[Double.valueOf$D(sim)]));
System.out.println$();
}return sim;
});

Clazz.newMeth(C$, 'isValidType$I',  function (type) {
var valid=true;
try {
var key=$I$(11).getInstance$().getKey$I(type);
this.interactionSimilarityTable.getDistance$I$I(key, key);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
valid=false;
} else {
throw e;
}
}
return valid;
});

C$.$static$=function(){C$.$static$=0;
C$.INSTANCE=null;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
