(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d"),p$1={},I$=[[0,'java.util.stream.IntStream','com.actelion.research.chem.Coordinates','com.actelion.research.calc.Matrix','java.util.Arrays','com.actelion.research.calc.SingularValueDecomposition']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "KabschAlignment");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['coords1','com.actelion.research.chem.Coordinates[]','+coords2','com1','com.actelion.research.chem.Coordinates','+com2','mapping','int[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA',  function (coords1, coords2, mapping) {
;C$.$init$.apply(this);
this.coords1=coords1;
this.coords2=coords2;
this.mapping=mapping;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer',  function (conf1, conf2) {
C$.c$$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA.apply(this, [conf1.getCoordinates$(), conf2.getCoordinates$(), $I$(1,"range$I$I",[0, conf1.getMolecule$().getAtoms$()]).mapToObj$java_util_function_IntFunction((P$.KabschAlignment$lambda1$||(P$.KabschAlignment$lambda1$=(((P$.KabschAlignment$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$I','apply$O'],  function (e) { return (Clazz.array(Integer.TYPE, -1, [e, e]));});
})()
), Clazz.new_(P$.KabschAlignment$lambda1.$init$,[this, null])))))).toArray$java_util_function_IntFunction(((P$.KabschAlignment$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'apply$I',  function (t) { return Clazz.array(Integer.TYPE, [t.intValue(), null])});
})()
), Clazz.new_(P$.KabschAlignment$lambda2.$init$,[this, null])))]);
}, 1);

Clazz.newMeth(C$, 'getCOM$com_actelion_research_chem_CoordinatesA',  function (coords) {
var counter=0;
var com=Clazz.new_($I$(2,1));
for (var c, $c = 0, $$c = coords; $c<$$c.length&&((c=($$c[$c])),1);$c++) {
com.add$com_actelion_research_chem_Coordinates(c);
++counter;
}
com.scale$D(1.0 / counter);
return com;
}, p$1);

Clazz.newMeth(C$, 'align$',  function () {
this.align$com_actelion_research_chem_Coordinates$com_actelion_research_calc_Matrix$com_actelion_research_chem_Coordinates(Clazz.new_($I$(2,1)), Clazz.new_($I$(3,1).c$$I$I,[3, 3]), Clazz.new_($I$(2,1)));
});

Clazz.newMeth(C$, 'align$com_actelion_research_chem_Coordinates$com_actelion_research_calc_Matrix$com_actelion_research_chem_Coordinates',  function (trans1, rot, trans2) {
this.com1=p$1.getCOM$com_actelion_research_chem_CoordinatesA.apply(this, [this.coords1]);
this.com2=p$1.getCOM$com_actelion_research_chem_CoordinatesA.apply(this, [this.coords2]);
for (var c1, $c1 = 0, $$c1 = this.coords1; $c1<$$c1.length&&((c1=($$c1[$c1])),1);$c1++) c1.sub$com_actelion_research_chem_Coordinates(this.com1);

for (var c2, $c2 = 0, $$c2 = this.coords2; $c2<$$c2.length&&((c2=($$c2[$c2])),1);$c2++) c2.sub$com_actelion_research_chem_Coordinates(this.com2);

var t1=this.com2.scaleC$D(-1.0);
trans1.x=t1.x;
trans1.y=t1.y;
trans1.z=t1.z;
trans2.x=this.com1.x;
trans2.y=this.com1.y;
trans2.z=this.com1.z;
var m=Clazz.new_($I$(3,1).c$$I$I,[3, 3]);
var c1=$I$(4).stream$OA(this.coords1).map$java_util_function_Function((P$.KabschAlignment$lambda3$||(P$.KabschAlignment$lambda3$=(((P$.KabschAlignment$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_Coordinates','apply$O'],  function (e) { return (Clazz.array(Double.TYPE, -1, [e.x, e.y, e.z]));});
})()
), Clazz.new_(P$.KabschAlignment$lambda3.$init$,[this, null])))))).toArray$java_util_function_IntFunction(((P$.KabschAlignment$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'apply$I',  function (t) { return Clazz.array(Double.TYPE, [t.intValue(), null])});
})()
), Clazz.new_(P$.KabschAlignment$lambda4.$init$,[this, null])));
var c2=$I$(4).stream$OA(this.coords2).map$java_util_function_Function((P$.KabschAlignment$lambda5$||(P$.KabschAlignment$lambda5$=(((P$.KabschAlignment$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_Coordinates','apply$O'],  function (e) { return (Clazz.array(Double.TYPE, -1, [e.x, e.y, e.z]));});
})()
), Clazz.new_(P$.KabschAlignment$lambda5.$init$,[this, null])))))).toArray$java_util_function_IntFunction(((P$.KabschAlignment$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "KabschAlignment$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'apply$I',  function (t) { return Clazz.array(Double.TYPE, [t.intValue(), null])});
})()
), Clazz.new_(P$.KabschAlignment$lambda6.$init$,[this, null])));
for (var i=0; i < 3; i++) {
for (var j=0; j < 3; j++) {
var rij=0.0;
for (var map, $map = 0, $$map = this.mapping; $map<$$map.length&&((map=($$map[$map])),1);$map++) {
rij+=c2[map[1]][i] * c1[map[0]][j];
}
m.set$I$I$D(i, j, rij);
}
}
var svd=Clazz.new_([m.getArray$(), null, null],$I$(5,1).c$$DAA$com_actelion_research_calc_ProgressListener$com_actelion_research_calc_ThreadMaster);
var u=Clazz.new_([svd.getU$()],$I$(3,1).c$$DAA);
var v=Clazz.new_([svd.getV$()],$I$(3,1).c$$DAA);
var ut=u.getTranspose$();
var vut=v.multiply$com_actelion_research_calc_Matrix(ut);
var det=vut.det$();
var ma=Clazz.new_($I$(3,1).c$$I$I,[3, 3]);
ma.set$I$I$D(0, 0, 1.0);
ma.set$I$I$D(1, 1, 1.0);
ma.set$I$I$D(2, 2, det);
var r=ma.multiply$com_actelion_research_calc_Matrix(ut);
r=v.multiply$com_actelion_research_calc_Matrix(r);
Clazz.assert(C$, this, function(){return (r.det$() > 0.0 )});
r=r.getTranspose$();
for (var c, $c = 0, $$c = this.coords2; $c<$$c.length&&((c=($$c[$c])),1);$c++) {
c.rotate$DAA(r.getArray$());
c.add$com_actelion_research_chem_Coordinates(this.com1);
}
for (var c, $c = 0, $$c = this.coords1; $c<$$c.length&&((c=($$c[$c])),1);$c++) {
c.add$com_actelion_research_chem_Coordinates(this.com1);
}
rot.set$DAA(r.getArray$());
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
