(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'java.io.File','java.io.BufferedReader','java.io.FileReader','com.actelion.research.chem.forcefield.mmff.Vector3']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Sdf", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['OnMolecule',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'testFolder$S$S$S$com_actelion_research_chem_forcefield_mmff_Sdf_OnMolecule',  function (sdfbase, refbase, ext, cb) {
var failed=0;
var total=0;
var dir=Clazz.new_($I$(1,1).c$$S,[sdfbase]);
var ls=dir.listFiles$();
for (var fp, $fp = 0, $$fp = ls; $fp<$$fp.length&&((fp=($$fp[$fp])),1);$fp++) {
var sdfpath=fp.getAbsolutePath$();
if (!sdfpath.endsWith$S(".sdf")) continue;
var refpath=Clazz.new_([refbase, fp.getName$()],$I$(1,1).c$$S$S).getPath$().replace$CharSequence$CharSequence(".sdf", ext);
failed+=cb.check$S$S(sdfpath, refpath) ? 0 : 1;
++total;
}
System.out.println$S("Failed molecules: " + failed + " / " + total + "    (" + new Double(((failed * 100.0) / total)).toString() + "%)" );
}, 1);

Clazz.newMeth(C$, 'getPositions$S',  function (sdfpath) {
var br=null;
try {
var line;
br=Clazz.new_([Clazz.new_($I$(3,1).c$$S,[sdfpath])],$I$(2,1).c$$java_io_Reader);
br.readLine$();
br.readLine$();
br.readLine$();
var natoms=Integer.parseInt$S(br.readLine$().substring$I$I(0, 3).trim$());
var res=Clazz.array($I$(4), [natoms]);
for (var i=0; i < natoms && (line=br.readLine$()) != null  ; i++) {
res[i]=Clazz.new_([Double.parseDouble$S(line.substring$I$I(0, 10).trim$()), Double.parseDouble$S(line.substring$I$I(10, 20).trim$()), Double.parseDouble$S(line.substring$I$I(20, 30).trim$())],$I$(4,1).c$$D$D$D);
}
return res;
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.io.FileNotFoundException")){
var e = e$$;
{
System.out.println$S("Could not find file: '" + sdfpath + "'" );
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var e = e$$;
{
System.out.println$S("IO Exception!");
}
} else {
throw e$$;
}
} finally {
try {
if (br != null ) br.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
System.out.println$S("Couldn\'t close buffered reader!");
} else {
throw e;
}
}
}
return Clazz.array($I$(4), [1]);
}, 1);
;
(function(){/*i*/var C$=Clazz.newInterface(P$.Sdf, "OnMolecule", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
