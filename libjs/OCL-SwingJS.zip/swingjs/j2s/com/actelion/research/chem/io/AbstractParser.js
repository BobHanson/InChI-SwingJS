(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),I$=[[0,'java.util.ArrayList','java.util.zip.GZIPInputStream','java.io.FileInputStream','java.io.InputStreamReader','java.nio.charset.StandardCharsets','java.util.zip.ZipInputStream','java.io.BufferedReader','java.io.FileReader','java.io.File','java.util.zip.GZIPOutputStream','java.io.FileOutputStream','java.io.OutputStreamWriter','java.util.zip.ZipOutputStream','java.io.BufferedWriter','java.io.FileWriter','IllegalAccessError','java.util.HashSet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.errors=Clazz.new_($I$(1,1));
this.optimize3D=true;
},1);

C$.$fields$=[['Z',['optimize3D'],'O',['errors','java.util.List']]
,['S',['NEWLINE']]]

Clazz.newMeth(C$, 'loadGroup$S',  function (fileName) {
var r=null;
try {
if (fileName.toUpperCase$().endsWith$S(".GZ")) {
var is=Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName])],$I$(2,1).c$$java_io_InputStream);
r=Clazz.new_([is, $I$(5).UTF_8],$I$(4,1).c$$java_io_InputStream$java_nio_charset_Charset);
} else if (fileName.toUpperCase$().endsWith$S(".ZIP")) {
var is=Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName])],$I$(6,1).c$$java_io_InputStream);
r=Clazz.new_([is, $I$(5).UTF_8],$I$(4,1).c$$java_io_InputStream$java_nio_charset_Charset);
} else {
r=Clazz.new_([Clazz.new_($I$(8,1).c$$S,[fileName])],$I$(7,1).c$$java_io_Reader);
}var mols=this.loadGroup$S$java_io_Reader$I$I(fileName, r, -1, -1);
var count=0;
for (var mol, $mol = mols.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
++count;
if (mol != null  && (mol.getName$() == null  || mol.getName$().length$() == 0 ) ) mol.setName$S(Clazz.new_($I$(9,1).c$$S,[fileName]).getName$() + (mols.size$() > 1 ? "#" + count : ""));
}
return mols;
} finally {
if (r != null ) try {
r.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'loadGroup$S$java_io_Reader',  function (fileName, $in) {
return this.loadGroup$S$java_io_Reader$I$I(fileName, $in, -1, -1);
});

Clazz.newMeth(C$, 'load$java_io_File',  function (file) {
return this.load$S(file.getPath$());
});

Clazz.newMeth(C$, 'load$S',  function (fileName) {
var list=this.loadGroup$S(fileName);
return list.size$() > 0 ? list.get$I(0) : null;
});

Clazz.newMeth(C$, 'load$S$java_io_Reader',  function (fileName, $in) {
var list=this.loadGroup$S$java_io_Reader$I$I(fileName, $in, -1, -1);
return list.size$() > 0 ? list.get$I(0) : null;
});

Clazz.newMeth(C$, 'save$java_util_List$S',  function (mol, fileName) {
var w=null;
try {
if (fileName.toUpperCase$().endsWith$S(".GZ")) {
var os=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[fileName])],$I$(10,1).c$$java_io_OutputStream);
w=Clazz.new_($I$(12,1).c$$java_io_OutputStream,[os]);
} else if (fileName.toUpperCase$().endsWith$S(".ZIP")) {
var os=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[fileName])],$I$(13,1).c$$java_io_OutputStream);
w=Clazz.new_($I$(12,1).c$$java_io_OutputStream,[os]);
} else {
w=Clazz.new_([Clazz.new_([Clazz.new_($I$(11,1).c$$S,[fileName]), $I$(5).UTF_8],$I$(12,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(14,1).c$$java_io_Writer);
}this.save$java_util_List$java_io_Writer(mol, w);
w.close$();
} finally {
if (w != null ) try {
w.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'save$com_actelion_research_chem_Molecule3D$S',  function (mol, fileName) {
var w=null;
try {
if (fileName.toUpperCase$().endsWith$S(".GZ")) {
var os=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[fileName])],$I$(10,1).c$$java_io_OutputStream);
w=Clazz.new_($I$(12,1).c$$java_io_OutputStream,[os]);
} else if (fileName.toUpperCase$().endsWith$S(".ZIP")) {
var os=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[fileName])],$I$(13,1).c$$java_io_OutputStream);
w=Clazz.new_($I$(12,1).c$$java_io_OutputStream,[os]);
} else {
w=Clazz.new_($I$(15,1).c$$S,[fileName]);
}this.save$com_actelion_research_chem_Molecule3D$java_io_Writer(mol, w);
w.close$();
} finally {
if (w != null ) try {
w.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'save$com_actelion_research_chem_Molecule3D$java_io_Writer',  function (mol, writer) {
throw Clazz.new_($I$(16,1).c$$S,["Not implemented"]);
});

Clazz.newMeth(C$, 'save$java_util_List$java_io_Writer',  function (mols, writer) {
if (mols == null  || mols.size$() == 0 ) return;
if (mols.size$() == 1) this.save$com_actelion_research_chem_Molecule3D$java_io_Writer(mols.get$I(0), writer);
 else {
throw Clazz.new_($I$(16,1).c$$S,["Cannot save more than one file in  this format"]);
}});

Clazz.newMeth(C$, 'convertDataToPrimitiveTypes$java_util_List',  function (res) {
if (res.size$() == 0) return;
var fieldNames=Clazz.new_($I$(17,1));
for (var m, $m = res.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
fieldNames.addAll$java_util_Collection(m.getAuxiliaryInfos$().keySet$());
}
 loop : for (var fieldName, $fieldName = fieldNames.iterator$(); $fieldName.hasNext$()&&((fieldName=($fieldName.next$())),1);) {
var type=0;
var val="";
for (var m, $m = res.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
var o=m.getAuxiliaryInfos$().get$O(fieldName);
if (o == null ) continue;
if (!(Clazz.instanceOf(o, "java.lang.String"))) {
continue loop;
}val=o;
if (type == 0) try {
Integer.parseInt$S(val);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
++type;
} else {
throw e;
}
}
if (type == 1) try {
Double.parseDouble$S(val);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
++type;
} else {
throw e;
}
}
if (type == 2) break;
}
if (type == 0) {
for (var m, $m = res.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
val=m.getAuxiliaryInfos$().get$O(fieldName);
if (val != null ) m.getAuxiliaryInfos$().put$O$O(fieldName, Integer.valueOf$I(Integer.parseInt$S(m.getAuxiliaryInfos$().get$O(fieldName))));
}
} else if (type == 1) {
for (var m, $m = res.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
val=m.getAuxiliaryInfos$().get$O(fieldName);
if (val != null ) m.getAuxiliaryInfos$().put$O$O(fieldName, Double.valueOf$D(Double.parseDouble$S(val)));
}
}}
}, 1);

Clazz.newMeth(C$, 'writeR$java_io_Writer$S$I',  function (writer, data, len) {
if (data == null ) data="";
var l=Math.max(0, len - data.length$());
for (var i=0; i < l; i++) writer.write$I(" ".$c());

writer.write$S(data);
}, 1);

Clazz.newMeth(C$, 'writeL$java_io_Writer$S$I',  function (writer, data, len) {
if (data == null ) data="";
writer.write$S(data);
var l=Math.max(0, len - data.length$());
for (var i=0; i < l; i++) writer.write$I(" ".$c());

}, 1);

Clazz.newMeth(C$, 'getErrors$',  function () {
return this.errors;
});

Clazz.newMeth(C$, 'is3D$com_actelion_research_chem_Molecule3D',  function (m) {
for (var a=0; a < m.getAllAtoms$(); a++) {
if (Math.abs(m.getAtomZ$I(a)) > 0.1 ) return true;
}
return false;
}, 1);

Clazz.newMeth(C$, 'setOptimize3D$Z',  function (optimize3d) {
this.optimize3D=optimize3d;
});

Clazz.newMeth(C$, 'isOptimize3D$',  function () {
return this.optimize3D;
});

C$.$static$=function(){C$.$static$=0;
C$.NEWLINE=System.getProperty$S("line.separator");
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
