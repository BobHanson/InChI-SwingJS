(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.DescriptorHandlerFlexophore','com.actelion.research.chem.phesa.DescriptorHandlerShape','com.actelion.research.chem.phesa.DescriptorHandlerShapeOneConf']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerStandardFactory", null, 'com.actelion.research.chem.descriptor.DescriptorHandlerStandard2DFactory');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['$sFactory','com.actelion.research.chem.descriptor.DescriptorHandlerStandardFactory']]]

Clazz.newMeth(C$, 'getFactory$',  function () {
if (C$.$sFactory == null ) {
{
if (C$.$sFactory == null ) C$.$sFactory=Clazz.new_(C$);
}}return C$.$sFactory;
}, 1);

Clazz.newMeth(C$, 'getDefaultDescriptorHandler$S',  function (shortName) {
var dh=C$.superclazz.prototype.getDefaultDescriptorHandler$S.apply(this, [shortName]);
if (dh != null ) return dh;
if ($I$(1).DESCRIPTOR_Flexophore.shortName.equals$O(shortName)) {
return $I$(2).getDefaultInstance$();
} else if ($I$(1).DESCRIPTOR_ShapeAlign.shortName.equals$O(shortName)) {
return $I$(3).getDefaultInstance$();
} else if ($I$(1).DESCRIPTOR_ShapeAlignSingleConf.shortName.equals$O(shortName)) {
return $I$(3).getDefaultInstance$();
}return null;
});

Clazz.newMeth(C$, 'create$S',  function (shortName) {
var dh=C$.superclazz.prototype.create$S.apply(this, [shortName]);
if (dh != null ) return dh;
if ($I$(1).DESCRIPTOR_Flexophore.shortName.equals$O(shortName)) {
return Clazz.new_($I$(2,1));
} else if ($I$(1).DESCRIPTOR_ShapeAlign.shortName.equals$O(shortName)) {
return Clazz.new_($I$(3,1));
} else if ($I$(1).DESCRIPTOR_ShapeAlignSingleConf.shortName.equals$O(shortName)) {
return Clazz.new_($I$(4,1));
}return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
